package com.example.demo.bookrepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.Book.Book;
import com.example.demo.Book.BookPublisher;

public interface BookPublisherRepository extends JpaRepository<BookPublisher, Integer>{
	void deleteById(int id);

	public  List<Book> findById(int id);
}