var express = require('express');
var apiRouter = express.Router();
var FileController = require('../../controller/FileController');

apiRouter.post('/create_contract', FileController.createContract);
apiRouter.get('/getpdf_for_user/:userId',FileController.getPdfForUser);
apiRouter.delete('/deleteproperty',FileController.delProperty)
apiRouter.get('/findfile',FileController.findFile)
apiRouter.get('/findproperty',FileController.findProperty)

module.exports = apiRouter;
