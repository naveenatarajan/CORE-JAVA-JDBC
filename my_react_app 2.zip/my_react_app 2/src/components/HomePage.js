import React, { Component } from 'react';
import { Button, Dropdown, Menu, Icon, Image } from 'semantic-ui-react'

import './homePage.css';
import logo from './aeroLogo.jpg';


class HomeComponent extends Component {
    constructor(props) {
    super(props);
    this.state = {
      activeItem: 'Patients'
     }
   }

   componentWillMount() {
       
   }




  render() {
    const { activeItem } = this.state;

    return (
      <div>
        <nav class="navbar navbar-expand-md bg-dark navbar-dark cstm-nav-bar-css">
          <a class="navbar-brand" href="#">
            <img src={logo} alt="logo" className="logo-css-design" />
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon" style={{ backgroundColor:'lightskyblue'}}></span>
          </button>
          <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav">
              <li class="nav-item">
                <span class="nav-link space-menu"></span>
              </li>
              <li class="nav-item">
                <span class="nav-link font-color-css">Dashboard</span>
              </li>
              <li class="nav-item">
                <span class="nav-link font-color-css" >
                Patients
                <span class="badge badge-light badge-style">64</span>
                </span>
              </li>
            </ul>
              <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                <div class="nav-link font-color-css">
                  <Icon color='teal' name='search' />
                </div>
                </li>
                <li class="nav-item">
                  <div class="nav-link font-color-css">
                    <Icon color='teal' name='bell' />
                  </div>
                </li>
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle font-color-css" href="#" id="navbardrop" data-toggle="dropdown">
                  <Image src='https://static.turbosquid.com/Preview/2015/02/21__10_20_16/doc_MainImageWide.jpg33530628-2ba0-4a6d-89f6-2edeeb3f3c2cOriginal.jpg' avatar />
                  </a>
                  <div class="dropdown-menu">
                    <a class="dropdown-item" href="#">Link 1</a>
                    <a class="dropdown-item" href="#">Link 2</a>
                    <a class="dropdown-item" href="#">Link 3</a>
                  </div>
                </li>
                <li class="nav-item">
                  <div class="nav-link font-color-css">
                  <Button color='twitter'>
                    <Icon name='plus' /> ADD PATIENT
                  </Button>
                  </div>
                </li>
              </ul>
          </div>
        </nav>
        <br />

        <div class="container-fluid">
            <h3>Body Container</h3>
            <p>In this example, the navigation bar is hidden on small screens and replaced by a button in the top right corner (try to re-size this window).</p>
            <p>Only when the button is clicked, the navigation bar will be displayed.</p>
            <p>Tip: You can also remove the .navbar-expand-md class to ALWAYS hide navbar links and display the toggler button.</p>
          </div>
       
        </div>
    );
  }
}

export default HomeComponent;
