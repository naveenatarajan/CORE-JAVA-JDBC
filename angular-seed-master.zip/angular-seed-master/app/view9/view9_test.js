'use strict';

describe('myApp.view9 module', function() {

  beforeEach(module('myApp.view9'));

  describe('view9 controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view9Ctrl = $controller('View9Ctrl');
      expect(view9Ctrl).toBeDefined();
    }));

  });
});