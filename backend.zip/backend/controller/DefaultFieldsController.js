var DefaultFieldsService = require('../service/DefaultFieldsService');


//create default field in DefaultFields table
module.exports.createField = (req,res) => {
    var fields = req.body;
 
    DefaultFieldsService.createField(fields, function(data, err){
        if(err){
            res.status(500).send(err);
        }else{
            res.status(200).send(data);
        }
    })
}

//get AllFields
module.exports.getAllFields = (req,res) => {
 
    DefaultFieldsService.getAllFields(function(data, err){
        if(err){
            res.status(500).send(err);
        }else{
            res.status(200).send(data);
        }
    })
}
