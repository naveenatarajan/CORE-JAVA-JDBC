var MasterListService = require('../service/MasterListService');


module.exports.addlist = (req, res) => {
    var masterllistdata = req.body;

    MasterListService.addlist(masterllistdata, function (masterllistdata, err) {

        if (err) {
            res.status(500).send(err);
        } else {
            res.status(201).send(masterllistdata);
        }
    })
}

module.exports.getalllist = (req, res) => {

    MasterListService.getalllist(function (masterdetail, err) {

        if (err) {
            res.status(500).send(err);
        } else {
            res.status(200).send(masterdetail);
        }
    })

}

module.exports.updatemasterlist = (req, res) => {
    var details = req.body;
    var id = details._id;
    var listdetails = {
        description: details.description,
        title: details.title,
        listId: details.listId,
        updatedby: details.updatedby,
        updatedate: details.updatedate,
    }
    MasterListService.updatealllist(id, listdetails, function (err, listdetails) {
        if (err) {
            res.status(500).send(err);
        } else {
            res.status(200).send(listdetails);
        }
    })
}

module.exports.deletealllist = (req, res) => {
    var id = req.params.id
    MasterListService.deletealllist(id, function (data, err) {
        if (err) {
            res.status(500).send(err);
        } else {
            res.status(200).send(data);
        }
    });
}