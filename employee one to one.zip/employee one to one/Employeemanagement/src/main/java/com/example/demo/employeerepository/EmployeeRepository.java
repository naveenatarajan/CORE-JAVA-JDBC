package com.example.demo.employeerepository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.employeerecord.EmployeeRecord;

@Repository
public interface EmployeeRepository extends JpaRepository<EmployeeRecord, Long> {
	
}
