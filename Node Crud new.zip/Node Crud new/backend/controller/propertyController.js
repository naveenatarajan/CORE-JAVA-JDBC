var propertyService = require('../service/propertyService');

module.exports.insert_property = (req, res) => {
    var property = req.body;
    propertyService.insert_property(property, function (err, response) {
        if (err) {
            res.status(500).send(err);
        } else {
            res.status(201).send(response);
        }
    });
}

module.exports.getproperty = (req, res) => {

    propertyService.listofproperty(function (propertylist, err) {
        if (err) {
            res.status(500).send(err);
        } else {
            res.status(200).send(propertylist);
        }

    });
}
module.exports.updateproperty = (req, res) => {

    var details = req.body;
    var id = details.id;
    var property_key = details.property_key;
    var address = details.address;
    var postal_code = details.postal_code;
    var list_price = details.list_price;
    var sq_ft_header = details.sq_ft_header;
    var sub_division_name = details.sub_division_name;
    var water_frontage = details.water_frontage;
    var year = details.year;
    var county = details.county;
    var user_action = details.user_action;
    var historical_high_sold_price_per_sq_ft = details.historical_high_sold_price_per_sq_ft;
    var notes = details.notes;
    var legalDescription = details.legalDescription;
    var taxId = details.taxId;
    var updated_by = details.updated_by;

    propertyService.updateproperty(id, property_key, address, postal_code, list_price, sq_ft_header, sub_division_name, water_frontage, year, county, user_action, historical_high_sold_price_per_sq_ft, legalDescription, taxId, updated_by, function (err, data) {
        if (err) {
            res.status(500).send(err);
        } else {
            res.status(200).send(data);
        }
    })

}

module.exports.deleteproperty = (req,res) => {

    var id = req.params._id

    propertyService.deleteproperties (id, function(err,data){
        console.log("id----------------------->>>>>>>>>>>",id);
        if(err){
            res.status(500).send(err);
        }else{
            res.status(200).send(data);
        }
    });
}



module.exports.get_by_city_zip = (req, res) => {
    var city = req.query.city;
    var zip = req.query.zip;
    propertyService.get_by_city_zip(city, zip, function (err, response) {
        // res.status(201).send(response);
        if (err) {
            res.status(500).send(err);
        } else {
            res.status(201).send(response);
        }
    })
}


//search property 
module.exports.searchproperty = (req, res)=>{
    var id = req.param('id');
     propertyService.searchproperty(id, function (data,err){
        if(err){
            res.status(500).send(err);
        } else{
          
            res.status(200).send(data)
        }
    })
}
//get postalcode by city
module.exports.getpostalbycity = (req, res)=>{
    var city = req.param('city');
    propertyService.getpostalbycity(city, function (data,err){
        if(err){
            res.status(500).send(err);
        } else{
            var postalCode = {
                value : data[0].postal_code
            };
            res.status(200).send(postalCode)
            
        }
    })
}

//find property by view
module.exports.viewedProperty = (req, res) => {
    var views = req.params.View;
    console.log("propertyyyyyyyyyyyyyyyyyyyyyy",views)
    propertyService.viewedProperty(views, function(data, err){
        if(err) {
            res.status(500).send(err);
        } else {
            console.log("daaaaaaaaaaaaaaaaaaaaaaaaa",data);
         res.status(200).send(data);
        }
    })
}



//find property by address
module.exports.getByAddress = (req, res) => {
    var address = req.params.address;
    console.log("propertyyyyyyyyyyyyyyyyyyyyyy",views)
    propertyService.getByAddress(address, function(data, err){
        if(err) {
            res.status(500).send(err);
        } else {
            console.log("daaaaaaaaaaaaaaaaaaaaaaaaa",data);
         res.status(200).send(data);
        }
    })
}
