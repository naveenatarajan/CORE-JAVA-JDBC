'use strict';

module.exports = function(sequelize, DataTypes) {
  var Tables = sequelize.define("WorkOrder", {
    id: {
    	type : DataTypes.INTEGER,
    	primaryKey : true,
    	autoIncrement : true
    },
    WorkOrderNumber: DataTypes.STRING,
    SalesOrderNumber: DataTypes.STRING,
    SalesOrderLine:DataTypes.INTEGER,
    CustomerName:DataTypes.STRING,
    CustomerNumber:DataTypes.STRING,
    // DueDate:DataTypes.DATE.now(),
    PartNumber:DataTypes.STRING,
    PartDescription:DataTypes.STRING,
    Quantity:DataTypes.DOUBLE,
    Completed:DataTypes.DOUBLE,
    // Updated:DataTypes.DATETIME,
    WorkOrderStatusId:DataTypes.INTEGER
  },{
    createdAt: false,
    updatedAt: false,
    freezeTableName:true
  });
  return Tables;
};