var express = require('express');
var apiRouter = express.Router();
var CityController = require('../../controller/CityController');

apiRouter.post('/addzipcode',CityController.addZipCode);
apiRouter.get('/listofstates',CityController.getListOfState);
apiRouter.get('/listofcities',CityController.getListOfCities);
apiRouter.get('/listofcities_by_state',CityController.getCitiesByState);
apiRouter.get('/getpostalbycity/:city',CityController.getPostalCodeByCity);
apiRouter.delete('/deletezipcode/:postalCode',CityController.deletePostalCode);
apiRouter.get('/getCityCount',CityController.getCityCount);

module.exports = apiRouter;