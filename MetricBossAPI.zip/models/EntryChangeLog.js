'use strict';

module.exports = function (sequelize, DataTypes) {
  var Tables = sequelize.define("Entry.ChangeLog", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    Revision: {
      type: DataTypes.INTEGER,
      primaryKey: true,
    },
    TimeCardId: DataTypes.INTEGER,
    EntryTypeId: DataTypes.INTEGER,
    PaidTime: DataTypes.INTEGER,
    BillableTime: DataTypes.INTEGER,
    RefId: DataTypes.INTEGER,
    Completed: DataTypes.DOUBLE,
    Notes: DataTypes.STRING,
    EntryStatusId: DataTypes.INTEGER,
    Deleted: DataTypes.INTEGER,
    UpdatedBy: DataTypes.STRING,
    UpdatedFromIp: DataTypes.STRING,
    Action: DataTypes.STRING,
    EntryId: DataTypes.INTEGER
  }, {
      createdAt: false,
      updatedAt: false,
      freezeTableName: true
    });
  return Tables;
};