'use strict';

module.exports = function(sequelize, DataTypes) {
  var Tables = sequelize.define("TimeCard", {
    id: {
    	type : DataTypes.INTEGER,
    	primaryKey : true,
    	autoIncrement : true
    },
    Deleted: DataTypes.INTEGER,
    UpdatedFromIp: DataTypes.STRING,
    UpdatedBy: DataTypes.STRING,
    EmployeeId:DataTypes.INTEGER,
    TimeCardStatusId:DataTypes.INTEGER,
  },{
    createdAt: false,
    updatedAt: false,
    freezeTableName:true
  });
  return Tables;
};