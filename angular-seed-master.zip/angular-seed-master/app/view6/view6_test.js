'use strict';

describe('myApp.view6 module', function() {

  beforeEach(module('myApp.view6'));

  describe('view6 controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view6Ctrl = $controller('View6Ctrl');
      expect(view6Ctrl).toBeDefined();
    }));

  });
});