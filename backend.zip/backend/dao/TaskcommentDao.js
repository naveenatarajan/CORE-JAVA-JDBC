var Taskcomment = require('../model/TaskComment');

module.exports.createcomment = (createcomment,callback) => {
    var taskcomment = new Taskcomment(createcomment);
    taskcomment.save (function (data,err){

        if(err){
            callback(err);
        }else{
            callback(data);
        }
    });

}

module.exports.getalltask = (callback) => {

    Taskcomment.find(function(data,err){
        if(err){
            callback(err);
        }else{
            callback(data);
        }

    });
}