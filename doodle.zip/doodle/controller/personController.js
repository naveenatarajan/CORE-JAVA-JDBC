var personService = require('../service/personService')


module.exports.postPerson =  (req, res) => {
    var personData = req.body;
    personService.postPerson(personData, function(err, result){
        if(err){
            res.status(400).send(err)
        } else{
            res.status(200).send(result)
        }
    })
}