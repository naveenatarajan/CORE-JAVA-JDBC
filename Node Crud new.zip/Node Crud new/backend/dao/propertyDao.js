var Property = require('../model/Property');


//Insert a property
module.exports.insert_property = (data, callback) => {
    var propertyData = new Property(data);
    propertyData.save(function (data, err) {
        if (err) {
            callback(err);
        } else {
            console.log('Property inserted.', data);
            callback(data);
        }
    });
}

module.exports.propertylist = (callback) => {

    Property.find(function (data, err) {

        if (err) {
            callback(err);
        } else {
            callback(data);
        }
    });
}

module.exports.updateproperty = (id, property_key, address, postal_code, list_price, sq_ft_header, sub_division_name, water_frontage, year, county, user_action, historical_high_sold_price_per_sq_ft, legalDescription, taxId, updated_by, callback) => {

    Property.findOneAndUpdate({ id }, { property_key, address, postal_code, list_price, sq_ft_header, sub_division_name, water_frontage, year, county, user_action, historical_high_sold_price_per_sq_ft, legalDescription, taxId, updated_by }, function (err, data) {
        if (err) {
            callback(err);
        } else {
            callback(data);
        }
    });
}

module.exports.deleteproperty = (id, callback) => {

    Property.deleteOne({ id: id }, function (err, data) {
        if (err) {
            callback(err);
        } else {
            callback(data);
        }
    });

}

//get all properties
module.exports.get_by_city_zip = (city, zipcode, callback) => {
    Property.find({ 'city': city, 'postal_code': zipcode }, function (err, response) {
        console.log("Custom query:", response);
        if (err) {
            callback(err);
        } else {
            callback(null, response);
        }
    });
}

//search property
module.exports.searchproperty = function(id, callback){
    Property.find({_id: id}, function(err, data){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}


//get postalcode by city
module.exports.getpostalbycity = (city, callback) => {

    Property.find({ city:city}, function(postal_code, err){
        if(err){
            callback(err);
        }
        else{

            callback(postal_code);
            
        }
    })
}

//find property by view
module.exports.getByAddress = (address, callback) => {
    Property.findOne({_address:address},function (err, data) {
        if(err){
            callback(err);
            console.log("eeeeerrrrrrrr",err)
        }else{
            console.log("dataaaeeeeeeeeeeeeeeeeeeeee",data)
            callback(data);
        }
    })
}


