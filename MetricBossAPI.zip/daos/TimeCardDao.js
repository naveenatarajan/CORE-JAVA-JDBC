var models = require("../models");
var sequelize = models.sequelize;
var PropertiesReader = require('properties-reader');
var timeCardDao = require("../daos/TimeCard.ChangeLogDao")
var moment = require('moment');
var sqlQuery = PropertiesReader(__dirname + '/../sql_queries/TimeCard_SQL.properties');
var sqlQueryEntry = PropertiesReader(__dirname + '/../sql_queries/Entry_SQL.properties');

module.exports.create_Tables = function (Tables, callback) {

  var check_employee = sqlQuery._properties.check_employee;

  var firstDate = moment(new Date()).format('YYYY-MM-DD');
  var secondDate = moment(new Date()).add(1, 'days').format("YYYY-MM-DD");

  sequelize.query(check_employee, {
    replacements: {
      EmployeeId: Tables.EmployeeId,
      start_date: firstDate,
      end_date: secondDate,
    },
    type: sequelize.QueryTypes.SELECT,
    model: models.Tables
  }).then(function (tables) {

    if (tables.length == 0) {
      var create_query = sqlQuery._properties.create_Tables;
      sequelize.query(create_query, {
        replacements: {
          Deleted: Tables.Deleted,
          UpdatedFromIp: Tables.UpdatedFromIp,
          UpdatedBy: Tables.UpdatedBy,
          EmployeeId: Tables.EmployeeId,
          TimeCardStatusId: Tables.TimeCardStatusId,
        },
        type: sequelize.QueryTypes.INSERT,
        model: models.Tables
      }).then(function (tables) {
        Tables.Revision = 1;
        Tables.Action = "CREATE";
        Tables.TimeCardId = tables;
        Tables.Out = null;
        timeCardDao.create_Tables(Tables, function (TimeCardLogId) {
          var object = { Success: true, data: tables }
          callback(object);
        });
      });

    } else {
      var object = { Success: false, Error: "Employee already Found" }
      callback(object);
    }

  });
}

module.exports.UpdateOutTime = function (Tables, callback) {

  var firstDate = moment(new Date()).format('YYYY-MM-DD');
  var secondDate = moment(new Date()).add(1, 'days').format("YYYY-MM-DD");

  var update_query = sqlQuery._properties.update_out_time;
  sequelize.query(update_query, {
    replacements: {
      timeCardId: Tables.timeCardId,
      Out: new Date(),
      firstDate: firstDate,
      secondDate: secondDate
    },
    type: sequelize.QueryTypes.UPDATE,
    model: models.Tables
  }).then(function (tables) {
    var get_By_timecard_id = sqlQuery._properties.search_for_update_Tables;
    sequelize.query(get_By_timecard_id, {
      replacements: {
        id: Tables.timeCardId,
        firstDate: firstDate,
        secondDate: secondDate
      },
      type: sequelize.QueryTypes.SELECT,
      model: models.Tables
    }).then(function (get_timecard_id) {

      //updating out time in entry with rescpect to time card

      var update_entry_with_out_time = sqlQuery._properties.update_entry_with_out_time;
      sequelize.query(update_entry_with_out_time, {
        replacements: {
          time_card_id: get_timecard_id[0].Id,
          Out: new Date()
        },
        type: sequelize.QueryTypes.BULKUPDATE,
        model: models.Tables
      }).then(function (tables) {


        //here is for updating timecard log when we update outtime

        console.log("executing ehere")
        console.log("---->get_timecard_id", get_timecard_id)
        get_timecard_id[0].Revision = 1;
        get_timecard_id[0].Action = "OUT_TIME_UPDATED";
        get_timecard_id[0].TimeCardId = get_timecard_id[0].Id;
        get_timecard_id[0].Out = new Date();

        timeCardDao.create_Tables(get_timecard_id[0], function (TimeCardLogId) {
          var object = { Success: true }
          callback(object);
        });

        //var obj = { status: true }
        //callback(obj)
      });
    });
  });
}



module.exports.update_Tables = function (Tables, callback) {
  var update_query = sqlQuery._properties.update_Tables;
  sequelize.query(update_query, {
    replacements: {
      id: Tables.id,
      Deleted: Tables.Deleted,
      UpdatedFromIp: Tables.UpdatedFromIp,
      UpdatedBy: Tables.UpdatedBy,
      EmployeeId: Tables.EmployeeId,
      TimeCardStatusId: Tables.TimeCardStatusId,
    },
    type: sequelize.QueryTypes.BULKUPDATE,
    model: models.Tables
  }).then(function (tables) {

    Tables.Revision = 1;
    Tables.Action = "UPDATE";
    Tables.TimeCardId = Tables.id;
    Tables.Out = null;


    timeCardDao.create_Tables(Tables, function (TimeCardLogId) {
      var object = { Success: true, data: tables }
      callback(object);
    });

  });
}


module.exports.search_Tables_for_update = function (Tables_id, callback) {
    
  var search_for_update_query = sqlQuery._properties.search_for_update_Tables;
  
  sequelize.query(search_for_update_query, {
    replacements: {
      id: Tables_id 
    },
    type: sequelize.QueryTypes.SELECT,
    model: models.Tables
  }).then(function (tables) {
    console.log("response from db====>",tables[0]);
    tables[0].In = moment.utc(tables[0].In).format('YYYY-MM-DD HH:mm:ss');
    tables[0].Out = moment.utc(tables[0].Out).format('YYYY-MM-DD HH:mm:ss');
    callback(tables[0]);
  });
}


module.exports.search_by_params = function (req, callback) {
  
 var employee_id, In, Out, time_card_status;

  if(req.param('EmployeeId') == undefined){
   employee_id = null;
 }else{
   employee_id = req.param('EmployeeId');
  
 }
//  console.log("employeee ====>>>>>>>",req.params.EmployeeId)
  if(req.param('In') == undefined){
   In = null;
 }else{
   In = req.param('In');
 }

  if(req.param('Out') == undefined){
   Out = null;
 }else{
   Out = req.param('Out');
 }

  if(req.param('TimeCardStatus') == undefined){
   time_card_status = null;
 }else{
   time_card_status = req.param('TimeCardStatus');
 }

 //  if(req.params.EmployeeNumber == undefined){
 //   employee_number = null;
 // }else{
 //   employee_number = req.params.EmployeeNumber;
 // }

 //  if(req.params.OrganizationUnitId == undefined){
 //   organization_unit_id = null;
 // }else{
 //   organization_unit_id = req.params.OrganizationUnitId;
 // }

 var search_by_params = sqlQuery._properties.search_by_params_query;
 
 sequelize.query(search_by_params, {
   replacements: {

     EmployeeId: employee_id,
     Out: Out,
     In: In,
     TimeCardStatus: time_card_status
     // EmployeeNumber: employee_number,
     // OrganizationUnitId: organization_unit_id 
   },
   type: sequelize.QueryTypes.SELECT,
   model: models.Tables
 }).then(function (tables) {
   console.log("response from db====>",tables[0]);
   tables[0].In = moment.utc(tables[0].In).format('YYYY-MM-DD HH:mm:ss');
   tables[0].Out = moment.utc(tables[0].Out).format('YYYY-MM-DD HH:mm:ss');
   callback(tables[0]);
 });
}


module.exports.delete_Tables = function (Tables_id, callback) {
  exports.search_Tables_for_update(Tables_id, function (selected_data) {
    //console.log("able", tables)
    var delete_query = sqlQuery._properties.delete_Tables;
    sequelize.query(delete_query, {
      replacements: {
        id: Tables_id
      },
      type: sequelize.QueryTypes.DELETE,
      model: models.Tables
    }).then(function () {
      console.log("selected data", selected_data)
      selected_data.Revision = 1;
      selected_data.Action = "DELETE";
      Tables.Out = new Date();
      selected_data.TimeCardId = selected_data.Id
      timeCardDao.create_Tables(selected_data, function (TimeCardLogId) {
        var object = { Success: true }
        callback(object);
      });
    });
  });
}

module.exports.get_all_Tables = function (callback) {
  var get_all_query = sqlQuery._properties.get_all_Tables;
  sequelize.query(get_all_query, {
    type: sequelize.QueryTypes.SELECT,
    model: models.Tables
  }).then(function (tables) {
    callback(tables);
  });
}