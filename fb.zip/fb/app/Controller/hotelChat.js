
// var request = require('request');
// var moment = require('moment');
// var accountSid = 'AC273fe799ac5d6af28239e657c3457f80';
// var authToken = '1bf72c4bb389d44d3cbd0de4acc2e73c';
// var twilio = require('twilio');

// var client = new twilio(accountSid, authToken);
// var MessagingResponse = require('twilio').twiml.MessagingResponse;
// var twiml = new MessagingResponse();

// const questions = [
//     { keyword: 'What is the checkout time?', value: '12:00am', fx: checkoutTime },
//     { keyword: 'checkout time', value: '12:00am', fx: checkoutTime },
//     { keyword: 'What is the WiFi password?', value: 'Venuelytics', fx: wifiPassword },
//     { keyword: 'WiFi password', value: 'Venuelytics', fx: wifiPassword },
//     { keyword: 'Breakfast time', value: '08:00am', fx: breakfastTime },
//     { keyword: 'Do you have Ironing Boards?', value: 'yes', fx: ironingBoards },
//     { keyword: 'Do you have iPhone charger?', value: 'yes', fx: iPhoneCharger },
//     { keyword: 'what are the Deals?', value: 'No Deals', fx: listDeals },
//     { keyword: 'what are the Events?', value: 'Corporate Event, Birthday Party, Wedding, Bachelorette Party, Reception, Charity Event', fx: listEvents },
//     { keyword: 'Bottle Service', value: 'vodka, whisky, brandy, Tequila', fx: bottleService },
//     { keyword: 'Do you want to extend the checkout time?', value: 'yes', fx: extendCheckoutTime },
//     { keyword: 'How would you rate our service (between 1-5)?', value: '5', fx: ratingService },
//     { keyword: 'Gym Hours', value: 'Mor- 5:00am to 7:00am and Eve- 5:00pm to 7:00pm', fx: gymHours },
//     { keyword: 'Restaurant Close Time', value: '11:00pm', fx: closeTime },
//     { keyword: 'Do you want to charged in the same credit card?', value: 'yes', fx: paymentCredit },
//     { keyword: 'List the food items?', value: 'Pizza, HotDog, Fast Food', fx: listFoodItems }
// ];

// module.exports.setwebhook = function (req, res) {
//     var body = req.query.Body;
//     var number = req.query.From;
//     var twilioNumber = req.query.To;
// };

// module.exports.getwebhook = function (req, res) {
//     var message = req.query.Body;
//     var number = req.query.From;
//     var twilioNumber = req.query.To;

//     for (var i = 0; i < questions.length; i++) {
//         if (message.toLowerCase() === questions[i].keyword.toLowerCase()) {
//             questions[i].fx(questions[i].value);
//         }
//     }

//     if ((message === 'hello') || (message === 'hai') || (message === 'hi')) {
//         cbTwlMsg(message + '! Welcome to our Guest Services! How can I help you with your requests?');
//     }
// }

// function checkoutTime(value) {
//     cbTwlMsg(value);
// }

// function wifiPassword(value) {
//     cbTwlMsg(value);
// }

// function extendCheckoutTime(value) {
//     cbTwlMsg(value);
// }

// function ratingService(value) {
//     cbTwlMsg(value);
// }

// function breakfastTime(value) {
//     cbTwlMsg(value);
// }

// function ironingBoards(value) {
//     cbTwlMsg(value);
// }

// function iPhoneCharger(value) {
//     cbTwlMsg(value);
// }

// function listDeals(value) {
//     cbTwlMsg(value);
// }

// function listEvents(value) {
//     cbTwlMsg(value);
// }

// function bottleService(value) {
//     cbTwlMsg(value);
// }

// function paymentCredit(value) {
//     cbTwlMsg(value);
// }

// function listFoodItems(value) {
//     cbTwlMsg(value);
// }

// function closeTime(value) {
//     cbTwlMsg(value);
// }


// function gymHours(value) {
//     cbTwlMsg(value);
// }

// var cbTwlMsg = function (value) {
//     client.messages.create({
//         from: '+19042049724',
//         to: '+19252403172',
//         body: value
//     }, function (err, message) {
//         if (err) {
//             console.error(err.message);
//         }
//     });
// };