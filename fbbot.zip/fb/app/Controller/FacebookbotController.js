/**
 * Modified: December 2017
 * @author khalisaran
 */
var request = require('request');
var moment = require('moment');

var accountSid = 'AC9d98576b667ee9ccfcc7d6dc0a21f519';
var authToken = 'a8ba0133cb82a480ffdcc0ced1895011';
//var fromNumber = '+14436489694';
var twilio = require('twilio');
var client = new twilio(accountSid, authToken);

let VERIFY_TOKEN = "EAAWQ31ROoaUBAAuGHO1RZBfDipAvmkGCpZAnUILvdj4kHa9XS3IU6rlmOTuyoIh4RpwWZAJAyOpxgcykgbD4IEDMYFid700BqfXT56GczTjXXZApGCI8lFftJZBK6oVhZAUBZBAtPdGuFeJuDA497AHZCcaEHeThKw6GFVWLSTbqQgZDZD"

var listOfVenues = [];
var venueNumber = '';
var element = [];
var tableId = '';
var venue = false;
var table = false;
var tablevenue = false;
var venueId = '';
var guest = false;
var date = false;
var phone = false;
var mobilenumber = '';
var venueDate = '';
var userDate = '';

//const LookupsClient = require('twilio').LookupsClient;
//const client = new LookupsClient(accountSid, authToken);
//var phoneNumber = process.argv[2];

// client.phoneNumbers('+14436489694').get((error, number) => {
//   console.log(number.national_format);
//   console.log(number.country_code);

//   // This will sometimes be null
//   console.log(number.caller_name);
// });

// client.phoneNumbers(phoneNumber).get({
//   type: 'carrier'
// }, (error, number) => {
//   let message = number ? number.national_format + ' is valid' : error;
//   if (error && error.status === 404) {
//     message = 'Invalid phone number';
//   }
//   console.log(message);
// });

module.exports.getwebhook = function (req, res) {

  let mode = req.query['hub.mode'];
  let token = req.query['hub.verify_token'];
  let challenge = req.query['hub.challenge'];
  if (mode && token) {
    if (mode === 'subscribe' && token === VERIFY_TOKEN) {
      console.log('WEBHOOK_VERIFIED');
      res.status(200).send(challenge);
    } else {
      res.sendStatus(403);
    }
  }
}

module.exports.setwebhook = function (req, res) {
  let body = req.body;
  console.log("the data ---->" + JSON.stringify(body))
  if (body.object === 'page') {
    body.entry.forEach(function (entry) {
      let webhookEvent = entry.messaging[0];
      console.log(webhookEvent);
      if (webhookEvent.message && webhookEvent.message.text) {
        text = webhookEvent.message.text;
        replyToSender(webhookEvent.sender.id, text);
      } else if (webhookEvent.postback && webhookEvent.postback.payload) {
        payload = webhookEvent.postback.payload;
        console.log("at webhook----payload", payload)
        replyToSender(webhookEvent.sender.id, payload);
      }
    });
    res.status(200).send('EVENT_RECEIVED');
  } else {
    res.sendStatus(404);
  }
}

function replyToSender(sender, message) {
  let messageData;

  if ((message.toLowerCase() === 'hai') || (message.toLowerCase() === 'hi') || (message.toLowerCase() === 'hello')) {
    messageData = {
      "attachment": {
        "type": "template",
        "payload": {
          "template_type": "generic",
          "elements": [{
            "title": "Welcome to VenueLytics!",
            "image_url": "http://www.venuelytics.com/assets/img/2.jpg",
            "buttons": [
              {
                "type": "postback",
                "title": "Book Table Service",
                "payload": "BottleService"
              },
              // {
              //   "type": "postback",
              //   "title": "Dining Service",
              //   "payload": "DiningService",
              // },
              // {
              //   "type": "postback",
              //   "title": "Book Private Events",
              //   "payload": "PrivateEvents",
              // },
              // {
              //   "type": "postback",
              //   "title": "Guest List",
              //   "payload": "GuestList",
              // },
              {
                "type": "web_url",
                "title": "Other Services",
                "url": "http://www.venuelytics.com/home",
              }
            ]
          }]
        }
      }
    }
  } else if (message === 'BottleService') {
    venue = true
    messageData = {
      text: "Please enter the venue name to book"
    }
  }
  // else if (message === 'DiningService') {
  //   venue = true
  //   messageData = {
  //     text: "Enter the Dining Service to Book"
  //   }
  // }
  // else if (message === 'PrivateEvents') {
  //   venue = true
  //   messageData = {
  //     text: "Enter the Private Events to Book"
  //   }
  // }
  // else if (message === 'GuestList') {
  //   venue = true
  //   messageData = {
  //     text: "Enter the Guest List to Book"
  //   }
  // } 
  else if (table) {
    table = false;
    tablevenue = true;
    venueDate = moment(userDate).format('YYYYMMDD');
    console.log('venueDate------>',venueDate);
    request.get(getAllTableApi(venueId), function (error, response, body) {
      var result = JSON.parse(body);
      var count = 0;
      request.get(getReserveTableApi(venueId, venueDate), function (reserveError, reserveResponse, reserveBody) {
        var reserve = JSON.parse(reserveBody);
        if (result) {
          if (reserve.length !== 0) {
            for (var k = 0; k < reserve.length; k++) {
              var found = false;
              for (var j = 0; j < result[0].elements.length; j++) {
                if (result[0].elements[j].id === reserve[k].productId) {
                  // var object = {
                  //   "title": result[0].elements[j].name,
                  //   "image_url": result[0].elements[j].imageUrls[0].smallUrl,
                  //   "buttons": [
                  //     {
                  //       "type": "postback",
                  //       "title": "Reserve",
                  //       "payload": result[0].elements[j].id,
                  //     }
                  //   ]
                  // }
                  result[0].elements.splice(j, 1);
                  count++;
                  found = true;
                  break;
                  if (found == false) {

                  }
                }
              }
            }
            for (var z = 0; z < result[0].elements.length; z++) {
              var object = {
                "title": result[0].elements[z].name,
                "image_url": result[0].elements[z].imageUrls[0].smallUrl,
                "buttons": [
                  {
                    "type": "postback",
                    "title": "Reserve",
                    "payload": result[0].elements[z].id + " - Table Name : " + result[0].elements[z].name,
                  }
                ]
              }
              element.push(object);
            }
          } else {
            for (var j = 0; j < result[0].elements.length; j++) {
              var object = {
                "title": result[0].elements[j].name,
                "image_url": result[0].elements[j].imageUrls[0].smallUrl,
                "buttons": [
                  {
                    "type": "postback",
                    "title": "Reserve",
                    "payload": result[0].elements[j].id + " - Table Name : " + result[0].elements[j].name,
                  }
                ]
              }
              element.push(object);
            }
          }
          messageData = {
            "attachment": {
              "type": "template",
              "payload": {
                "template_type": "generic",
                "elements": element.slice(0, 9)
              }
            }
          }
          request({
            url: 'https://graph.facebook.com/v2.6/me/messages',
            qs: { access_token: VERIFY_TOKEN },
            method: 'POST',
            json: {
              recipient: { id: sender },
              message: messageData,
            }
          }, function (error, response, body) {
            if (error) {
              console.log('Error sending message: ', error);
            } else if (response.body.error) {
              console.log('Error: ', response.body.error);
            }
          });
        }
      })
    })
  } else if (venue) {

    venue = false;
    date = true;
    console.log("the venue table state --->", table, venue)
    venuename = message;
    request.get(searchrelatedvenue(venuename), function (error, response, body) {
      var result = JSON.parse(body)
      var count = 0;
      if (result) {
        for (var i = 0; i < result.venues.length; i++) {
          venueId = result.venues[i].id;
          var object = {
            "title": result.venues[i].venueName,
            "image_url": "http://franciza.ro/sites/default/files/styles/cover_photo/public/categories/images/restaurants.jpg?itok=Qw5AcmHU&timestamp=1447161272",
            "buttons": [
              {
                "type": "postback",
                "title": "Select Venue",
                "payload": result.venues[i].id,
              }
            ]
          }
          listOfVenues.push(object);
          count++;
        }

      }
      if (count === result.venues.length) {
        console.log("the listofvenues ---->", listOfVenues)
        console.log("inside sending reply")
        messageData = {
          "attachment": {
            "type": "template",
            "payload": {
              "template_type": "generic",
              "elements": listOfVenues
            }
          }
        }
        request({
          url: 'https://graph.facebook.com/v2.6/me/messages',
          qs: { access_token: VERIFY_TOKEN },
          method: 'POST',
          json: {
            recipient: { id: sender },
            message: messageData,
          }
        }, function (error, response, body) {
          if (error) {
            console.log('Error sending message: ', error);
          } else if (response.body.error) {
            console.log('Error: ', response.body.error);
          }
        });
      } else {
        messageData = {
          text: "sorry there is no venue in this name"
        }
        request({
          url: 'https://graph.facebook.com/v2.6/me/messages',
          qs: { access_token: VERIFY_TOKEN },
          method: 'POST',
          json: {
            recipient: { id: sender },
            message: messageData,
          }
        }, function (error, response, body) {
          if (error) {
            console.log('Error sending message: ', error);
          } else if (response.body.error) {
            console.log('Error: ', response.body.error);
          }
        });
      }
    })
  } else if (date) {
    date = false;
    phone = true;
    messageData = {
      text: " Enter the reservation date MM/DD/YYYY "
    }
  } else if (phone) {
    phone = false;
    guest = true;
    userDate = message;
    messageData = {
      text: " Enter your mobile number "
    }
  } else if (guest) {
    table = true;
    guest = false;
    mobilenumber = message;
    messageData = {
      text: " Enter the number of guests "
    }
  } else if (tablevenue) {
    tablevenue = false;
    var selectedtable = message
    request.post(bookYourOrder(selectedtable, venueId), function (error, response, body) {
      var result = JSON.parse(body)
      if (result) {
        messageData = {
          text: " Table Booked successfully "
        }
        if (messageData.text) {
          client.messages.create({
            body: 'Table Booked successfully : ' + selectedtable,
            to: '+918682846138',  // Text this number
            from: '+14436489694 ' // From a valid Twilio number
          })
            .then((message) => console.log(message.sid));
        }
        request({
          url: 'https://graph.facebook.com/v2.6/me/messages',
          qs: { access_token: VERIFY_TOKEN },
          method: 'POST',
          json: {
            recipient: { id: sender },
            message: messageData,
          }
        }, function (error, response, body) {
          if (error) {
            console.log('Error sending message: ', error);
          } else if (response.body.error) {
            console.log('Error: ', response.body.error);
          }
        });
      }
    })
  }
  request({
    url: 'https://graph.facebook.com/v2.6/me/messages',
    qs: { access_token: VERIFY_TOKEN },
    method: 'POST',
    json: {
      recipient: { id: sender },
      message: messageData,
    }
  }, function (error, response, body) {
    if (error) {
      console.log('Error sending message: ', error);
    } else if (response.body.error) {
      console.log('Error: ', response.body.error);
    }
  });
};

function getAllVenueApi() {
  var options = {
    url: 'http://dev.api.venuelytics.com/WebServices/rsapi/v1//venues'
  };
  return options;
}

function searchrelatedvenue(venuename) {
  var options = {
    url: 'http://dev.api.venuelytics.com/WebServices/rsapi/v1//venues/q?lat=&lng=&dist=20000&search=' + venuename
  };
  return options;
}

function searchvenue(venuename) {
  console.log("the venue name--->", venuename)

}


function getAllVenue() {
  request.get(getAllVenueApi(), function (error, response, body) {
    var result = JSON.parse(body)
    if (result) {
      for (var i = 0; i < result.venues.length; i++) {
        listOfVenues.push(result[i].venues.venueName);
      }
    }
  })
}

// function getAllTable(venueId, venueDate, callback) {
//   request.get(getAllTableApi(venueId,venueDate), function (error, response, body) {
//     var result = JSON.parse(body)
//     if (result) {
//       for (var i = 0; i < result.length; i++) {
//         element.push(result[i].elements);
//       }
//       callback(element)
//     } else {
//       callback("ERROR")
//     }
//   })
// }

function getAllTableApi(venueId) {
  //var token = "dGVzdCB0ZXN0OnRlc3RAZ21haWwuY29tOig4ODgpIDg4OC04ODg4";
  var options = {
    url: 'http://dev.api.venuelytics.com/WebServices/rsapi/v1/venuemap/' + venueId,
    //url: 'http://prod.api.venuelytics.com/WebServices/rsapi/v1/venuemap/' + venueId,
    // headers: {
    //   'Authorization': 'Anonymous ' + token
    // }
  };
  return options;
}


function getReserveTableApi(venueId, venueDate) {
  var token = "dGVzdCB0ZXN0OnRlc3RAZ21haWwuY29tOig4ODgpIDg4OC04ODg4";
  var reserve = {
    url: 'http://dev.api.venuelytics.com/WebServices/rsapi/v1/reservations/' + venueId + '/date/' + venueDate,
    //url: 'http://prod.api.venuelytics.com/WebServices/rsapi/v1/reservations/' + venueId + '/date/' + venueDate,

    headers: {
      'X-XSRF-TOKEN': 'XX-YY-XX-V'
    }
  };
  return reserve;
}


function orderPostJson(tableNumber, callback) {
  request.post(bookYourOrder(tableNumber), function (error, response, body) {
    var result = JSON.parse(body)
    if (result) {
      callback(result)
    } else {
      callback("ERROR")
    }
  })
}

function bookYourOrder(tableNumber, venueId) {
  var ENDPOINT = 'http://dev.api.venuelytics.com/WebServices/rsapi/v1/vas/';
  var token = "dGVzdCB0ZXN0OnRlc3RAZ21haWwuY29tOig4ODgpIDg4OC04ODg4";
  var options = {
    method: 'POST',
    uri: ENDPOINT + venueId + '/orders',
    body: JSON.stringify({
      "serviceType": "Bottle",
      "venueNumber": venueId,
      "reason": "Birthday Party",
      "contactNumber": "(888) 888-8888",
      "contactEmail": "test@gmail.com",
      "contactZipcode": "23987298",
      "noOfGuests": 2,
      "noOfMaleGuests": 0,
      "noOfFemaleGuests": 0,
      "budget": 0,
      "serviceInstructions": "none",
      "status": "REQUEST",
      "fulfillmentDate": Date.now(),
      "durationInMinutes": 0,
      "deliveryType": "Pickup",
      "order": {
        "venueNumber": venueId,
        "orderDate": Date.now(),
        "orderItems": [
          {
            "venueNumber": venueId,
            "productId": tableNumber,
            "productType": "VenueMap",
            "quantity": 5,
            "name": "Table 10A"
          }
        ]
      },
      "prebooking": false,
      "employeeName": "",
      "visitorName": "test test"
    }),
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Anonymous " + token
    }
  };
  return options;
}