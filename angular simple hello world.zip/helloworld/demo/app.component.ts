import { Component } from '@angular/core';  

import { Service } from './app.service';  

@Component({ 
   selector: 'demo-app', 
   template: '<div>{{value}}</div>', 
   providers: [service] 
}) 

export class AppComponent { 
   value: string = ""; 
   constructor(private _Service: appService) { }  
   
   ngOnInit(): void { 
      this.value = this._Service.getApp(); 
   } 
} 