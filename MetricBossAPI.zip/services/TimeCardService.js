var dao = require("../daos/TimeCardDao")
module.exports.create_Tables = function(Tables,callback) {
  dao.create_Tables(Tables,function (tables){
    callback(tables);
  });
}

module.exports.UpdateOutTime = function(Tables,callback) {
  dao.UpdateOutTime(Tables,function (tables){
    callback(tables);
  });
}


module.exports.update_Tables = function(Tables,callback) {
  dao.update_Tables(Tables,function (tables){
    callback(tables);
  });
}
module.exports.search_Tables_for_update = function(Tables_id,callback) {
  console.log("employee_id in service ====>",Tables_id);
  dao.search_Tables_for_update(Tables_id,function (tables){
    callback(tables)
  });
}

module.exports.search_by_params = function(req,callback) {
  // console.log("req in service ====>",req);
  dao.search_by_params(req,function (tables){
    callback(tables)
  });
}

module.exports.delete_Tables = function(Tables_id,callback) {
  dao.delete_Tables(Tables_id,function (){
    callback();
  });
}
module.exports.get_all_Tables = function(callback) {
  dao.get_all_Tables(function (list_of_tables){
    callback(list_of_tables)
  });
}