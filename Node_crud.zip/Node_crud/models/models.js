'use strict';

module.exports = function (sequelize, DataTypes) {
  var Tables = sequelize.define("Employee", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    EmployeeName: DataTypes.STRING,
    EmployeeId: DataTypes.INTEGER,
    EmployeeSalary: DataTypes.INTEGER
    
  }, {
      createdAt: false,
      updatedAt: false,
      freezeTableName: true
    });
  return Tables;
};