var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var uniqueValidator = require('mongoose-unique-validator');
var autoIncrement = require('mongoose-auto-increment');
var Binary = require('mongodb').Binary,
    ObjectID = require('mongodb').ObjectID,
    Code = require('mongodb').Code
  

var fileSchema = new Schema({
    id:{type:Number},
    userId:{type:Number, required:true},
    property:{type:String, default:null},
    file_name:{type:String, default:null},
    file:{type:Buffer, default:null}
},{
    versionKey:false
});
autoIncrement.initialize(mongoose);

fileSchema.plugin(uniqueValidator);

fileSchema.plugin(autoIncrement.plugin,{model:'file' , startAt:1});
var FileDetails = mongoose.model('file', fileSchema, 'File');

module.exports = FileDetails;