package com.example.demo.employeerepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.employeerecord.EmployeeRecordDetail;

@Repository
public interface EmployeeRepositoryDetail extends JpaRepository<EmployeeRecordDetail, Long> {
	
	void deleteById(long id);

	public  List<EmployeeRecordDetail> findById(long id);
	
}
