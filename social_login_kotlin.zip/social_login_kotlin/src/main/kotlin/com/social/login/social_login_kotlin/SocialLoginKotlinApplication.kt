package com.social.login.social_login_kotlin

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SocialLoginKotlinApplication

fun main(args: Array<String>) {
    runApplication<SocialLoginKotlinApplication>(*args)
}
