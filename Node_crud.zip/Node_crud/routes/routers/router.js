var express = require("express");
var router = express.Router();
var controller = require("../../controller")
router.post("", controller.create_Tables);
router.put("", controller.update_Tables);
router.delete("/:id", controller.delete_Tables);
router.get("", controller.get_all_Tables);

module.exports = router;