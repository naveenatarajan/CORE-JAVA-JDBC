'use strict';

describe('myApp.view7 module', function() {

  beforeEach(module('myApp.view7'));

  describe('view7 controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view7Ctrl = $controller('View7Ctrl');
      expect(view7Ctrl).toBeDefined();
    }));

  });
});