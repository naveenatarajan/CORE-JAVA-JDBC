var express = require('express');
var apiRouter = express.Router();
var AssignZipcodeController = require('../../controller/AssignZipcodeController');

apiRouter.post('/assign_user',AssignZipcodeController.assignZipcodeToUser);
apiRouter.get('/getassigneduser/:userId',AssignZipcodeController.getAssignedUser);
apiRouter.get('/getusercities/:state/:_id',AssignZipcodeController.getCityForUser);
apiRouter.delete('/remove_assigneduser/:username/:zipcode',AssignZipcodeController.removeAssignedUser);
apiRouter.get('/get_postal_city/:city/:userId',AssignZipcodeController.getPostalCodeForCity);
apiRouter.get('/get_user_postalcode/:state/:city/:id',AssignZipcodeController.getPostalForAssignUser)
apiRouter.get('/getusercitycount',AssignZipcodeController.getUserCityCount);

module.exports = apiRouter;