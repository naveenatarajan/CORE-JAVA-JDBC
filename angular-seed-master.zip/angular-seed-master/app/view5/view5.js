'use strict';

angular.module('myApp.view5', ['ngRoute'])

  .config(['$routeProvider', function ($routeProvider) {
    $routeProvider.when('/view5', {
      templateUrl: 'view5/view5.html',
      controller: 'View5Ctrl'
    });
  }])

  .controller('View5Ctrl', ['$scope', '$interval', function ($scope, $interval) {
    // $scope.salesData = [
    //   { hour: 1, sales: 54 },
    //   { hour: 2, sales: 66 },
    //   { hour: 3, sales: 77 },
    //   { hour: 4, sales: 70 },
    //   { hour: 5, sales: 60 },
    //   { hour: 6, sales: 63 },
    //   { hour: 7, sales: 55 },
    //   { hour: 8, sales: 47 },
    //   { hour: 9, sales: 55 },
    //   { hour: 10, sales: 30 }
    // ];

    // $interval(function () {
    //   var hour = $scope.salesData.length + 1;
    //   var sales = Math.round(Math.random() * 100);
    //   $scope.salesData.push({ hour: hour, sales: sales });
    // }, 1000, 10);



    // $scope.salesData =[
    //   {
    //     "State": "CA",
    //     "Under 5 Years": 2704659,
    //     "5 to 13 Years": 4499890,
    //     "14 to 17 Years": 2159981,
    //     "18 to 24 Years": 3853788,
    //     "25 to 44 Years": 10604510,
    //     "45 to 64 Years": 8819342,
    //     "65 Years and Over": 4114496
    //   },
    //   {
    //     "State": "TX",
    //     "Under 5 Years": 2027307,
    //     "5 to 13 Years": 3277946,
    //     "14 to 17 Years": 1420518,
    //     "18 to 24 Years": 2454721,
    //     "25 to 44 Years": 7017731,
    //     "45 to 64 Years": 5656528,
    //     "65 Years and Over": 2472223
    //   },
    //   {
    //     "State": "NY",
    //     "Under 5 Years": 1208495,
    //     "5 to 13 Years": 2141490,
    //     "14 to 17 Years": 1058031,
    //     "18 to 24 Years": 1999120,
    //     "25 to 44 Years": 5355235,
    //     "45 to 64 Years": 5120254,
    //     "65 Years and Over": 2607672
    //   },
    //   {
    //     "State": "FL",
    //     "Under 5 Years": 1140516,
    //     "5 to 13 Years": 1938695,
    //     "14 to 17 Years": 925060,
    //     "18 to 24 Years": 1607297,
    //     "25 to 44 Years": 4782119,
    //     "45 to 64 Years": 4746856,
    //     "65 Years and Over": 3187797
    //   },
    //   {
    //     "State": "IL",
    //     "Under 5 Years": 894368,
    //     "5 to 13 Years": 1558919,
    //     "14 to 17 Years": 725973,
    //     "18 to 24 Years": 1311479,
    //     "25 to 44 Years": 3596343,
    //     "45 to 64 Years": 3239173,
    //     "65 Years and Over": 1575308
    //   },
    //   {
    //     "State": "PA",
    //     "Under 5 Years": 737462,
    //     "5 to 13 Years": 1345341,
    //     "14 to 17 Years": 679201,
    //     "18 to 24 Years": 1203944,
    //     "25 to 44 Years": 3157759,
    //     "45 to 64 Years": 3414001,
    //     "65 Years and Over": 1910571
    //   }
    // ]
  }])

  // .directive('linearChart', function ($parse, $window) {
  //   return {
  //     restrict: 'EA',
  //     template: "<svg width='850' height='200'></svg>",
  //     link: function (scope, elem, attrs) {
  //       var exp = $parse(attrs.chartData);

  //       var salesDataToPlot = exp(scope);
  //       var padding = 20;
  //       var pathClass = "path";
  //       var xScale, yScale, xAxisGen, yAxisGen, lineFun;

  //       var d3 = $window.d3;
  //       var rawSvg = elem.find('svg');
  //       var svg = d3.select(rawSvg[0]);

  //       scope.$watchCollection(exp, function (newVal, oldVal) {
  //         salesDataToPlot = newVal;
  //         redrawLineChart();
  //       });

  //       function setChartParameters() {

  //         xScale = d3.scale.linear()
  //           .domain([salesDataToPlot[0].hour, salesDataToPlot[salesDataToPlot.length - 1].hour])
  //           .range([padding + 5, rawSvg.attr("width") - padding]);

  //         yScale = d3.scale.linear()
  //           .domain([0, d3.max(salesDataToPlot, function (d) {
  //             return d.sales;
  //           })])
  //           .range([rawSvg.attr("height") - padding, 0]);

  //         xAxisGen = d3.svg.axis()
  //           .scale(xScale)
  //           .orient("bottom")
  //           .ticks(salesDataToPlot.length - 1);

  //         yAxisGen = d3.svg.axis()
  //           .scale(yScale)
  //           .orient("left")
  //           .ticks(5);

  //         lineFun = d3.svg.line()
  //           .x(function (d) {
  //             return xScale(d.hour);
  //           })
  //           .y(function (d) {
  //             return yScale(d.sales);
  //           })
  //           .interpolate("basis");
  //       }

  //       function drawLineChart() {

  //         setChartParameters();

  //         svg.append("svg:g")
  //           .attr("class", "x axis")
  //           .attr("transform", "translate(0,180)")
  //           .call(xAxisGen);

  //         svg.append("svg:g")
  //           .attr("class", "y axis")
  //           .attr("transform", "translate(20,0)")
  //           .call(yAxisGen);

  //         svg.append("svg:path")
  //           .attr({
  //             d: lineFun(salesDataToPlot),
  //             "stroke": "blue",
  //             "stroke-width": 2,
  //             "fill": "none",
  //             "class": pathClass
  //           });
  //       }

  //       function redrawLineChart() {

  //         setChartParameters();

  //         svg.selectAll("g.y.axis").call(yAxisGen);

  //         svg.selectAll("g.x.axis").call(xAxisGen);

  //         svg.selectAll("." + pathClass)
  //           .attr({
  //             d: lineFun(salesDataToPlot)
  //           });
  //       }

  //       drawLineChart();
  //     }
  //   };
  // });

  .directive('d3GroupBars', [
    function () {
      return {
        restrict: 'E',
        template: "<svg width='960' height='500'></svg>",
        link: function (scope, element) {
          console.log("svg++++++++++++++",svg);
          
          var svg = d3.select("svg"),
            margin = { top: 20, right: 20, bottom: 30, left: 40 },
            width = +svg.attr("width") - margin.left - margin.right,
            height = +svg.attr("height") - margin.top - margin.bottom,
            g = svg.append("g").attr("transform", "translate(" + margin.left + "," + margin.top + ")");

          var x0 = d3.scaleBand()
            .rangeRound([0, width])
            .paddingInner(0.1);
             
          var x1 = d3.scaleBand()
            .padding(0.05);
            
          var y = d3.scaleLinear()
            .rangeRound([height, 0]);
            
          var z = d3.scaleOrdinal()
            .range(["#458b74", "#7fff00", "#ff1493", "#6b486b", "#ff3030", "#eec900", "#9bcd9b"]);
            
          d3.csv("view5/data.csv", function (d, i, columns) {
            console.log("columnscolumns",columns);
            console.log("ddddddddddddcolumnscolumns",d);
            console.log("iiiiiiiiiiiiicolumnscolumns",i);
            for (var i = 1, n = columns.length; i < n; ++i) d[columns[i]] = +d[columns[i]];
            return d;
          }, function (error, data) {
            if (error) throw error;
            console.log('datadatadata',data);
            var keys = data.columns.slice(1);
            console.log("keyskeyskeys",keys);
            x0.domain(data.map(function (d) { return d.State; }));
            x1.domain(keys).rangeRound([0, x0.bandwidth()]);
            y.domain([0, d3.max(data, function (d) { return d3.max(keys, function (key) { return d[key]; }); })]).nice();

            g.append("g")
              .selectAll("g")
              .data(data)
              .enter().append("g")
              .attr("transform", function (d) { return "translate(" + x0(d.State) + ",0)"; })
              .selectAll("rect")
              .data(function (d) { return keys.map(function (key) { return { key: key, value: d[key] }; }); })
              .enter().append("rect")
              .attr("x", function (d) { return x1(d.key); })
              .attr("y", function (d) { return y(d.value); })
              .attr("width", x1.bandwidth())
              .attr("height", function (d) { return height - y(d.value); })
              .attr("fill", function (d) { return z(d.key); });

            g.append("g")
              .attr("class", "axis")
              .attr("transform", "translate(0," + height + ")")
              .call(d3.axisBottom(x0));

            g.append("g")
              .attr("class", "axis")
              .call(d3.axisLeft(y).ticks(null, "s"))
              .append("text")
              .attr("x", 2)
              .attr("y", y(y.ticks().pop()) + 0.5)
              .attr("dy", "0.32em")
              .attr("fill", "#000")
              .attr("font-weight", "bold")
              .attr("text-anchor", "start")
              .text("Population");

            var legend = g.append("g")
              .attr("font-family", "sans-serif")
              .attr("font-size", 10)
              .attr("text-anchor", "end")
              .selectAll("g")
              .data(keys.slice().reverse())
              .enter().append("g")
              .attr("transform", function (d, i) { return "translate(0," + i * 20 + ")"; });

            legend.append("rect")
              .attr("x", width - 19)
              .attr("width", 19)
              .attr("height", 19)
              .attr("fill", z);

            legend.append("text")
              .attr("x", width - 24)
              .attr("y", 9.5)
              .attr("dy", "0.32em")
              .text(function (d) { return d; });
          });

        }
      };
    }
  ]); 