module.exports = {
    url: 'https://aerobit.auth0.com/oauth/token',
    headers: { 'content-type': 'application/json' },
    body: '{"client_id":"szw6T6f8WdKbUPzWO7d8cA6J0zyYab05","client_secret":"p5bf1q-1aFIjucID34qaqCTsm7HncbsgexGAakHbDSR5rjVOK2A3nMFCNQpKgmIY","audience":"http://54.156.240.171:8000/","grant_type":"client_credentials"}',
    method: 'POST'
};