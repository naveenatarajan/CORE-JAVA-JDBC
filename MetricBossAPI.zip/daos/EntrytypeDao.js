var models = require("../models");
var sequelize = models.sequelize;
var PropertiesReader = require('properties-reader');
var sqlQuery = PropertiesReader(__dirname+'/../sql_queries/EntryType_SQL.properties');
module.exports.create_Entry = function(Tables,callback) {
  var create_query = sqlQuery._properties.create_Tables;
  sequelize.query(create_query, {
    replacements: {
    	Name : Tables.Name,
    	Active : Tables.Active,
    	Order : Tables.Order,
      TimeCardEntryId : Tables.TimeCardEntryId,
    },
    type : sequelize.QueryTypes.INSERT,
    model: models.Tables
  }).then(function(tables) {
		callback(tables);
	});
}
module.exports.update_Entry = function(Tables,callback) {
  var update_query = sqlQuery._properties.update_Tables;
  sequelize.query(update_query, {
    replacements: {
      Id:Tables.Id,
    	Name : Tables.Name,
    	Active : Tables.Active,
    	Order : Tables.Order,
      TimeCardEntryId : Tables.TimeCardEntryId,
    },
    type : sequelize.QueryTypes.BULKUPDATE,
    model: models.Tables
  }).then(function(tables) {
		callback(tables);
	});
}
module.exports.search_Entry_for_update = function(Tables_id,callback) {
  var search_for_update_query = sqlQuery._properties.search_for_update_Tables;
  sequelize.query(search_for_update_query, {
    replacements: {
    	id: Tables_id
    },
    type : sequelize.QueryTypes.SELECT,
    model: models.Tables
  }).then(function(tables) {
		callback(tables[0]);
	});
}
module.exports.delete_Entry = function(Tables_id,callback) {
  var delete_query = sqlQuery._properties.delete_Tables;
  sequelize.query(delete_query, {
    replacements: {
    	id: Tables_id
    },
    type : sequelize.QueryTypes.DELETE,
    model: models.Tables
  }).then(function() {
		callback();
	});
}
module.exports.get_all_Entry = function(callback) {
  var get_all_query = sqlQuery._properties.get_all_Tables;
  sequelize.query(get_all_query, {
    type : sequelize.QueryTypes.SELECT,
    model: models.Tables
  }).then(function(tables) {
		callback(tables);
	});
}