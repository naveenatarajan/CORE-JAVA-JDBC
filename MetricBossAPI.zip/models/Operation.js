'use strict';

module.exports = function (sequelize, DataTypes) {
  var Tables = sequelize.define("Operation", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    WorkOrderId: DataTypes.INTEGER,
    Code: DataTypes.STRING,
    Description: DataTypes.STRING,
    AllowConcurrency: DataTypes.INTEGER,
    Instructions: DataTypes.STRING,
    PlannedQuantity: DataTypes.DOUBLE,
    ExpectedTime: DataTypes.DOUBLE,
    TimeCardEntryId: DataTypes.INTEGER,
    WorkOrderId: DataTypes.INTEGER
  }, {
      createdAt: false,
      updatedAt: false,
      freezeTableName: true
    });
  return Tables;
};