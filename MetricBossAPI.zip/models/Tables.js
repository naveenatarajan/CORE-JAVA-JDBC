'use strict';

module.exports = function(sequelize, DataTypes) {
  var Tables = sequelize.define("WorkOrderStatus", {
    id: {
    	type : DataTypes.INTEGER,
    	primaryKey : true,
    	autoIncrement : true
    },
    name: DataTypes.STRING,
    active: DataTypes.INTEGER,
    order: DataTypes.INTEGER
  },{
    createdAt: false,
    updatedAt: false,
    freezeTableName:true
  });
  return Tables;
};