'use strict';

angular.module('myApp.view1', ['ngRoute'])

  .config(['$routeProvider', function ($routeProvider) {
    $routeProvider.when('/view1', {
      templateUrl: 'view1/view1.html',
      controller: 'View1Ctrl'
    });
  }])

  .controller('View1Ctrl', ['$scope', '$http', function ($scope, $http) {

    $scope.myData = [15, 20, 31, 66, 33, 77, 38];

    // $http({
    //   method: "GET",
    //   url: "view1/data.json"
    // }).then(function mySuccess(response) {
    //   console.log('response>>>>>>>>>>', response);
    //   $scope.myData = response.data.myData;
    //   console.log('$scope.myData>>>>>>>>>>', $scope.myData);
    // }, function myError(response) {
    //   $scope.myData = response.statusText;
    // })

    $scope.allCohortsNorm = [
      {
        "cohortName": "Boston",
        "value": 0.3337727272727273
      },
      {
        "cohortName": "Stanley",
        "value": 0.2844818181818182
      },
      {
        "cohortName": "Students",
        "value": 0.1590909090909091
      }
    ];

    $scope.chartData = {
      "cols": [
        {
          "id": "month",
          "label": "Month",
          "type": "string"
        },
        {
          "id": "Tables-id",
          "label": "Tables",
          "type": "number"
        },
        {
          "id": "Chairs-id",
          "label": "Chairs",
          "type": "number"
        },
        {
          "id": "Bed-id",
          "label": "Bed",
          "type": "number"
        },
        {
          "id": "Desk-id",
          "label": "Desk",
          "type": "number"
        }
      ],
      "rows": [
        {
          "c": [
            {
              "v": "January"
            },
            {
              "v": 19,
              "f": "19 Tables"
            },
            {
              "v": 12,
              "f": "12 Chairs"
            },
            {
              "v": 7,
              "f": "7 Beds"
            },
            {
              "v": 4,
              "f": "4 Desks"
            }
          ]
        },
        {
          "c": [
            {
              "v": "February"
            },
            {
              "v": 13
            },
            {
              "v": 1,
              "f": "only 1unit"
            },
            {
              "v": 12
            },
            {
              "v": 2
            }
          ]
        },
        {
          "c": [
            {
              "v": "March"
            },
            {
              "v": 24
            },
            {
              "v": 5
            },
            {
              "v": 11
            },
            {
              "v": 6
            }
          ]
        }
      ]
    }
  }])

  .directive('barsChart', function ($parse) {
    return {
      restrict: 'E',
      replace: false,
      scope: { data: '=chartData' },
      link: function (scope, element, attrs) {
        console.log('d3.select(element[0])>>>>>>>>>>>>>', element[0]);
        var chart = d3.select(element[0]);
        console.log('scope.data>>>>>>>>>>>>>', scope.data);
        chart.append("div").attr("class", "chart")
          .selectAll('div')
          .data(scope.data).enter().append("div")
          .transition().ease("elastic")
          .style("width", function (d) { return d + "%"; })
          .text(function (d) { return d + "%"; });
      }
    }
  })

  .directive('d3Bars', function () {
    return {
      restrict: 'E',
      scope: {
        data: '='
      },
      link: function (scope, element) {
        var margin = { top: 15, right: 60, bottom: 150, left: 100 },
          width = 400 - margin.left - margin.right,
          height = 360 - margin.top - margin.bottom;

        var svg = d3.select(element[0])
          .append("svg")
          .attr('width', width + margin.left + margin.right)
          .attr('height', height + margin.top + margin.bottom)
          .attr('id', 'svg_id')
          .append("g")
          .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

        var x = d3.scale.ordinal().rangeRoundBands([0, width], .2);
        var y = d3.scale.linear().rangeRound([height, 0]);

        var xAxis = d3.svg.axis()
          .scale(x)
          .orient("bottom");

        var yAxis = d3.svg.axis()
          .scale(y)
          .orient("left")
          .tickFormat(d3.format(".0%"));

        scope.render = function (data) {

          if (data === undefined) {
            return;
          }

          svg.selectAll("*").remove();

          data.forEach(function (d) {
            d.value = +d.value;
          });

          x.domain(data.map(function (d) { return d.cohortName; }));
          y.domain([0, d3.max(data, function (d) { return d.value; })]);

          svg.selectAll('g.axis').remove();
          svg.append("g")
            .attr("class", "x axis")
            .attr("transform", "translate(0," + height + ")")
            .attr("fill", "white")
            .call(xAxis)
            .selectAll("text")
            .style("text-anchor", "end")
            .style("font-size", "12px")
            .attr("dx", "2em")
            .attr("dy", ".7em")
            .attr("transform", function (d) {
              return "rotate(-15)";
            });

          svg.append("g")
            .attr("class", "y axis")
            .attr("fill", "white")
            .call(yAxis)
            .append("text")
            .attr("transform", "rotate(-90)")
            .attr("y", -70)
            .attr("x", -30)
            .attr("dy", ".6em")
            .style("text-anchor", "end")
            .attr("fill", "white")
            .text("% of standards met");

          var bars = svg.selectAll(".bar")
            .data(data)
            .enter().append("rect")
            .style("fill", "#45ADA8")
            .attr("x", function (d) { return x(d.cohortName); })
            .attr("width", x.rangeBand())
            .attr("y", function (d) { return y(d.value); })
            .attr("height", function (d) { return height - y(d.value); });

          svg.selectAll("rect")
            .data(data)
            .enter()
            .append("text")
            .attr("x", x.rangeBand() / 2)
            .attr("y", function (d) { return (d.value * 100); })
            .style("text-anchor", "middle")
            .style("font-size", "10px")
            .text(function (d) { return (d.value * 100); });

          svg.selectAll(".label")
            .data(data)
            .enter().append("svg:text")
            .attr("class", "label")
            .attr("x", function (d) {
              return x(d.cohortName) + (x.rangeBand() / 3) - 5;
            })
            .attr("y", function (d) {
              return y(d.value) + 40;
            })
            .text(function (d) {
              return (d.value * 100).toFixed() + "%";
            });
        };

        scope.$watch('data', function () {
          scope.render(scope.data);
        });

      }
    };
  })

  .directive('appColumnchart', function () {
    // return {
    //   scope: {                      //set up directive's isolated scope

    //     data: '=data',
    //     stacked: '=stacked',
    //   },
    //   restrict: 'EA',}

      return {
        restrict: 'EA',
        scope: {
          data: '=data',
          stacked: '=stacked',
        },
        link: function (scope, element) {
          var margin = { top: 15, right: 60, bottom: 150, left: 100 },
            width = 400 - margin.left - margin.right,
            height = 360 - margin.top - margin.bottom;
        console.log('element[0]***************',element[0]);
          var svg = d3.select(element[0])
            .append("svg")
            .attr('width', width + margin.left + margin.right)
            .attr('height', height + margin.top + margin.bottom)
            .attr('id', 'svg_id')
            .append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
  
          var x = d3.scale.ordinal().rangeRoundBands([0, width], .2);
          var y = d3.scale.linear().rangeRound([height, 0]);
  
          var xAxis = d3.svg.axis()
            .scale(x)
            .orient("bottom");
  
          var yAxis = d3.svg.axis()
            .scale(y)
            .orient("left")
            .tickFormat(d3.format(".0%"));
  
          scope.render = function (data) {
  
            if (data === undefined) {
              return;
            }
  
            svg.selectAll("*").remove();
  
            data.forEach(function (d) {
              d.type = +d.type;
            });
  
            x.domain(data.map(function (d) { return d.label; }));
            y.domain([0, d3.max(data, function (d) { return d.type; })]);
  
            svg.selectAll('g.axis').remove();
            svg.append("g")
              .attr("class", "x axis")
              .attr("transform", "translate(0," + height + ")")
              .attr("fill", "white")
              .call(xAxis)
              .selectAll("text")
              .style("text-anchor", "end")
              .style("font-size", "12px")
              .attr("dx", "2em")
              .attr("dy", ".7em")
              .attr("transform", function (d) {
                return "rotate(-15)";
              });
  
            svg.append("g")
              .attr("class", "y axis")
              .attr("fill", "white")
              .call(yAxis)
              .append("text")
              .attr("transform", "rotate(-90)")
              .attr("y", -70)
              .attr("x", -30)
              .attr("dy", ".6em")
              .style("text-anchor", "end")
              .attr("fill", "white")
              .text("% of standards met");
  
            var bars = svg.selectAll(".bar")
              .data(data)
              .enter().append("rect")
              .style("fill", "#45ADA8")
              .attr("x", function (d) { return x(d.label); })
              .attr("width", x.rangeBand())
              .attr("y", function (d) { return y(d.type); })
              .attr("height", function (d) { return height - y(d.type); });
  
            svg.selectAll("rect")
              .data(data)
              .enter()
              .append("text")
              .attr("x", x.rangeBand() / 2)
              .attr("y", function (d) { return (d.type * 100); })
              .style("text-anchor", "middle")
              .style("font-size", "10px")
              .text(function (d) { return (d.type * 100); });
  
            svg.selectAll(".label")
              .data(data)
              .enter().append("svg:text")
              .attr("class", "label")
              .attr("x", function (d) {
                return x(d.label) + (x.rangeBand() / 3) - 5;
              })
              .attr("y", function (d) {
                return y(d.type) + 40;
              })
              .text(function (d) {
                return (d.type * 100).toFixed() + "%";
              });
          };
  
          scope.$watch('data', function () {
            scope.render(scope.data);
          });
  
        }
      };

  });


