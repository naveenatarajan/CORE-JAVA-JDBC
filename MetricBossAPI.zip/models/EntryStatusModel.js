'use strict';

module.exports = function(sequelize, DataTypes) {
  var Tables = sequelize.define("EntryStatus", {
    id: {
    	type : DataTypes.INTEGER,
    	primaryKey : true,
    	autoIncrement : true
    },
    Name: DataTypes.STRING,
    Active: DataTypes.INTEGER,
    Order: DataTypes.INTEGER,
    TimeCardEntryId:DataTypes.INTEGER,
  },{
    createdAt: false,
    updatedAt: false,
    freezeTableName:true
  });
  return Tables;
};