var express = require('express');
var apiRouter = express.Router();
var PropertyHistoryController = require('../../controller/propertyHistoryController');

apiRouter.post('/create', PropertyHistoryController.insert_property_history);
apiRouter.get('/getByPropertyKey', PropertyHistoryController.get_history_by_key);
apiRouter.get('/all_propertyhistory',PropertyHistoryController.all_propertyhistory);
apiRouter.put('/update_propertyhistory',PropertyHistoryController.update_propertyhistory);
apiRouter.delete('/delete_propertyhistory',PropertyHistoryController.delete_propertyhistory);
apiRouter.get('/search_propertyhistory',PropertyHistoryController.search_propertyhistory)
module.exports = apiRouter;
