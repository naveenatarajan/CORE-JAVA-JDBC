var TaskGrouplist = require('../service/TaskGroupService');

module.exports.addtask = (req, res) => {
    var task = req.body;

    TaskGrouplist.addtask(task, function (task, err) {

        if (err) {
            res.status(500).send(err);
        } else {
            res.status(201).send(task);
        }
    });

}

module.exports.gettasklist = (req, res) => {

    TaskGrouplist.gettasklist(function (tasklist, err) {
        if (err) {
            res.status(500).send(err);
        } else {
            res.status(200).send(tasklist);
        }
    });

}

module.exports.updatetaskgroup = (req, res) => {

    var details = req.body;
    var id = details._id;
    var taskdetails = {
    description : details.description,
    groupid : details.groupid,
    groupname : details.groupname
    }

    TaskGrouplist.updatetask(id, taskdetails, function (err, taskdetails) {

        if (err) {
            res.status(500).send(err);
        } else {
            res.status(200).send(taskdetails);
        }

    });
}

module.exports.deletetask = (req, res) => {

    var id = req.params.id

    TaskGrouplist.deletelist(id, function (err, data) {

        if (err) {
            res.status(500).send(err);
        } else {
            res.status(200).send(data);
        }
    });

}