
var Reuser = require('../model/Reuser');

module.exports.signUp = (userData, callback) =>{

    var user = new Reuser(userData);
        
    user.save(function(data, err){
        if(err){
            callback(err);
        }else{
            callback(data);
            console.log('Usr-----------',data);
        }
    })
}



module.exports.updateUser = (email, callback) =>{

    Reuser.findOneAndUpdate({email:email},{$set:{emailConfirmation:false,}},{upsert:true, new:true, runValidators:true}, function(data, err){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}

module.exports.deleteUser = (email, callback) => {

    Reuser.findOneAndRemove({email:email}, function(data, err){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })

}

//get all users from reuser table
module.exports.getUsers = ( callback) => {
    
    Reuser.find(function(data, err){
        if(err){
            callback(err);            
        }else{
            callback(data);
        }
    })
}

//set percentage in reuser table
module.exports.setUserPercentage = (percentage,_id, callback) => {

    Reuser.findOneAndUpdate({_id:_id},{percentage:percentage},{upsert:true, new:true, runValidators:true}, function(data,err){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}

//get user_by_id from reuser table
module.exports.getUserId = (UserId, callback) => {
   
    Reuser.find(function(data, err) {
        if(err){
            callback(err);
        }
        else{
            console.log(' userid---->',data);
            callback(data);
        }
    })
}