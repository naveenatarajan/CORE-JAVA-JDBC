 /**
 * @swagger
 * /login:
 *   get:
 *     tags:
 *       - Login
 *     produces:
 *       - application/json
 *     responses:
 *       200:
 *        description: "ok"
 */


 /**
 * @swagger
 * definition:
 *   Headers:
 *     properties:
 *       Authorization:
 *         type: string
 */




/**
 * @swagger
 * definition:
 *   WorkOrderStatus:
 *     properties:
 *       id:
 *         type: number
 *       name:
 *         type: string  
 *       active:
 *         type: number
 *       order:
 *         type: number
 */


 /**
 * @swagger
 * /WorkOrderStatus:
 *   post:
 *     tags:
 *       - WorkOrderStatus
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         schema:
 *           $ref: '#/definitions/Headers'
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/WorkOrderStatus'         
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



  /**
 * @swagger
 * /WorkOrderStatus:
 *   put:
 *     tags:
 *       - WorkOrderStatus
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         schema:
 *           $ref: '#/definitions/Headers'
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/WorkOrderStatus'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


 /**
 * @swagger
 * /WorkOrderStatus:
 *   get:
 *     tags:
 *       - WorkOrderStatus
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       200:
 *        description: "ok"
 */

  /**
 * @swagger
 * /WorkOrderStatus/{id}:
 *   delete:
 *     tags:
 *       - WorkOrderStatus
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "Work Order Status not found"
 */

 /**
 * @swagger
 * /WorkOrderStatus/{id}:
 *   get:
 *     tags:
 *       - WorkOrderStatus
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "Work Order Status not found"
 */


//////-----empployee type


 /**
 * @swagger
 * definition:
 *   EmployeeType:
 *     properties:
 *       id:
 *         type: number
 *       name:
 *         type: string  
 *       active:
 *         type: number
 *       order:
 *         type: number
 */


 /**
 * @swagger
 * /EmployeeType:
 *   post:
 *     tags:
 *       - EmployeeType
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/EmployeeType'
 *       - in: header
 *         name: "Authorization"
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



  /**
 * @swagger
 * /EmployeeType:
 *   put:
 *     tags:
 *       - EmployeeType
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/EmployeeType'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


 /**
 * @swagger
 * /EmployeeType:
 *   get:
 *     tags:
 *       - EmployeeType
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       200:
 *        description: "ok"
 */

  /**
 * @swagger
 * /EmployeeType/{id}:
 *   delete:
 *     tags:
 *       - EmployeeType
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "EmployeeType Status not found"
 */

 /**
 * @swagger
 * /EmployeeType/{id}:
 *   get:
 *     tags:
 *       - EmployeeType
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "EmployeeType not found"
 */

 //////-----timecard status

 /**
 * @swagger
 * definition:
 *   TimeCardStatus:
 *     properties:
 *       id:
 *         type: number
 *       name:
 *         type: string  
 *       active:
 *         type: number
 *       order:
 *         type: number
 */


 /**
 * @swagger
 * /TimeCardStatus:
 *   post:
 *     tags:
 *       - TimeCardStatus
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/TimeCardStatus'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



  /**
 * @swagger
 * /TimeCardStatus:
 *   put:
 *     tags:
 *       - TimeCardStatus
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/TimeCardStatus'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


 /**
 * @swagger
 * /TimeCardStatus:
 *   get:
 *     tags:
 *       - TimeCardStatus
 *     produces:
 *       - application/json
*     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       200:
 *        description: "ok"
 */

  /**
 * @swagger
 * /TimeCardStatus/{id}:
 *   delete:
 *     tags:
 *       - TimeCardStatus
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "TimeCardStatus  not found"
 */

 /**
 * @swagger
 * /TimeCardStatus/id}:
 *   get:
 *     tags:
 *       - TimeCardStatus
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "TimeCardStatus not found"
 */


 //////-----OrganizationalUnit


 /**
 * @swagger
 * definition:
 *   OrganizationalUnit:
 *     properties:
 *       id:
 *         type: number
 *       parentId:
 *         type: number
 *       name:
 *         type: string  
 *       active:
 *         type: number
 *       order:
 *         type: number
 *       OrganizationalUnitId:
 *         type: number
 */


 /**
 * @swagger
 * /OrganizationalUnit:
 *   post:
 *     tags:
 *       - OrganizationalUnit
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/OrganizationalUnit'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



  /**
 * @swagger
 * /OrganizationalUnit:
 *   put:
 *     tags:
 *       - OrganizationalUnit
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/OrganizationalUnit'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


 /**
 * @swagger
 * /OrganizationalUnit:
 *   get:
 *     tags:
 *       - OrganizationalUnit
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       200:
 *        description: "ok"
 */

  /**
 * @swagger
 * /OrganizationalUnit/{id}:
 *   delete:
 *     tags:
 *       - OrganizationalUnit
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "OrganizationalUnit  not found"
 */

 /**
 * @swagger
 * /OrganizationalUnit/{id}:
 *   get:
 *     tags:
 *       - OrganizationalUnit
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "OrganizationalUnit not found"
 */


 //////-----Employee


 /**
 * @swagger
 * definition:
 *   Employee:
 *     properties:
 *       id:
 *         type: number
 *       FirstName:
 *         type: string  
 *       MiddleName:
 *         type: string  
 *       LastName:
 *         type: string  
 *       EmployeeTypeId:
 *         type: number
 *       EmployeeNumber:
 *         type: string  
 *       OrganizationalUnitId:
 *         type: number
 *       Active:
 *         type: number
 *       Order:
 *         type: number
 *       ManagerId:
 *         type: number
 */


 /**
 * @swagger
 * /Employee:
 *   post:
 *     tags:
 *       - Employee
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Employee'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



  /**
 * @swagger
 * /Employee:
 *   put:
 *     tags:
 *       - Employee
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Employee'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


 /**
 * @swagger
 * /Employee:
 *   get:
 *     tags:
 *       - Employee
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       200:
 *        description: "ok"
 */

  /**
 * @swagger
 * /Employee/{id}:
 *   delete:
 *     tags:
 *       - Employee
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "Employee  not found"
 */

 /**
 * @swagger
 * /Employee/{id}:
 *   get:
 *     tags:
 *       - Employee
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "Employee not found"
 */


 //////-----TimeCard


 /**
 * @swagger
 * definition:
 *   TimeCard:
 *     properties:
 *       id:
 *         type: number  
 *       Deleted:
 *         type: number  
 *       UpdatedFromIp:
 *         type: string  
 *       UpdatedBy:
 *         type: string
 *       EmployeeId:
 *         type: number
 *       TimeCardStatusId:
 *         type: number
 */


 /**
 * @swagger
 * /TimeCard:
 *   post:
 *     tags:
 *       - TimeCard
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/TimeCard'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



  /**
 * @swagger
 * /TimeCard:
 *   put:
 *     tags:
 *       - TimeCard
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/TimeCard'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


 /**
 * @swagger
 * /TimeCard:
 *   get:
 *     tags:
 *       - TimeCard
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       200:
 *        description: "ok"
 */

  /**
 * @swagger
 * /TimeCard/{id}:
 *   delete:
 *     tags:
 *       - TimeCard
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "TimeCard  not found"
 */

 /**
 * @swagger
 * /TimeCard/{id}:
 *   get:
 *     tags:
 *       - TimeCard
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "TimeCard not found"
 */


 //////-----WorkOrder


 /**
 * @swagger
 * definition:
 *   WorkOrder:
 *     properties:
 *       id:
 *         type: number 
 *       WorkOrderNumber:
 *         type: string  
 *       SalesOrderNumber:
 *         type: string  
 *       SalesOrderLine:
 *         type: number  
 *       CustomerName:
 *         type: string
 *       CustomerNumber:
 *         type: number
 *       PartNumber:
 *         type: string
 *       PartDescription:
 *         type: string
 *       Quantity:
 *         type: number
 *       Completed:
 *         type: number
 *       WorkOrderStatusId:
 *         type: number
 * 
 */ 


 /**
 * @swagger
 * /WorkOrder:
 *   post:
 *     tags:
 *       - WorkOrder
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/WorkOrder'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



  /**
 * @swagger
 * /WorkOrder:
 *   put:
 *     tags:
 *       - WorkOrder
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/WorkOrder'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


 /**
 * @swagger
 * /WorkOrder:
 *   get:
 *     tags:
 *       - WorkOrder
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       200:
 *        description: "ok"
 */

  /**
 * @swagger
 * /WorkOrder/{id}:
 *   delete:
 *     tags:
 *       - WorkOrder
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "WorkOrder  not found"
 */

 /**
 * @swagger
 * /WorkOrder/{id}:
 *   get:
 *     tags:
 *       - WorkOrder
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "WorkOrder not found"
 */


  //////-----Entry


 /**
 * @swagger
 * definition:
 *   Entry:
 *     properties:
 *       id:
 *         type: number
 *       EntryTypeId: 
 *         type: number 
 *       PaidTime:
 *         type: number  
 *       BillableTime:
 *         type: number
 *       RefId:
 *         type: number
 *       Completed:
 *         type: number
 *       Notes:
 *         type: string
 *       EntryStatusId:
 *         type: number  
 *       Deleted:
 *         type: number
 *       UpdatedBy:
 *         type: string
 *       UpdatedFromIp:
 *         type: string
 *       TimeCardId:
 *         type: number
 * 
 */ 


 /**
 * @swagger
 * /Entry:
 *   post:
 *     tags:
 *       - Entry
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Entry'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



  /**
 * @swagger
 * /Entry:
 *   put:
 *     tags:
 *       - Entry
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Entry'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


 /**
 * @swagger
 * /Entry:
 *   get:
 *     tags:
 *       - Entry
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       200:
 *        description: "ok"
 */

  /**
 * @swagger
 * /Entry/{id}:
 *   delete:
 *     tags:
 *       - Entry
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "WorkOrder  not found"
 */

 /**
 * @swagger
 * /Entry/{id}:
 *   get:
 *     tags:
 *       - Entry
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "Entry not found"
 */



//entry status

/**
 * @swagger
 * definition:
 *   EntryStatus:
 *     properties:
 *       id:
 *         type: number
 *       Name:
 *         type: string  
 *       Active:
 *         type: number
 *       Order:
 *         type: number
 *       TimeCardEntryId:
 *         type: number
 */


 /**
 * @swagger
 * /EntryStatus:
 *   post:
 *     tags:
 *       - EntryStatus
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/EntryStatus'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



  /**
 * @swagger
 * /EntryStatus:
 *   put:
 *     tags:
 *       - EntryStatus
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/EntryStatus'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


 /**
 * @swagger
 * /EntryStatus:
 *   get:
 *     tags:
 *       - EntryStatus
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       200:
 *        description: "ok"
 */

  /**
 * @swagger
 * /EntryStatus/{id}:
 *   delete:
 *     tags:
 *       - EntryStatus
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "Work Order Status not found"
 */

 /**
 * @swagger
 * /EntryStatus/{id}:
 *   get:
 *     tags:
 *       - EntryStatus
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: " Status not found"
 */

 
 //entry type

/**
 * @swagger
 * definition:
 *   EntryType:
 *     properties:
 *       id:
 *         type: number
 *       Name:
 *         type: string  
 *       Active:
 *         type: number
 *       Order:
 *         type: number
 *       TimeCardEntryId:
 *         type: number
 */


 /**
 * @swagger
 * /EntryType:
 *   post:
 *     tags:
 *       - EntryType
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/EntryType'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



  /**
 * @swagger
 * /EntryType:
 *   put:
 *     tags:
 *       - EntryType
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/EntryType'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


 /**
 * @swagger
 * /EntryType:
 *   get:
 *     tags:
 *       - EntryType
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       200:
 *        description: "ok"
 */

  /**
 * @swagger
 * /EntryType/{id}:
 *   delete:
 *     tags:
 *       - EntryType
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "Work Order Status not found"
 */

 /**
 * @swagger
 * /EntryType/{id}:
 *   get:
 *     tags:
 *       - EntryType
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: " Status not found"
 */

 

  //AdjustedEntry

/**
 * @swagger
 * definition:
 *   AdjustedEntry:
 *     properties:
 *       id:
 *         type: number
 *       TimeCardId:
 *         type: number
 *       EntryId:
 *         type: number
 *       EntryCode:
 *         type: string
 *       EmployeeNumber:
 *         type: string  
 *       WorkOrderNumber:
 *         type: string
 *       PartNumber:
 *         type: string
 *       OrganizationalUnitId:
 *         type: number
 *       Duration:
 *         type: number
 *       Weight:
 *         type: number
 */


 /**
 * @swagger
 * /AdjustedEntry:
 *   post:
 *     tags:
 *       - AdjustedEntry
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/AdjustedEntry'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



  /**
 * @swagger
 * /AdjustedEntry:
 *   put:
 *     tags:
 *       - AdjustedEntry
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/AdjustedEntry'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


 /**
 * @swagger
 * /AdjustedEntry:
 *   get:
 *     tags:
 *       - AdjustedEntry
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *        description: "ok"
 */
 

  /**
 * @swagger
 * /AdjustedEntry/{id}:
 *   delete:
 *     tags:
 *       - AdjustedEntry
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "Work Order Status not found"
 */

 /**
 * @swagger
 * /AdjustedEntry/{id}:
 *   get:
 *     tags:
 *       - AdjustedEntry
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: " Status not found"
 */

 


 //Operation

/**
 * @swagger
 * definition:
 *   Operation:
 *     properties:
 *       id:
 *         type: number
 *       Code:
 *         type: string
 *       Description:
 *         type: string
 *       AllowConcurrency:
 *         type: number
 *       Instructions:
 *         type: string
 *       PlannedQuantity:
 *         type: number
 *       ExpectedTime:
 *         type: number
 *       TimeCardEntryId:
 *         type: number
 *       WorkOrderId:
 *         type: number
 */


 /**
 * @swagger
 * /Operation:
 *   post:
 *     tags:
 *       - Operation
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Operation'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



  /**
 * @swagger
 * /Operation:
 *   put:
 *     tags:
 *       - Operation
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Operation'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


 /**
 * @swagger
 * /Operation:
 *   get:
 *     tags:
 *       - Operation
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       200:
 *        description: "ok"
 */

  /**
 * @swagger
 * /Operation/{id}:
 *   delete:
 *     tags:
 *       - Operation
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "Work Order Status not found"
 */

 /**
 * @swagger
 * /Operation/{id}:
 *   get:
 *     tags:
 *       - Operation
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: " Status not found"
 */

 
 //Entry Change Log

/**
 * @swagger
 * definition:
 *   EntryChangeLog:
 *     properties:
 *       id:
 *         type: number
 *       Revision:
 *         type: number
 *       TimeCardId:
 *         type: number
 *       EntryTypeId:
 *         type: number
 *       PaidTime:
 *         type: number
 *       BillableTime:
 *         type: number
 *       RefId:
 *         type: number
 *       Completed:
 *         type: number
 *       Notes:
 *         type: string
 *       EntryStatusId:
 *         type: number
 *       Deleted:
 *         type: number
 *       UpdatedBy:
 *         type: string
 *       UpdatedFromIp:
 *         type: string
 *       Action:
 *         type: string
 *       EntryId:
 *         type: number
 */


 /**
 * @swagger
 * /EntryChangeLog:
 *   post:
 *     tags:
 *       - EntryChangeLog
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/EntryChangeLog'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



  /**
 * @swagger
 * /EntryChangeLog:
 *   put:
 *     tags:
 *       - EntryChangeLog
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/EntryChangeLog'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


 /**
 * @swagger
 * /EntryChangeLog:
 *   get:
 *     tags:
 *       - EntryChangeLog
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       200:
 *        description: "ok"
 */

  /**
 * @swagger
 * /EntryChangeLog/{id}:
 *   delete:
 *     tags:
 *       - EntryChangeLog
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "EntryChangeLog not found"
 */

 /**
 * @swagger
 * /EntryChangeLog/{id}:
 *   get:
 *     tags:
 *       - EntryChangeLog
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: " Status not found"
 */




 //break



 /**
 * @swagger
 * definition:
 *   Break:
 *     properties:
 *       id:
 *         type: number
 *       Code:
 *         type: string
 *       Description:
 *         type: string
 *       PaidTime:
 *         type: number
 *       Active:
 *         type: number
 *       Order:
 *         type: number
 *       TimeCardEntry_Id:
 *         type: number
 */


 /**
 * @swagger
 * /Break:
 *   post:
 *     tags:
 *       - Break
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Break'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



  /**
 * @swagger
 * /Break:
 *   put:
 *     tags:
 *       - Break
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Break'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


 /**
 * @swagger
 * /Break:
 *   get:
 *     tags:
 *       - Break
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     produces:
 *       - application/json
 *     responses:
 *       200:
 *        description: "ok"
 */

  /**
 * @swagger
 * /Break/{id}:
 *   delete:
 *     tags:
 *       - Break
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "EntryChangeLog not found"
 */

 /**
 * @swagger
 * /Break/{id}:
 *   get:
 *     tags:
 *       - Break
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: " Status not found"
 */



 //Indirect Labour



 /**
 * @swagger
 * definition:
 *   IndirectLabor:
 *     properties:
 *       id:
 *         type: number
 *       Code:
 *         type: string
 *       AllowConcurrency:
 *         type: number
 *       Description:
 *         type: string
 *       PaidTime:
 *         type: number
 *       Active:
 *         type: number
 *       Order:
 *         type: number
 *       TimeCardEntryId:
 *         type: number
 */


 /**
 * @swagger
 * /IndirectLabor:
 *   post:
 *     tags:
 *       - IndirectLabor
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/IndirectLabor'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



  /**
 * @swagger
 * /IndirectLabor:
 *   put:
 *     tags:
 *       - IndirectLabor
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/IndirectLabor'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


 /**
 * @swagger
 * /IndirectLabor:
 *   get:
 *     tags:
 *       - IndirectLabor
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       200:
 *        description: "ok"
 */

  /**
 * @swagger
 * /IndirectLabor/{id}:
 *   delete:
 *     tags:
 *       - IndirectLabor
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "EntryChangeLog not found"
 */

 /**
 * @swagger
 * /IndirectLabor/{id}:
 *   get:
 *     tags:
 *       - IndirectLabor
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: " Status not found"
 */

 

 

 //timecard Change Log

/**
 * @swagger
 * definition:
 *   TimeCardChangeLog:
 *     properties:
 *       id:
 *         type: number
 *       Revision:
 *         type: number
 *       EmployeeId:
 *         type: number
 *       TimeCardStatusId:
 *         type: number
 *       Deleted:
 *         type: number
 *       UpdatedBy:
 *         type: string
 *       UpdatedFromIp:
 *         type: string
 *       Action:
 *         type: string
 *       TimeCardId:
 *         type: number
 */


 /**
 * @swagger
 * /TimeCardChangeLog:
 *   post:
 *     tags:
 *       - TimeCardChangeLog
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/TimeCardChangeLog'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



  /**
 * @swagger
 * /TimeCardChangeLog:
 *   put:
 *     tags:
 *       - TimeCardChangeLog
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/TimeCardChangeLog'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


 /**
 * @swagger
 * /TimeCardChangeLog:
 *   get:
 *     tags:
 *       - TimeCardChangeLog
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       200:
 *        description: "ok"
 */

  /**
 * @swagger
 * /TimeCardChangeLog/{id}:
 *   delete:
 *     tags:
 *       - TimeCardChangeLog
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: "TimeCardChangeLog not found"
 */

 /**
 * @swagger
 * /TimeCardChangeLog/{id}:
 *   get:
 *     tags:
 *       - TimeCardChangeLog
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: "id"
 *         in: "path"
 *         description: "Enter the id to delete"
 *         required: true
 *         type: "integer"
 *         format: "int64"
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *         400:
 *           description: "Invalid ID supplied"
 *         404:
 *           description: " Status not found"
 */


//===========================Update OutTime

 /**
 * @swagger
 * definition:
 *   UpdateOutTime:
 *     properties:
 *       timeCardId:
 *         type: number
 */


 /**
 * @swagger
 * /TimeCard/UpdateOutTime:
 *   post:
 *     tags:
 *       - UpdateOutTime
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/UpdateOutTime'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */

 //===========================create Break Entries

 /**
 * @swagger
 * definition:
 *   CreateBreakEntry:
 *     properties:
 *       TimeCardId :
 *         type: number
 *       PaidTime:
 *         type: number
 *       BillableTime:
 *         type: number
 *       Completed:
 *         type: number
 *         format: double
 *       Notes:
 *         type: string
 *       EntryStatusId:
 *         type: number
 *       Deleted:
 *         type: number
 *       UpdatedBy:
 *         type: string
 *       UpdatedFromIp:
 *         type: string
 *       Code:
 *         type: string
 *       Description:
 *         type: string
 *       Active:
 *         type: number
 *       Order:
 *         type: number
 */


 /**
 * @swagger
 * /Break/createBreakEntries:
 *   post:
 *     tags:
 *       - CreateBreakEntry
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/CreateBreakEntry'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */




//===========================Indirect Labor Entries Entries

 /**
 * @swagger
 * definition:
 *   IndirectLaborEntry:
 *     properties:
 *       TimeCardId :
 *         type: number
 *       PaidTime:
 *         type: number
 *       BillableTime:
 *         type: number
 *       Completed:
 *         type: number
 *         format: double
 *       Notes:
 *         type: string
 *       EntryStatusId:
 *         type: number
 *       Deleted:
 *         type: number
 *       UpdatedBy:
 *         type: string
 *       UpdatedFromIp:
 *         type: string
 *       Code:
 *         type: string
 *       Description:
 *         type: string
 *       Active:
 *         type: number
 *       Order:
 *         type: number
 *       AllowConcurrency:
 *         type: number
 */


 /**
 * @swagger
 * /IndirectLabor/createIndirectLaborEntries:
 *   post:
 *     tags:
 *       - IndirectLaborEntry
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/IndirectLaborEntry'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */



 //===========================Operation Entry

 /**
 * @swagger
 * definition:
 *   OperationEntry:
 *     properties:
 *       TimeCardId :
 *         type: number
 *       PaidTime:
 *         type: number
 *       BillableTime:
 *         type: number
 *       Completed:
 *         type: number
 *         format: double
 *       Notes:
 *         type: string
 *       EntryStatusId:
 *         type: number
 *       Deleted:
 *         type: number
 *       UpdatedBy:
 *         type: string
 *       UpdatedFromIp:
 *         type: string
 *       Code:
 *         type: string
 *       Description:
 *         type: string
 *       Active:
 *         type: number
 *       Order:
 *         type: number
 *       AllowConcurrency:
 *         type: number
 *       PlannedQuantity:
 *         type: number
 *       ExpectedTime:
 *         type: number
 *       Instructions:
 *         type: string
 *       WorkOrderId:
 *         type: number
 */


 /**
 * @swagger
 * /Operation/createOperationEntries:
 *   post:
 *     tags:
 *       - OperationEntry
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/OperationEntry'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */


//===========================checkOperationConcurrency

 /**
 * @swagger
 * definition:
 *   checkOperationConcurrency:
 *     properties:
 *       timecardId:
 *         type: number
 */


 /**
 * @swagger
 * /Operation/checkOperationConcurrency:
 *   post:
 *     tags:
 *       - checkOperationConcurrency
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/checkOperationConcurrency'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */




 //===========================checkIndirectLaborConcurrency

 /**
 * @swagger
 * definition:
 *   checkIndirectLaborConcurrency:
 *     properties:
 *       timecardId:
 *         type: number
 */


 /**
 * @swagger
 * /IndirectLabor/checkIndirectLaborConcurrency:
 *   post:
 *     tags:
 *       - checkIndirectLaborConcurrency
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: "body"
 *         name: "body"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/checkIndirectLaborConcurrency'
 *       - in: "header"
 *         name: "Authorization"
 *         required: true
 *         schema:
 *           $ref: '#/definitions/Headers'
 *     responses:
 *       405:
 *         description: "Invalid input"
 */
 



 