var express = require('express');
var apiRouter = express.Router();
var Masterlistcontroller = require('../../controller/MasterListController.js');

apiRouter.post('/create_masterlist', Masterlistcontroller.addlist);
apiRouter.get('/getalllist', Masterlistcontroller.getalllist);
apiRouter.put('/updatemasterlist', Masterlistcontroller.updatemasterlist);
apiRouter.delete('/deletelist/:id', Masterlistcontroller.deletealllist);

module.exports = apiRouter;