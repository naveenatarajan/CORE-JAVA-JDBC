var personDao = require('../dao/personDao')

module.exports.postPerson = (personData, callback) => {
    personDao.postPerson(personData, function (err, result) {
        if (err) {
            callback(err)
        } else {
            callback(result)
        }
    })
}