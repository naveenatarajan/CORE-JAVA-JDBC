var dao = require("../daos/EntrytypeDao")
module.exports.create_Entry = function(Tables,callback) {
  dao.create_Entry(Tables,function (tables){
    callback(tables);
  });
}
module.exports.update_Entry = function(Tables,callback) {
  dao.update_Entry(Tables,function (tables){
    callback(tables);
  });
}
module.exports.search_Entry_for_update = function(Tables_id,callback) {
  dao.search_Entry_for_update(Tables_id,function (tables){
    callback(tables)
  });
}
module.exports.delete_Entry = function(Tables_id,callback) {
  dao.delete_Entry(Tables_id,function (){
    callback();
  });
}
module.exports.get_all_Entry = function(callback) {
  dao.get_all_Entry(function (list_of_tables){
    callback(list_of_tables)
  });
}