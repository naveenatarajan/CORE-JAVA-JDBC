'use strict';

describe('myApp.view5 module', function() {

  beforeEach(module('myApp.view5'));

  describe('view5 controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view5Ctrl = $controller('View5Ctrl');
      expect(view5Ctrl).toBeDefined();
    }));

  });
});