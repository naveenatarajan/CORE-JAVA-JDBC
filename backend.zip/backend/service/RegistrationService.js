var RegistrationDao = require('../dao/RegistrationDao');

module.exports.signUp = (userData, callback)=>{

    RegistrationDao.signUp(userData, function(err, data){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}

module.exports.updateUser = (email, callback) =>{
    RegistrationDao.updateUser(email, function(err, data){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}


module.exports.deleteUser = (email, callback) =>{
    RegistrationDao.deleteUser(email, function(err, data){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}

//get all users from reuser table
module.exports.getUsers = (callback) => {
    RegistrationDao.getUsers(function(err, data){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}

//set percentage in reuser table
module.exports.setUserPercentage = (percentage,_id, callback) => {
    RegistrationDao.setUserPercentage(percentage,_id, function(err,data){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}

//get user_by_id from reuser table
module.exports.getUserId = (UserId, callback) => {

    RegistrationDao.getUserId(UserId, function(err,assignedusers){
        if(err){
            callback(err);
        }
        else{
            callback(data);
        }
    })
}