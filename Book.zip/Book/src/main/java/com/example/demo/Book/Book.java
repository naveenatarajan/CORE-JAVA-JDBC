package com.example.demo.Book;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "book")
@JsonIgnoreProperties
public class Book {
	@Id
	@GeneratedValue
	private int id;
	private String name;
	
   @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private BookDetail bookDetail;

    @ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "bookvaries_id")
	private BookVaries bookvaries;
	 
	@ManyToMany(targetEntity = BookPublisher.class,cascade = CascadeType.MERGE,fetch = FetchType.EAGER)
    @JoinTable(name = "bookpublisher", 
    joinColumns ={@JoinColumn(name = "book_id",referencedColumnName = "id")},
    inverseJoinColumns = {@JoinColumn(name = "bookpublisher_id",referencedColumnName = "id")})
	private  List<BookPublisher> bookpublisher;

	public Book() {

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BookDetail getBookDetail() {
		return bookDetail;
	}

	public void setBookDetail(BookDetail bookDetail) {
		this.bookDetail = bookDetail;
	}

	@Override
	public String toString() {
		return String.format("Book[id=%d, name='%s', number of pages='%d']", id, name, bookDetail.getNumberOfPages());
	}

	public BookVaries getBookvaries() {
		return bookvaries;
	}

	public void setBookvaries(BookVaries bookvaries) {
		this.bookvaries = bookvaries;
	}
	
	public  List<BookPublisher> getBookPublisher() {
        return bookpublisher;
}

    public void setBookPublisher( List<BookPublisher> bookpublisher) {
        this.bookpublisher = bookpublisher;
 }

}
