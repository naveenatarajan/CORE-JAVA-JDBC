var models = require("../models");
var sequelize = models.sequelize;
var PropertiesReader = require('properties-reader');
var sqlQuery = PropertiesReader(__dirname + '/../sql_queries/IndirectLabor_SQL.properties');
var sqlQueryEntry = PropertiesReader(__dirname + '/../sql_queries/Entry_SQL.properties');

module.exports.create_Tables = function (Tables, callback) {
  var create_query = sqlQuery._properties.create_Tables;
  sequelize.query(create_query, {
    replacements: {
      Code: Tables.Code,
      Description: Tables.Description,
      AllowConcurrency: Tables.AllowConcurrency,
      Active: Tables.Active,
      Order: Tables.Order,
      TimeCardEntryId: Tables.TimeCardEntryId,
    },
    type: sequelize.QueryTypes.INSERT,
    model: models.Tables
  }).then(function (tables) {
    callback(tables);
  });
}


module.exports.checkIndirectLaborConcurrency = function (Tables, callback) {

  var search_for_update_query = sqlQuery._properties.check_indirect_labor_concurrency;
  sequelize.query(search_for_update_query, {
    replacements: {
      timecard_id : Tables.timecardId
    },
    type: sequelize.QueryTypes.SELECT,
    model: models.Tables
  }).then(function (tables) {

    var not_concurrency = false;

    tables.forEach(function (entry) {
      console.log("allow conncurrency============>", entry.AllowConcurrency);
      if (entry.AllowConcurrency == 0) {
        var obj = { message: "user could not able to create another entry" }
        not_concurrency = true;
      }

    });

    if (not_concurrency == true) {
      var obj = { message: "user could not able to create another entry" }
      callback(obj)
    } else {
      var obj = { message: "user can create Entry " }
      callback(obj)
    }
    // tables.forEach(function (entry) {
    //   console.log("allow conncurrency============>", entry.AllowConcurrency);
    //   if (entry.AllowConcurrency == 0) {
    //     var obj = { message: "user could not able to create another entry" }
    //     callback(obj)
    //   }
    // });
  });

}



module.exports.createIndirectLaborEntries = function (Tables, callback) {
  //saving the entry with base info
  var create_query = sqlQueryEntry._properties.create_Tables_for_entries;

  sequelize.query(create_query, {
    replacements: {
      TimeCardId: Tables.TimeCardId,
      EntryTypeId: 0,
      PaidTime: Tables.PaidTime,
      BillableTime: Tables.BillableTime,
      Completed: Tables.Completed,
      Notes: Tables.Notes,
      EntryStatusId: 0,
      Completed: Tables.Completed,
      Deleted: Tables.Deleted,
      UpdatedBy: "MetriCBoss",
      UpdatedFromIp: "MetriCBoss",
    },
    type: sequelize.QueryTypes.INSERT,
    model: models.Tables
  }).then(function (entrydata) {
    var create_query_for_Indirect_labout = sqlQuery._properties.create_Tables;
    sequelize.query(create_query_for_Indirect_labout, {
      replacements: {
        Code: Tables.Code,
        Description: Tables.Description,
        AllowConcurrency: Tables.AllowConcurrency,
        Active: Tables.Active,
        Order: Tables.Order,
        TimeCardEntryId: entrydata,
      },
      type: sequelize.QueryTypes.INSERT,
      model: models.Tables
    }).then(function (values) {
      var update_for_refId = sqlQueryEntry._properties.update_for_refId;
      sequelize.query(update_for_refId, {
        replacements: {
          id: entrydata,
          RefId: values
        },
        type: sequelize.QueryTypes.INSERT,
        model: models.Tables
      }).then(function (refIdSave) {
        var obj = { success: true, id: entrydata }
        callback(obj);
      });
    });
  });
}


module.exports.update_Tables = function (Tables, callback) {
  var update_query = sqlQuery._properties.update_Tables;
  sequelize.query(update_query, {
    replacements: {
      Id: Tables.Id,
      Code: Tables.Code,
      Description: Tables.Description,
      AllowConcurrency: Tables.AllowConcurrency,
      Active: Tables.Active,
      Order: Tables.Order,
      TimeCardEntryId: Tables.TimeCardEntryId,
    },
    type: sequelize.QueryTypes.BULKUPDATE,
    model: models.Tables
  }).then(function (tables) {
    callback(tables);
  });
}


module.exports.search_Tables_for_update = function (Tables_id, callback) {
  var search_for_update_query = sqlQuery._properties.search_for_update_Tables;
  sequelize.query(search_for_update_query, {
    replacements: {
      id: Tables_id
    },
    type: sequelize.QueryTypes.SELECT,
    model: models.Tables
  }).then(function (tables) {
    callback(tables[0]);
  });
}


module.exports.delete_Tables = function (Tables_id, callback) {
  var delete_query = sqlQuery._properties.delete_Tables;
  sequelize.query(delete_query, {
    replacements: {
      id: Tables_id
    },
    type: sequelize.QueryTypes.DELETE,
    model: models.Tables
  }).then(function () {
    callback();
  });
}
module.exports.get_all_Tables = function (callback) {
  var get_all_query = sqlQuery._properties.get_all_Tables;
  sequelize.query(get_all_query, {
    type: sequelize.QueryTypes.SELECT,
    model: models.Tables
  }).then(function (tables) {
    callback(tables);
  });
}