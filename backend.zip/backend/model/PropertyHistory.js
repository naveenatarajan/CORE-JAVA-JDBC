var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var uniqueValidator = require('mongoose-unique-validator');
var autoIncrement = require('mongoose-auto-increment');

var propertyHistorySchema = new Schema({

    id:{type:Number},
    property_key:{type:String, required:true},
    countyorparish:{type:String, required:true},
    address:{type:String, required:true},
    postal_code:{type:String, required:true},
    list_price:{type:Number, required:true},
    closeprice:{type:Number, required:true},
    sq_ft_heated:{type:Number, required:true},
    sub_division_name:{type:String, required:true},
    year:{type:Number, required:true},
    water_frontage:{type:String, required:true},
    history_year:{type:String, required:true}

},{
    versionKey:false
});
autoIncrement.initialize(mongoose);

propertyHistorySchema.plugin(uniqueValidator);
propertyHistorySchema.plugin(autoIncrement.plugin,{model:'propertyHistory' , startAt:1});
var propertyHistoryDetails = mongoose.model('propertyHistory', propertyHistorySchema, 'PropertyHistory');

module.exports = propertyHistoryDetails;