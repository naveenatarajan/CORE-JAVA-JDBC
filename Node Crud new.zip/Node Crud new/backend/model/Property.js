var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var uniqueValidator = require('mongoose-unique-validator');
var autoIncrement = require('mongoose-auto-increment');

var propertySchema = new Schema({

    id:{type:Number},
    property_key:{type:String, required:true},
    address:{type:String, required:true},
    postal_code:{type:String, required:true},
    list_price:{type:Number, required:true},
    sq_ft_heated:{type:Number, required:true},
    sub_division_name:{type:String, required:true},
    water_frontage:{type:String, required:true},
    year:{type:Number, required:true},
    city:{type:String, required:true},
    county:{type:String, required:true},    
    status:{type:String, required:true},
    user_action:{type:String, required:true},
    historical_high_sold_price_per_sq_ft:{type:Number, required:true},
    notes:{type:String, default:null},
    legalDescription:{type:String, default:null},
    taxId:{type:String, default:null},
    View:{type:String,required:true},

},{
    versionKey:false
});
autoIncrement.initialize(mongoose);

propertySchema.plugin(uniqueValidator);
propertySchema.plugin(autoIncrement.plugin,{model:'property' , startAt:1});
var propertyDetails = mongoose.model('property', propertySchema, 'Property');

module.exports = propertyDetails;