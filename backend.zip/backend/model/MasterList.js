var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var uniqueValidator = require('mongoose-unique-validator');
var autoIncrement = require('mongoose-auto-increment');

var MasterlistSchema = new Schema({
    createdby: { type: Number },
    createddate: { type: Number },
    description: { type: String },
    title: { type: String },
    updatedby: { type: Number },
    updateddate: { type: Number },
    listId: { type: Number },
    listtype: { type: String }
},{
    versionKey:false
});

autoIncrement.initialize(mongoose);
MasterlistSchema.plugin(uniqueValidator);
MasterlistSchema.plugin(autoIncrement.plugin,{ model:'masterlistdata', startAt:1 });
var masterlistdata = mongoose.model ('masterlistdata',MasterlistSchema,'masterlistdata');

module.exports = masterlistdata;
