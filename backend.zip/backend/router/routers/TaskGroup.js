var express = require('express');
var apiRouter = express.Router();
var TaskGroupController = require('../../controller/TaskGroupController');

apiRouter.post('/create_taskgroup', TaskGroupController.addtask);
apiRouter.get ('/gettaskgroup',TaskGroupController.gettasklist);
apiRouter.put ('/updategrouptask',TaskGroupController.updatetaskgroup);
apiRouter.delete('/deletetaskgroup/:id',TaskGroupController.deletetask);


module.exports = apiRouter;