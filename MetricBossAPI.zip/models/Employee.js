'use strict';

module.exports = function (sequelize, DataTypes) {
  var Tables = sequelize.define("Employee", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    FirstName: DataTypes.STRING,
    MiddleName: DataTypes.STRING,
    LastName: DataTypes.STRING,
    EmployeeTypeId: DataTypes.INTEGER,
    EmployeeNumber: DataTypes.STRING,
    OrganizationalUnitId: DataTypes.INTEGER,
    Active: DataTypes.INTEGER,
    Order: DataTypes.INTEGER,
    ManagerId: DataTypes.INTEGER, 
  }, {
      createdAt: false,
      updatedAt: false,
      freezeTableName: true
    });
  return Tables;
};