'use strict';

angular.module('myApp.view3', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/view3', {
    templateUrl: 'view3/view3.html',
    controller: 'View3Ctrl'
  });
}])


.controller('View3Ctrl', ['$scope','$location',function($scope,$location) {
	
      /*$scope.myClick = function $location.path('/view2Ctrl'){
		console.log('From register to login');
	}*/
	$scope.count = 0;
    $scope.myFunc = function() {
        $scope.count++;
    };

    $scope.names = ["Male", "Female", "Others"];

   $scope.myClick=(function(){
   $location.path('/view1.html'); 
   alert('login page'); 
    });

	$scope.records = [
    "Refrence Guide->",
    "Frequently Asked Questions->",
    "MyPack Portal->",
    ]

}]);
