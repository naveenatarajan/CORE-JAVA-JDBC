var propertyHistory = require('../model/PropertyHistory');


//Insert a property
module.exports.insert_property_history = (data, callback) => {
    var propertyHistoryData = new propertyHistory(data);
    propertyHistoryData.save(function (propertyHistoryData, err) {
        if (err) {
            callback(err);
        } else {
            console.log('Property inserted.', data);
            callback(data);
        }
    });
}

//get all properties
module.exports.get_history_by_key = (property_key, callback) => {
    propertyHistory.find({ 'property_key': property_key }, function (err, response) {
        console.log("Custom query:", response);
        if (err) {
            callback(err);
        } else {
            callback(null, response);
        }
    });
}
//get all propertyhistory
module.exports.all_propertyhistory = (callback) => {

    propertyHistory.find(function (data, err) {

        if (err) {
            callback(err);
        } else {
            callback(data);
        }
    });
}


//update propertyhistory
module.exports.update_propertyhistory = (id, propertyhistory, callback) => {

    propertyHistory.findOneAndUpdate({ _id: id }, {
        $set: propertyhistory
    }, { upsert: true, new: true }, function (err, data) {

        if (err) {
            callback(err);
        } else {
            callback(data);
        }
    })

}
//delete property historry
module.exports.delete_propertyhistory = function(id, callback){
    propertyHistory.findByIdAndRemove({_id: id}, function(err, data){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}

//search property historry
module.exports.search_propertyhistory = function(id, callback){
    propertyHistory.findOne({_id: id}, function(err, data){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}