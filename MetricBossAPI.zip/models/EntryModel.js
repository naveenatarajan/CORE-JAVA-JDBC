'use strict';

module.exports = function(sequelize, DataTypes) {
  var Tables = sequelize.define("Entry", {
    id: {
    	type : DataTypes.INTEGER,
    	primaryKey : true,
    	autoIncrement : true
    },
    EntryTypeId: DataTypes.INTEGER,
    // In: DataTypes.TIMESTAMP,
    // Out:DataTypes.TIMESTAMP,
    PaidTime:DataTypes.INTEGER,
    BillableTime:DataTypes.INTEGER,
    RefId:DataTypes.INTEGER,
    Completed:DataTypes.DOUBLE,
    Notes:DataTypes.STRING,
    EntryStatusId:DataTypes.INTEGER,
    Deleted:DataTypes.INTEGER,
    // Updated:DataTypes.TIMESTAMP,
    UpdatedBy:DataTypes.STRING,
    UpdatedFromIp:DataTypes.STRING,
    TimeCardId:DataTypes.INTEGER,
  },{
    createdAt: false,
    updatedAt: false,
    freezeTableName:true
  });
  return Tables;
};