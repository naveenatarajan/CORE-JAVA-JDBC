package com.example.demo.employeerecord;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "EmployeeB")
public class EmployeeRecordDetail {
	 @Id
	  @GeneratedValue(strategy = GenerationType.AUTO)
	    private long id;
	    private long numberOfEmployees;
	    
	  public EmployeeRecordDetail(){

	    }

	    public EmployeeRecordDetail(long numberOfEmployees){
	        this.numberOfEmployees = numberOfEmployees;
	    }
	   
	    public long getId() {
	        return id;
	    }

	    public void setId(long id) {
	        this.id = id;
	    }

	    public long getNumberOfEmployees() {
	        return numberOfEmployees;
	    }

	    public void setNumberOfEmployees(long numberOfEmployees) {
	        this.numberOfEmployees = numberOfEmployees;
	    }

	  }



