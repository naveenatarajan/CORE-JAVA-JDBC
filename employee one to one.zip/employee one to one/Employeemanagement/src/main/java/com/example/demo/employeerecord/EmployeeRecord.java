package com.example.demo.employeerecord;

import javax.persistence.CascadeType;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;


@Entity
@Table(name = "EmployeeA")
public class EmployeeRecord {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@NotNull
	private String name;
	@NotNull
	private String dept;
	
	 @OneToOne(cascade = CascadeType.ALL,fetch=FetchType.EAGER)
	 private EmployeeRecordDetail employeerecorddetail;

public EmployeeRecord() {
	}

	 
	public EmployeeRecord(String name, String dept, EmployeeRecordDetail employeerecorddetail) {
		this.name = name;
		this.dept = dept;
		this.employeerecorddetail = employeerecorddetail;
	}

	public long getId() {
		return id;
	}

 

	public String getName() {
		return name;
	}

	public void setName(String value) {
		this.name = value;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String value) {
		this.dept = value;
	}

	
	public EmployeeRecordDetail getEmployeeRecordDetail() {
		return employeerecorddetail;
	}

	public void setEmployeeRecordDetail(EmployeeRecordDetail employeerecorddetail) {
		this.employeerecorddetail = employeerecorddetail;
	}
	
	  public void setId(long id) {
		this.id = id;
	}


	@Override 
	  public String toString() {
		  return String.format(" EmployeeA[id=%d, name='%s', dept='%s', number of employees='%d']",
	              id, name, dept, employeerecorddetail.getNumberOfEmployees()); 
	  }
	 
}
