module.exports = {
    mongoURL: 'mongodb://54.156.240.171:27017/aerobit',
    port: 8000
};

// module.exports = {
//     mongoURL: 'mongodb://localhost:27017/aerobit',
//     port: 8000
// };

