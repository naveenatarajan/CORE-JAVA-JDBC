package com.example.demo.bookrepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Book.Book;
import com.example.demo.Book.BookVaries;

public interface BookVariesRepository extends JpaRepository<BookVaries, Integer>{
	void deleteById(int id);

	public  List<Book> findById(int id);

}