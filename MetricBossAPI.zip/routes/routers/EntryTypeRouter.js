var express = require("express");
var router = express.Router();
var controller = require("../../controllers/EntryTypeController")
router.post("", controller.create_Entry);
router.get("/:id", controller.search_Entry_for_update);
router.put("", controller.update_Entry);
router.delete("/:id", controller.delete_Entry);
router.get("", controller.get_all_Entry);

module.exports = router;