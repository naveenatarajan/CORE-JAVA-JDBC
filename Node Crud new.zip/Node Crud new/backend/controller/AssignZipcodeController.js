var AssignZipcodeService = require('../service/AssignZipcodeService');

module.exports.assignZipcodeToUser = (req, res) => {
    var AssignZipcodeDetails = req.body;
    console.log("data-------------->",AssignZipcodeDetails)
    AssignZipcodeService.assignZipcodeToUser(AssignZipcodeDetails, function (data, err) {
        console.log("");
        if (err) {
            res.status(500).send(err);
        } else {
            res.status(201).send(data);
        }
    })
}

module.exports.getAssignedUser = (req, res) => {
    var UserId = req.params.userId;

    AssignZipcodeService.getAssignedUser(UserId, function (data, err) {
        console.log("");
        if (err) {
            res.status(500).send(err);
        }
        else {
            res.status(200).send(data);
        }
    })
}

module.exports.getCityForUser = (req, res) => {
    var _id = req.params._id;
    var state = req.params.state;
    AssignZipcodeService.getCityForUser(_id, state, function (usercities, err) {
        console.log("");
        if (err) {
            res.status(500).send(err);
        }
        else {
            res.status(200).send(usercities);
        }
    })
}

module.exports.removeAssignedUser = (req, res) => {
    var username = req.params.username;
    var zipcode = req.params.zipcode;

    AssignZipcodeService.removeAssignedUser(username, zipcode, function (data, err) {
        console.log("");
        if (err) {
            res.status(500).send(err);
        }
        else {
            res.status(200).send(data);
        }
    })
}

module.exports.getPostalCodeForCity = (req, res) => {
    var city = req.params.city;
    var userId = req.params.userId;

    AssignZipcodeService.getPostalCodeForCity(city,userId, function(postalcode, err) {
        console.log("");
        if(err){
            res.status(500).send(err);
        }
        else {
            res.status(200).send(postalcode);
        }
    })
}

module.exports.getPostalForAssignUser = (req,res) => {
    var state = req.params.state;
    var city = req.params.city;
    var id = req.params.id;

    AssignZipcodeService.getPostalForAssignUser(state,city,id, function(postalcode, err) {
        console.log("");
        if(err){
            res.status(500).send(err);
        }
        else {
            res.status(200).send(postalcode);
        }
    })
}

//user cities count
module.exports.getUserCityCount = (req,res) => {
    var city = req.param('city');
    AssignZipcodeService.getUserCityCount(city ,function(cities,err){
       if(err){
           res.status(500).send(err);
       }
       else{
           var counts = {
               value : cities.length
           };
           res.status(200).send(counts);
       }
   })
}