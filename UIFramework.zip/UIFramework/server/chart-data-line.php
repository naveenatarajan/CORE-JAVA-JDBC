<?php

$data = array(
    array(
     'label' => 'Complete',
     'color' => '#5ab1ef',
     'data' => 
     array(
      array('Jan', 188),
      array('Feb', 183),
      array('Mar', 185),
      array('Apr', 199),
      array('May', 190),
      array('Jun', 194),
      array('Jul', 194),
      array('Aug', 184),
      array('Sep', 74)
    )
  ),
  array(
     'label' => 'In Progress',
     'color' => '#f5994e',
     'data' => 
     array(
      array('Jan', 153),
      array('Feb', 116),
      array('Mar', 136),
      array('Apr', 119),
      array('May', 148),
      array('Jun', 133),
      array('Jul', 118),
      array('Aug', 161),
      array('Sep', 59)
    ),
  ),
  array(
     'label' => 'Cancelled',
     'color' => '#d87a80',
     'data' => 
     array(
      array('Jan', 111),
      array('Feb', 97),
      array('Mar', 93),
      array('Apr', 110),
      array('May', 102),
      array('Jun', 93),
      array('Jul', 92),
      array('Aug', 92),
      array('Sep', 44)
    )
  )
);

?>