package com.social.login.social_login_kotlin


import java.util.HashMap

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.core.ResolvableType
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken
import org.springframework.security.oauth2.client.registration.ClientRegistration
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository
import org.springframework.stereotype.Component
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.client.RestTemplate

@Controller
class LoginController {
    internal var oauth2AuthenticationUrls: MutableMap<String, String> = HashMap()

    @Autowired
    private val authorizedClientService: OAuth2AuthorizedClientService? = null

    @Autowired
    private val clientRegistrationRepository: ClientRegistrationRepository? = null

    @GetMapping("/oauth_login")
    fun getLoginPage(model: Model): String {
        println("-- > " + model.toString())

        var clientRegistrations: Iterable<ClientRegistration>? = null
        val type = ResolvableType.forInstance(clientRegistrationRepository!!)
                .`as`(Iterable::class.java)
        println("type.resolveGenerics()[0]- > " + type.resolveGenerics()[0])
        if (type !== ResolvableType.NONE && ClientRegistration::class.java.isAssignableFrom(type.resolveGenerics()[0])) {
            clientRegistrations = clientRegistrationRepository as Iterable<ClientRegistration>?
        }

        clientRegistrations!!.forEach { n ->

            oauth2AuthenticationUrls[n.clientName] = authorizationRequestBaseUri + "/" + n.registrationId
        }

        model.addAttribute("urls", oauth2AuthenticationUrls)
        println("-- urls -------- > " + oauth2AuthenticationUrls.toString())

        return "oauth_login"
    }

    @GetMapping("/loginSuccess")
    fun getLoginInfoSucess(model: Model, authentication: OAuth2AuthenticationToken): String {
        println("Inside Success")
        val client = authorizedClientService!!
                .loadAuthorizedClient<OAuth2AuthorizedClient>(
                        authentication.authorizedClientRegistrationId,
                        authentication.name)
        val userInfoEndpointUri = client.clientRegistration
                .providerDetails.userInfoEndpoint.uri

        println("userInfoEndpointUri - > " + userInfoEndpointUri!!)

        if (userInfoEndpointUri != null || userInfoEndpointUri !== "") {
            val restTemplate = RestTemplate()
            val headers = HttpHeaders()
            println("client.getAccessToken()- > " + client.accessToken.tokenValue)
            headers.add(HttpHeaders.AUTHORIZATION, "Bearer " + client.accessToken
                    .tokenValue)
            val entity = HttpEntity("", headers)
            val response = restTemplate
                    .exchange(userInfoEndpointUri, HttpMethod.GET, entity, Map::class.java)
            val userAttributes = response.body
            model.addAttribute("name", userAttributes!!["name"])

            println("userAttributes.get(\"name\") - > " + userAttributes.toString())
        }
        println("hai sssssssssssssssssss")
        return "loginSuccess"
    }

    @GetMapping("/loginFailure")
    fun loginFailure(model: Model, authentication: OAuth2AuthenticationToken): String {
        println("hai login Failed")

        return "loginError"
    }

    companion object {

        private val authorizationRequestBaseUri = "oauth2/authorization"
    }
}
