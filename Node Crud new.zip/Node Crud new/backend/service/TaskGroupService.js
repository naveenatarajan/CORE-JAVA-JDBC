var TaskgroupDao = require('../dao/TaskGroupDao');

module.exports.addtask = (addtask, callback) => {

    TaskgroupDao.addtask(addtask, function (err, addtask) {

        if (err) {
            callback(err);
        } else {
            callback(addtask);
        }
    });
}

module.exports.gettasklist = (callback) => {

    TaskgroupDao.gettasklist(function (err, gettasklist) {

        if (err) {
            callback(err);
        } else {
            callback(gettasklist);
        }
    });

}

module.exports.updatetask = (id, description, groupid, groupname, callback) => {

    TaskgroupDao.updategrouplist(id, description, groupid, groupname, function (err, data) {

        if (err) {
            callback(err);
        } else {
            callback(data);
        }

    })
}

module.exports.deletelist = (_id, callback) => {

    TaskgroupDao.deletetask(_id, function (err, data) {
        if (err) {
            callback(err);
        } else {
            callback(data);
        }
    });
}