package com.example.demo.Book;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "bookpublisher")
public class BookPublisher {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column
	private String publishname;
	
	@ManyToMany(cascade = CascadeType.ALL, mappedBy = "bookpublisher", fetch = FetchType.EAGER)
	private List<Book> books;
	
	public BookPublisher(){

    }
	
	public BookPublisher(String publishname){
        this.publishname = publishname;
    }

    public BookPublisher(String publishname, List<Book> books){
        this.publishname = publishname;
        this.books = books;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPublishname() {
        return publishname;
    }

    public void setPublishname(String publishname) {
        this.publishname = publishname;
    }

    public  List<Book> getBooks() {
        return books;
    }

    public void setBooks( List<Book> books) {
        this.books = books;
    }
}

