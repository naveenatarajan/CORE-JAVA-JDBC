var Masterlist = require('../model/MasterList');

//addmasterlist

module.exports.addmasterlist = (masterlistdata, callback) => {
    console.log("srrs---------------->", masterlistdata)
    var masterlist = new Masterlist(masterlistdata);
    masterlist.save(function (data, err) {
        if (err) {
            callback(err);
        } else {
            console.log('master------------', data);
            callback(data);
        }
    })
}

//getallmasterlist

module.exports.getalllist = (callback) => {

    Masterlist.find(function (data, err) {

        if (err) {
            callback(err);
        } else {
            callback(data);
        }
    });
}

//Updatemasterlist

module.exports.updatemasterlist = (id, listdetails, callback) => {
    Masterlist.findOneAndUpdate({_id : id }, {$set:listdetails},{ upsert: true, new: true }, function (err, listdetails) {
        if (err) {
            callback(err);
        } else {
            callback(listdetails);
        }
    })

}

//deletemasterlist

module.exports.deletealllist = (id,callback) =>{

    Masterlist.deleteOne({_id:id},function(data,err){
        if(err){
            callback(err);
        }else{
            console.log('delete----------------->>',data)
            callback(data);
        }
    })
}