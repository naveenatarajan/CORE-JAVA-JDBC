var express = require("express");
var http = require("http");
var path = require("path");
var models = require("./models");
var sequelize = models.sequelize;
var router   = require("./routes/routes");
var logger = require("morgan");
var bodyParser = require('body-parser');

var app = express();
var clientPath = path.resolve(__dirname, "client");
const jwt = require('express-jwt');
const jwksRsa = require('jwks-rsa');
var jwtAuthz = require('express-jwt-authz');
var request = require("request");

var swaggerJSDoc = require('swagger-jsdoc');
var swaggerDefinition = {
  info: {
    title: 'MetricBoss API',
    version: '1.0.0',
    description: 'RESTful API with Swagger',
  },
  //host: 'api.metricboss.com',
   host: 'localhost:3000',
  basePath: '/',
};


var options = {
  // import swaggerDefinitions
  swaggerDefinition: swaggerDefinition,
  // path to the API docs
  apis: ['./Swagger/*.js'],
};

// initialize swagger-jsdoc
var swaggerSpec = swaggerJSDoc(options);

// serve swagger
app.get('/swagger.json', function (req, res) {
  res.setHeader('Content-Type', 'application/json');
  res.send(swaggerSpec);
});

const checkJwt = jwt({
  secret: jwksRsa.expressJwtSecret({
    cache: true,
    rateLimit: true,
    jwksRequestsPerMinute: 5,
    jwksUri: `https://brush.auth0.com/.well-known/jwks.json`
  }),
  audience: 'https://brush.auth0.com/api/v2/',
  issuer: `https://brush.auth0.com/`,
  algorithms: ['RS256']
});


app.get('/login', function (req, res) {
  var options = {
    method: 'POST',
    url: 'https://brush.auth0.com/oauth/token',
    headers: { 'content-type': 'application/json' },
    body: '{"client_id":"TdRDSGOyNkK5V1AyTPT2HXiV9B4VJAyk","client_secret":"BCSu2_7GuALccW5CcZhIvB6HH48LBxn_KGE73NmYoWvPQHsdKQ_S6dE2v5QjBsPp","audience":"https://brush.auth0.com/api/v2/","grant_type":"client_credentials"}'
  };
  request(options, function (error, response, body) {
    if (error) throw new Error(error);
    var parsed_json = JSON.parse(body)
    res.json(parsed_json);
  });
});



app.use(express.static(path.join(__dirname, 'public')));
app.use(checkJwt);



app.use(bodyParser.json({ limit: '50mb' }))
app.use(logger("dev"));
app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, Accept, Content-Type, Content-Length, Authorization, X-Requested-With, X-XSRF-TOKEN");
  res.header("Access-Control-Allow-Methods", "PUT, POST, GET, DELETE, OPTIONS");
  if (req.method === 'OPTIONS') {
    console.log('OPTIONS SUCCESS');
    res.end();
  }
  next();
});

app.use("/", express.static(clientPath));

app.use("/", router);
app.all('*', function (req, res) {
  res.status(200).sendFile(path.join(__dirname, 'public'));
});


models.sequelize.sync().then(function () {
    var server = app.listen(3000, function () {
    console.log('Express server listening on port ' + server.address().port);
  });
});
