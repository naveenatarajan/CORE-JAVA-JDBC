var express = require("express");
var router = express.Router();
var controller = require("../../controllers/TimeCardController")
router.post("", controller.create_Tables);
router.post("/UpdateOutTime", controller.UpdateOutTime);
//router.get("/:id", controller.search_Tables_for_update);
router.put("", controller.update_Tables);
router.delete("/:id", controller.delete_Tables);
router.get("", controller.get_all_Tables);
router.get("/tables",controller.search_by_params);

module.exports = router;