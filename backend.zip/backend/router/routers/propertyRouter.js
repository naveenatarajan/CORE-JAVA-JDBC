var express = require('express');
var apiRouter = express.Router();
var PropertyController = require('../../controller/propertyController');

apiRouter.post('/create', PropertyController.insert_property);
apiRouter.get('/getallproperty', PropertyController.getproperty);
apiRouter.put ('/updateproperty',PropertyController.updateproperty);
apiRouter.delete('/deleteproperty/:id',PropertyController.deleteproperty);
apiRouter.get('/getByCityAndZip', PropertyController.get_by_city_zip);
apiRouter.get('/searchproperty',PropertyController.searchproperty);
apiRouter.get('/getpostalcode',PropertyController.getpostalbycity);
apiRouter.get('/viewedproperty',PropertyController.viewedProperty);
apiRouter.get('/getbyadderss',PropertyController.getByAddress)
module.exports = apiRouter;
