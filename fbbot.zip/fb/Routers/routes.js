var express = require("express");
var api = express.Router();
var routers = require("./router")

api.use("/facebook", routers.Facebook)

module.exports = api;