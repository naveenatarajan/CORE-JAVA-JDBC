var models = require("../models");
var sequelize = models.sequelize;
var PropertiesReader = require('properties-reader');
var sqlQuery = PropertiesReader(__dirname + '/../sql_queries/Employee_SQL.properties');
module.exports.create_Tables = function (Tables, callback) {
  var create_query = sqlQuery._properties.create_Tables;
  sequelize.query(create_query, {
    replacements: {
      FirstName: Tables.FirstName,
      MiddleName: Tables.MiddleName,
      LastName: Tables.LastName,
      EmployeeTypeId: Tables.EmployeeTypeId,
      EmployeeNumber: Tables.EmployeeNumber,
      OrganizationalUnitId: Tables.OrganizationalUnitId,
      Active: Tables.Active,
      Order: Tables.Order,
      ManagerId: Tables.ManagerId,
    },
    type: sequelize.QueryTypes.INSERT,
    model: models.Tables
  }).then(function (tables) {
    callback(tables);
  });
}
module.exports.update_Tables = function (Tables, callback) {
  var update_query = sqlQuery._properties.update_Tables;
  sequelize.query(update_query, {
    replacements: {
      id: Tables.id,
      FirstName: Tables.FirstName,
      MiddleName: Tables.MiddleName,
      LastName: Tables.LastName,
      EmployeeTypeId: Tables.EmployeeTypeId,
      EmployeeNumber: Tables.EmployeeNumber,
      OrganizationalUnitId: Tables.OrganizationalUnitId,
      Active: Tables.Active,
      Order: Tables.Order,
      ManagerId: Tables.ManagerId,
    },
    type: sequelize.QueryTypes.BULKUPDATE,
    model: models.Tables
  }).then(function (tables) {
    callback(tables);
  });
}
module.exports.search_Tables_for_update = function (Tables_id, callback) {
  var search_for_update_query = sqlQuery._properties.search_for_update_Tables;
  sequelize.query(search_for_update_query, {
    replacements: {
      id: Tables_id
    },
    type: sequelize.QueryTypes.SELECT,
    model: models.Tables
  }).then(function (tables) {
    callback(tables[0]);
  });
}
module.exports.delete_Tables = function (Tables_id, callback) {
  var delete_query = sqlQuery._properties.delete_Tables;
  sequelize.query(delete_query, {
    replacements: {
      id: Tables_id
    },
    type: sequelize.QueryTypes.DELETE,
    model: models.Tables
  }).then(function () {
    callback();
  });
}
module.exports.get_all_Tables = function (callback) {
  var get_all_query = sqlQuery._properties.get_all_Tables;
  sequelize.query(get_all_query, {
    type: sequelize.QueryTypes.SELECT,
    model: models.Tables
  }).then(function (tables) {
    callback(tables);
  });
}