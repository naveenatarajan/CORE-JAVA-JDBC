import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class HomeComponent extends Component {
  render() {
    return (
      <div >
        <h2>Normal Home </h2>
        <a href='/profile'>cc</a>
      </div>
    );
  }
}

export default HomeComponent;
