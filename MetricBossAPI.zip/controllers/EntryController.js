var service = require("../services/EntryService")
module.exports.create_Entry = function(req, res) {
  var Tables = req.body;
  service.create_Entry(Tables,function (tables){
    res.status(201);
    res.json(tables);
  });
}
module.exports.update_Entry = function(req, res) {
  var Tables = req.body;
  service.update_Entry(Tables,function (tables){
    res.status(201);
    res.json(tables);
  });
}
module.exports.search_Entry_for_update = function(req, res) {
  var Tables_id = req.params.id;
  service.search_Entry_for_update(Tables_id,function (tables){
    res.json(tables);
  });
}
module.exports.delete_Entry = function(req, res) {
  var Tables_id = req.params.id;
  service.delete_Entry(Tables_id,function (){
    res.status(204);
    res.end();
  });
}
module.exports.get_all_Entry = function(req, res) {
  var tables_id = req.query.id;
  service.get_all_Entry(function (tables){
    res.json(tables);
  });
}