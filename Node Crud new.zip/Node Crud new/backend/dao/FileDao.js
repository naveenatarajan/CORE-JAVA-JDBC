var File = require('../model/File');

//create contract
module.exports.createContract = (filedetails, callback) =>{
    console.log("srrs---------------->",filedetails)
    var file = new File(filedetails);     
    file.save(function(data, err){
        if(err){
            callback(err);
        }else{
            console.log('Usr-----------',data);
            callback(data);
        }
    })
}
//get file for pdf
module.exports.getPdfForUser = (userId, callback) => {
    console.log("ssss-----yuyuyuygyy----->",userId)
    File.findOne({userId:userId},function (err, data) {
        if(err){
            console.log("error...........")
        }
        else{
            console.log("-- - - --",data)
            console.log('pdf ---->',data);
            callback(data);
        }
    })
}
//del property
module.exports.delProperty = (id, callback) => {
    File.findByIdAndRemove({_id:id},function (err, data) {
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}

//find by filename
module.exports.findFile = (filname, callback) => {
    File.findOne({_filname:filname},function (err, data) {
        if(err){
            callback(err);
            console.log("eeeeerrrrrrrr",err)
        }else{
            console.log("dataaaeeeeeeeeeeeeeeeeeeeee",data)
            callback(data);
        }
    })
}


//find by filename
module.exports.findProperty = (property, callback) => {
    File.findOne({_property:property},function (err, data) {
        if(err){
            callback(err);
            console.log("eeeeerrrrrrrr",err)
        }else{
            console.log("dataaaeeeeeeeeeeeeeeeeeeeee",data)
            callback(data);
        }
    })
}