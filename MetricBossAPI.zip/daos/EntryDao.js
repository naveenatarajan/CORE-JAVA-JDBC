var models = require("../models");
var sequelize = models.sequelize;
var PropertiesReader = require('properties-reader');
var entryDao = require("../daos/EntryChangeLogDao")
var sqlQuery = PropertiesReader(__dirname + '/../sql_queries/Entry_SQL.properties');
module.exports.create_Entry = function (Tables, callback) {
  console.log("Dao", Tables)
  var create_query = sqlQuery._properties.create_Tables;
  sequelize.query(create_query, {
    replacements: {

      EntryTypeId: Tables.EntryTypeId,
      Out: new Date(Tables.Out),
      PaidTime: Tables.PaidTime,
      BillableTime: Tables.BillableTime,
      RefId: Tables.RefId,
      Completed: Tables.Completed,
      Notes: Tables.Notes,
      EntryStatusId: Tables.EntryStatusId,
      Completed: Tables.Completed,
      Deleted: Tables.Deleted,

      UpdatedBy: Tables.UpdatedBy,
      UpdatedFromIp: Tables.UpdatedFromIp,
      TimeCardId: Tables.TimeCardId
    },
    type: sequelize.QueryTypes.INSERT,
    model: models.Tables
  }).then(function (tables) {

    Tables.Revision = 1;
    Tables.Action = "CREATE";
    Tables.EntryId = tables;

    entryDao.create_Tables(Tables, function (EntryLogId) {
      var object = { Success: true, data: tables }
      callback(object);
    });


    //callback(tables);
  });
}
module.exports.update_Entry = function (Tables, callback) {
  var update_query = sqlQuery._properties.update_Tables;
  sequelize.query(update_query, {
    replacements: {
      id: Tables.id,
      EntryTypeId: Tables.EntryTypeId,
      // In : Tables.In,
      // Out : Tables.Out,
      PaidTime: Tables.PaidTime,
      BillableTime: Tables.BillableTime,
      RefId: Tables.RefId,
      Completed: Tables.Completed,
      Notes: Tables.Notes,
      EntryStatusId: Tables.EntryStatusId,
      Completed: Tables.Completed,
      Deleted: Tables.Deleted,
      Updated: new Date(),
      UpdatedBy: Tables.UpdatedBy,
      UpdatedFromIp: Tables.UpdatedFromIp,
      TimeCardId: Tables.TimeCardId
    },
    type: sequelize.QueryTypes.BULKUPDATE,
    model: models.Tables
  }).then(function (tables) {
    Tables.Revision = 1;
    Tables.Action = "UPDATE";
    Tables.EntryId = Tables.id;
    entryDao.create_Tables(Tables, function (EntryLogId) {
      var object = { Success: true, data: tables }
      callback(object);
    });
  });
}


module.exports.search_Entry_for_update = function (Tables_id, callback) {
  var search_for_update_query = sqlQuery._properties.search_for_update_Tables;
  sequelize.query(search_for_update_query, {
    replacements: {
      id: Tables_id
    },
    type: sequelize.QueryTypes.SELECT,
    model: models.Tables
  }).then(function (tables) {
    callback(tables[0]);
  });
}

module.exports.delete_Entry = function (Tables_id, callback) {
  
  exports.search_Entry_for_update(Tables_id, function (selected_data) {
    //console.log("able", tables)
    var delete_query = sqlQuery._properties.delete_Tables;
    sequelize.query(delete_query, {
      replacements: {
        id: Tables_id
      },
      type: sequelize.QueryTypes.DELETE,
      model: models.Tables
    }).then(function () {
      console.log("selected data", selected_data)
      selected_data.Revision = 1;
      selected_data.Action = "DELETE";
      selected_data.EntryId = selected_data.Id
      entryDao.create_Tables(selected_data, function (TimeCardLogId) {
        var object = { Success: true }
        callback(object);
      });
    });
  });
  // var delete_query = sqlQuery._properties.delete_Tables;
  // sequelize.query(delete_query, {
  //   replacements: {
  //     id: Tables_id
  //   },
  //   type: sequelize.QueryTypes.DELETE,
  //   model: models.Tables
  // }).then(function () {
  //   callback();
  // });
}

module.exports.get_all_Entry = function (callback) {
  var get_all_query = sqlQuery._properties.get_all_Tables;
  sequelize.query(get_all_query, {
    type: sequelize.QueryTypes.SELECT,
    model: models.Tables
  }).then(function (tables) {
    callback(tables);
  });
}