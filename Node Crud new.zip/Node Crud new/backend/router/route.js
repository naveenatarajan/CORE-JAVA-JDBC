var express = require('express');
var api = express.Router();
var Router = require('./routers');

api.use('/reuser', Router.ReuserRouter);
api.use('/City', Router.CityRouter);
api.use('/assignzipcode', Router.AssignZipcode);
api.use('/property', Router.propertyRouter);
api.use('/propertyHistory', Router.propertyHistory);
api.use('/file', Router.FileRouter);
api.use('/defaultfields', Router.DefaultFields);
api.use('/master_list', Router.MasterList);
api.use('/taskgroup', Router.TaskGroup);
api.use('/taskcomment', Router.Taskcomment);
api.use('/mail',Router.Mail);
module.exports = api;