var express = require('express');
var apiRouter = express.Router();
var RegistrationController = require('../../controller/RegistrationController');

//Reuser
apiRouter.post('/Signup', RegistrationController.signUp);
apiRouter.put('/emailConfirmation', RegistrationController.updateUser);
apiRouter.delete('/removeUser', RegistrationController.deleteUser);
apiRouter.get('/get_users',RegistrationController.getUsers);
apiRouter.put('/set_user_percentage/:percentage/:_id',RegistrationController.setUserPercentage);
apiRouter.get('/get_user/:userId',RegistrationController.getUserId);
module.exports = apiRouter;