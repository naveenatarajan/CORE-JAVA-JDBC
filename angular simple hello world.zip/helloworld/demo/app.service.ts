import { 
   Injectable 
} from '@angular/core';  

@Injectable()
export class Service {  
   getApp(): string { 
      return "Hello "; 
   } 
} 