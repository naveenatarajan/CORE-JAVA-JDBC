var express = require ('express');
var apiRouter = express.Router();
var Taskcommentcontroller = require ('../../controller/TaskcommentController');

apiRouter.post('/createtaskcomment', Taskcommentcontroller.createcomment);
apiRouter.get ('/getallcomment', Taskcommentcontroller.gettaskcomment);


module.exports = apiRouter;