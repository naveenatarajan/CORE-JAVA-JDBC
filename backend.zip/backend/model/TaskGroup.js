var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var uniqueValidator = require('mongoose-unique-validator');
var autoIncrement = require('mongoose-auto-increment');

var TasklistSchema = new Schema({
    createdby: { type: String },
    createddate: { type: Number },
    description: { type: String },
    groupid: { type: String },
    groupname: { type: String },
    updatedby: { type: String },
    updatedate: { type: Number }
}, {
        versionKey: false,
    });

autoIncrement.initialize(mongoose);
TasklistSchema.plugin(uniqueValidator);
TasklistSchema.plugin(autoIncrement.plugin, { model: 'tasklist', startAt: 1 });
var tasklist = mongoose.model('tasklist', TasklistSchema, 'tasklist');

module.exports = tasklist;
