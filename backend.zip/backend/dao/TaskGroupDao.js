var Taskgroup = require('../model/TaskGroup');

//addtask

module.exports.addtask = (addtask, callback) => {

    var tasklist = new Taskgroup(addtask);
    tasklist.save(function (data, err) {

        if (err) {
            callback(err);
        } else {
            callback(data);
        }
    });
}

//getatskgroup

module.exports.gettasklist = (callback) => {

    Taskgroup.find(function (data, err) {

        if (err) {
            callback(err);
        } else {
            callback(data);
        }
    });
}

//Updatetaskgroup

module.exports.updategrouplist = (id, taskdetails, callback) => {

    Taskgroup.findOneAndUpdate({_id: id }, { $set:taskdetails },{ upsert: true, new: true }, function (err, taskdetails) {
        if (err) {
            callback(err);
        } else {
            callback(taskdetails);
        }
    })
}

module.exports.deletetask = (id, callback) => {

    Taskgroup.deleteOne({_id: id }, function (data, err) {
        console.log("id-------------------------", id);
        if (err) {
            callback(err);
        } else {
            callback(data);
        }
    });
}
