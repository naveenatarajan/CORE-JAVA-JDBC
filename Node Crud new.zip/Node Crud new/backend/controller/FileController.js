var FileService = require('../service/FileService');
var fs = require('fs');
var PDFDocument = require('pdfkit')
var __dirname = "/home/decoders/Documents";
var JSZip = require('jszip');
var Docxtemplater = require('docxtemplater');
var path = require('path');


//create contract form
module.exports.createContract = (req, res) => {
    var editTemplateDetails = req.body;
    var content = fs
        .readFileSync(path.resolve(__dirname, 'ASIS.docx'), 'binary');

    var zip = new JSZip(content);
    var doc = new Docxtemplater().loadZip(zip)
    var text = doc.getFullText();
   
    console.log(text);
    var address, balanceClose, buyerD, buyerFullName, buyerName, buyersIni, closingDate,
        description, initialPrice, location, mail, miami, propertyInspection, purchaseMoney,
        purchasePrice, sellerD, sellerName, sellerPA, sellerPI, taxID, warranty, purmo, ylaf, slrd,
        brds, mdia, slpi, srpa, bhw, hws, nulll


    if (text != null && editTemplateDetails.sellerName != undefined) {
        console.log("null--------------->", editTemplateDetails.sellerName);
        sellerName = editTemplateDetails.sellerName
        //doc.setData({ seller: editTemplateDetails.sellerName })
    }
    else {
        sellerName = ""
        //doc.setData({ seller: "" })
    }

    if (text != null && editTemplateDetails.buyerName != undefined) {
        console.log("null--------------->", editTemplateDetails.buyerName);
        buyerName = editTemplateDetails.buyerName
        //doc.setData({ buyer: editTemplateDetails.buyerName })
    }
    else {
        buyerName = ""
        //doc.setData({ buyer: "" })
    }

    if (text != null && editTemplateDetails.address != undefined) {
        console.log("null--------------->", editTemplateDetails.address);
        address = editTemplateDetails.address
    }
    else {
        address = ""
    }

    if (text != null && editTemplateDetails.location != undefined) {
        console.log("null--------------->", editTemplateDetails.location);
        location = editTemplateDetails.location
    }
    else {
        location = ""
    }

    if (text != null && editTemplateDetails.description != undefined) {
        console.log("null--------------->", editTemplateDetails.description);
        description = editTemplateDetails.description
    }
    else {
        description = ""
    }

    if (text != null && editTemplateDetails.closingDate != undefined) {
        console.log("null--------------->", editTemplateDetails.closingDate);
        closingdt = editTemplateDetails.closingDate
    }
    else {
        closingdt = ""
    }

    if (text != null && editTemplateDetails.buyersIni != undefined) {
        console.log("null--------------->", editTemplateDetails.buyersIni);
        buyersIni = editTemplateDetails.buyersIni
    }
    else {
        buyersIni = ""
    }

    if (text != null && editTemplateDetails.buyerFullName != undefined) {
        console.log("null--------------->", editTemplateDetails.buyerFullName);
        buyerFullName = editTemplateDetails.buyerFullName
    }
    else {
        buyerFullName = ""
    }

    if (text != null && editTemplateDetails.purchasePrice != undefined) {
        console.log("null--------------->", editTemplateDetails.purchasePrice);
        purchasePrice = editTemplateDetails.purchasePrice
    }
    else {
        purchasePrice = ""
    }

    if (text != null && editTemplateDetails.initialPrice != undefined) {
        console.log("null--------------->", editTemplateDetails.initialPrice);
        initialPrice = editTemplateDetails.initialPrice
    }
    else {
        initialPrice = ""
    }

    if (text != null && editTemplateDetails.balanceClose != undefined) {
        console.log("null--------------->", editTemplateDetails.balanceClose);
        balanceClose = editTemplateDetails.balanceClose;
    }
    else {
        balanceClose = ""
    }

    if (text != null && editTemplateDetails.propertyInspection != undefined) {
        console.log("null--------------->", editTemplateDetails.propertyInspection);
        propertyInspection = editTemplateDetails.propertyInspection
    }
    else {
        propertyInspection = ""
    }

    if (text != null && editTemplateDetails.taxID != undefined) {
        console.log("null--------------->", editTemplateDetails.taxID);
        taxID = editTemplateDetails.taxID
    }
    else {
        texID = ""
    }

    //checkbox1
    if (text != null && editTemplateDetails.purchaseMoney == 'YES' && editTemplateDetails.purchaseMoney != undefined) {
        console.log("null ---------->", editTemplateDetails.purchaseMoney);
        purmo = '☒'
    } else {
        purmo = '☐'
    }

    if (text != null && editTemplateDetails.assumption == 'YES' && editTemplateDetails.assumption != undefined) {
        console.log("null ---------->", editTemplateDetails.assumption);
        ylaf = '☒'
    } else {
        ylaf = '☐'
    }

    //checkbox2
    if (text != null && editTemplateDetails.sellerD == 'YES' && editTemplateDetails.sellerD != undefined) {
        console.log("null ---------->", editTemplateDetails.sellerD);
        slrd = '☒'
    } else {
        slrd = '☐'
    }

    if (text != null && editTemplateDetails.buyerD == 'YES' && editTemplateDetails.buyerD != undefined) {
        console.log("null ---------->", editTemplateDetails.buyerD);
        brds = '☒'
    } else {
        brds = '☐'
    }

    if (text != null && editTemplateDetails.miami == 'YES' && editTemplateDetails.miami != undefined) {
        console.log("null ---------->", editTemplateDetails.miami);
        mdia = '☒'
    } else {
        mdia = '☐'
    }

    //checkbox3
    if (text != null && editTemplateDetails.sellerPI == 'YES' && editTemplateDetails.sellerPI != undefined) {
        console.log("null ---------->", editTemplateDetails.sellerPI);
        slpi: '☒'
    } else {
        slpi = '☐'
    }

    if (text != null && editTemplateDetails.sellerPA == 'YES' && editTemplateDetails.sellerPA != undefined) {
        console.log("null ---------->", editTemplateDetails.sellerPA);
        srpa = '☒'
    } else {
        srpa = '☐'
    }

    if (text != null && editTemplateDetails.warranty == 'BUYER' && editTemplateDetails.warranty != undefined) {
        console.log("null ---------->", editTemplateDetails.warranty);
        bhw = '☒'
    } else {
        bhw = '☐'
    }

    if (text != null && editTemplateDetails.warranty == 'SELLER' && editTemplateDetails.warranty != undefined) {
        console.log("null ---------->", editTemplateDetails.warranty);
        hws = '☒'
    } else {
        hws = '☐'
    }

    if (text != null && editTemplateDetails.warranty == 'N/A' && editTemplateDetails.warranty != undefined) {
        console.log("null ---------->", editTemplateDetails.warranty);
        nulll = '☒'
    } else {
        nulll = '☐'
    }


    doc.setData({
        seller: sellerName,
        buyer: buyerName,
        addrs: address,
        location: location,
        legals: description,
        closingdt: closingDate,
        byrsint: buyersIni,
        bname: buyerFullName,
        currDate: new Date,
        Purchasepr: purchasePrice,
        initprice: initialPrice,
        Balancetoclo: balanceClose,
        propInspe: propertyInspection,
        vari: taxID,
        purmo: purmo,
        ylaf: ylaf,
        slrd: slrd,
        brds: brds,
        mdia: mdia,
        slpi: slpi,
        srpa: srpa,
        bhw: bhw,
        hws: hws,
        nulll: nulll
    });
   
    try {
        doc.render()
    }
    catch (error) {
        var e = {
            message: error.message,
            name: error.name,
            stack: error.stack,
            properties: error.properties,
        }
        console.log(JSON.stringify({ error: e }));
        throw error;
    }
    var buff;   

   
    var buf = doc.getZip()
        .generate({ type: 'nodebuffer' });
        // .generate({ type: 'application/pdf' });
    var filedetails = {
        property:editTemplateDetails.address,
        file_name:"File"+editTemplateDetails.userId,
        file:buf,
        userId:editTemplateDetails.userId
    }
       
    fs.writeFileSync(path.resolve(__dirname, 'outputt.docx'), buf);
    console.log("File--------------------->",buf)
    if (text != null) {

    }

    console.log("check it is buffer or not",Buffer.isBuffer(buf))

    console.log("File--------------------->", buf)
    
    FileService.createContract(filedetails, function (zipcodedata, err) {
        console.log("");
        if (err) {
            res.status(500).send(err);
        } else {
            res.status(201).send(zipcodedata);
        }
    })
}
//get file for pdf
module.exports.getPdfForUser = (req, res) => {
    var userId = req.params.userId;
    FileService.getPdfForUser(userId, function(getpdf, err){
        if(err) {
            res.status(500).send(err);
        } else {
             var file = getpdf.file;
            pdeff = encodeURIComponent(file) + '.pdf'
            res.status(200).send(pdeff);
        }
    })
}


//delete property
module.exports.delProperty = (req, res) => {
    var id = req.param('id');
    FileService.delProperty(id, function(data, err){
        if(err) {
            res.status(500).send(err);
        } else {
         res.status(200).send(data);
        }
    })
}


//find property by file
module.exports.findFile = (req, res) => {
    var filname = req.params.file_name;
    console.log("ffffffffffffffffff",filname)
    FileService.findFile(filname, function(data, err){
        if(err) {
            res.status(500).send(err);
        } else {
            console.log("daaaaaaaaaaaaaaaaaaaaaaaaa",data);
         res.status(200).send(data);
        }
    })
}

//find property by file
module.exports.findProperty = (req, res) => {
    var property = req.params.property;
    console.log("propertyyyyyyyyyyyyyyyyyyyyyy",property)
    FileService.findProperty(property, function(data, err){
        if(err) {
            res.status(500).send(err);
        } else {
            console.log("daaaaaaaaaaaaaaaaaaaaaaaaa",data);
         res.status(200).send(data);
        }
    })
}

