var express = require('express');
var apiRoutes = express.Router();

var personController = require('../controller/personController')

apiRoutes.post('/person',personController.postPerson)
// apiRoutes.get('/personAll',personController.getAllPerson)
// apiRoutes.put('/personById',personController.updatePerson)
// apiRoutes.delete('/personById',personController.deletePerson)

module.exports = apiRoutes;