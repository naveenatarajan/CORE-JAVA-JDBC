var FileDao = require('../dao/FileDao');

module.exports.createContract = (filedetails, callback)=>{
    
    FileDao.createContract(filedetails, function(err, data){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}
//get file for pdf
module.exports.getPdfForUser = (userId, callback) => {

    FileDao.getPdfForUser(userId, function(err, data){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}
//delete property
module.exports.delProperty = (_id, callback) => {

    FileDao.delProperty(_id, function(err, data){
        if(err){
            callback(err);
        }else{
            console.log("dattttttttttttttaservid",data)
            callback(data);
        }
    })
}

//find property by filename
module.exports.findFile = (_filname, callback) => {

    FileDao.findFile(_filname, function(err, data){
        if(err){
            callback(err);
        }else{
            console.log("dattttttttttttttaservid",data)
            callback(data);
        }
    })
}


//find property by filename
module.exports.findProperty = (_property, callback) => {

    FileDao.findProperty(_property, function(err, data){
        if(err){
            callback(err);
        }else{
            console.log("dattttttttttttttaservid",data)
            callback(data);
        }
    })
}