module.exports = {
    SERVICE_EMAIL: 'developer.aerobit@gmail.com',
    SERVICE_EMAIL_PASSWORD: 'developer@A',
    EMAIL_SERVICE_MIDDLEWARE: 'gmail',
    FORGOT_PASSWORD_SUBJECT: 'Aerobit Health- Reset your password',
    RESET_PASSWORD_SUBJECT: 'Your Aerobit Health Account password has been changed',
    EMAIL_FROM: 'support@aerobithealth.com'

};