var AssignZipcodeDao = require('../dao/AssignZipcodeDao');

module.exports.assignZipcodeToUser = (AssignZipcodeDetails, callback)=>{
    
    AssignZipcodeDao.assignZipcodeToUser(AssignZipcodeDetails, function(err, data){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}

module.exports.getAssignedUser = (UserId, callback) => {

    AssignZipcodeDao.getAssignedUser(UserId, function(err,assignedusers){
        if(err){
            callback(err);
        }
        else{
            callback(data);
        }
    })
}

module.exports.getCityForUser = (_id,state, callback) => {

    AssignZipcodeDao.getCityForUser(_id,state, function(err,usercities){
        if(err){
            callback(err);
        }
        else{
            callback(usercities);
        }
    })
}

module.exports.removeAssignedUser = (username,zipcode, callback) => {

    AssignZipcodeDao.removeAssignedUser(username,zipcode, function(err, data){
        if(err){
            callback(err);
        }
        else{
            callback(data);
        }
    })
}

module.exports.getPostalCodeForCity = (city,userId, callback) => {

    AssignZipcodeDao.getPostalCodeForCity(city,userId, function(err,postalcode){
        if(err){
            callback(err);
        }
        else{
            callback(postalcode);
        }
    })
}

module.exports.getPostalForAssignUser = (state,city,id, callback) => {

    AssignZipcodeDao.getPostalForAssignUser(state,city,id, function(err,postalcode){
        if(err){
            callback(err);
        }
        else{
            callback(postalcode);
        }
    })
}

//usercities count
module.exports.getUserCityCount = (city,callback) => {
   
    AssignZipcodeDao.getUserCityCount(city,function(err,cities){
        if(err){
            callback(err);
        }
        else{
            callback(cities);
        }
    })
}