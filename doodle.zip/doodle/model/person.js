var mongoose = require('mongoose')
const Schema = mongoose.Schema

var personSchema = new Schema({
    name: {type: String, required: true},
    age: {type : String, required: true},
    address : {
        street : {type: String, required: true},
        city : {type: String, required: true},
        pin: {type: String, required: true}
    }
})


var personDetails = mongoose.model('person', personSchema, 'person')
module.exports = personDetails