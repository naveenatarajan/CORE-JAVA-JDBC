var Express = require('express')
var mongoose = require('mongoose')
var BodyParser = require('body-parser')
var Logger = require('morgan')
var Path = require('path')

const app = new Express()

var router = require('./router/route')
var serverConfig = require('./config/config')


// MongoDB Connection
const options = {
    reconnectTries: Number.MAX_VALUE, // Never stop trying to reconnect
    reconnectInterval: 500, // Reconnect every 500ms
    poolSize: 10, // Maintain up to 10 socket connections
    bufferMaxEntries: 0
};

mongoose.connect(serverConfig.url, options);

app.all('*', function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if ('OPTIONS' == req.method) {
        res.sendStatus(200);
    } else {
        next();
    }
});
app.use(function (req, res, next) {
    res.header('Access-Control-Allow-Origin', req.headers.origin);
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    next();
});

app.use(function (err, req, res, next) {  // eslint-disable-line
    res.status(err.status || 500).json(res.error(err.status || 500));
});

process.on('uncaughtException', function (err) {
    console.log('An unknown error occured internally', err); // eslint-disable-line
});

setTimeout(function () {
}, 500);

//app.use(logger('dev'));

app.use('/api', router);

// start app
app.listen(serverConfig.port, (error) => {
    if (!error) {
        console.log(`Aeroibit Health Server is running on port: ${serverConfig.port}!`); // eslint-disable-line
    }
});

module.exports = app;
