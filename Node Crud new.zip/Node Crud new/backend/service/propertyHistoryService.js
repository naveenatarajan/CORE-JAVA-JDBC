'use strict';
var propertyHistoryDao = require('../dao/propertyHistoryDao');

module.exports.insert_property_history = (data, callback) => {
    propertyHistoryDao.insert_property_history(data, function (err, response) {
        if (err) {
            callback(err);
        } else {
            callback(response);
        }
    });
}

module.exports.get_history_by_key = (key, callback) => {
    propertyHistoryDao.get_history_by_key(key, function(err, response) {
        console.log("Service get by city:", response);
        if(err) {
            callback(err);
        } else {
            callback(null, response);
        }
    });
}
//get all propertyhistory
module.exports.all_propertyhistory = (callback) => {

    propertyHistoryDao.all_propertyhistory(function (err, history) {

        if (err) {
            callback(err);
        } else {
            callback(history);
        }
    })
}
// upadte property history
module.exports.update_propertyhistory = (_id, property, callback) => {

    propertyHistoryDao.update_propertyhistory(_id, property, function (err, data) {

        if (err) {
            callback(err);
        } else {
            callback(data);
        }
    })
}

//delete property history
module.exports.delete_propertyhistory=(_id,callback)=>{
    propertyHistoryDao.delete_propertyhistory(_id,function(err,data){
        if (err){
            callback(err);
        } else {

            callback(data);
        }
    })
    

}
//search property history
module.exports.search_propertyhistory=(_id,callback)=>{
    propertyHistoryDao.search_propertyhistory(_id,function(err,data){
        if (err){
            callback(err);
        } else {

            callback(data);
        }
    })
    

}