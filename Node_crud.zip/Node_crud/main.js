var express = require("express");
var models = require("./models");
var sequelize = models.sequelize;
var router   = require("./routes/route");
var bodyParser = require('body-parser');

var app = express();

app.use(bodyParser.json({ limit: '50mb' }))
app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, Accept, Content-Type, Content-Length, Authorization, X-Requested-With, X-XSRF-TOKEN");
  res.header("Access-Control-Allow-Methods", "PUT, POST, GET, DELETE, OPTIONS");
  if (req.method === 'OPTIONS') {
    console.log('OPTIONS SUCCESS');
    res.end();
  }
  next();
});


app.use("/", router);
app.all('*', function (req, res) {
});


models.sequelize.sync().then(function () {
    var server = app.listen(3000, function () {
    console.log('Express server listening on port ' + server.address().port);
  });
});
