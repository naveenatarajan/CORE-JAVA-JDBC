'use strict';

module.exports = function(sequelize, DataTypes) {
  var Tables = sequelize.define("TimeCard.ChangeLog", {
    id: {
    	type : DataTypes.INTEGER,
    	primaryKey : true,
    	autoIncrement : true
    },
    Revision: {
    	type : DataTypes.INTEGER,
    	primaryKey : true,
    },
    // In:DataTypes.TIMESTAMP,
    // Out:DataTypes.TIMESTAMP,
    EmployeeId:DataTypes.INTEGER,
    TimeCardStatusId: DataTypes.INTEGER,
    Deleted: DataTypes.INTEGER,
    // Updated:DataTypes.TIMESTAMP,
    UpdatedFromIp: DataTypes.STRING,
    UpdatedBy: DataTypes.STRING,
    Action:DataTypes.STRING,
    TimeCardId:DataTypes.INTEGER,
  },{
    createdAt: false,
    updatedAt: false,
    freezeTableName:true
  });
  return Tables;
};