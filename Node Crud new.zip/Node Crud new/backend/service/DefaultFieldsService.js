
var DefaultFieldsDao = require('../dao/DefaultFieldsDao');

//create default field in DefaultFields table
module.exports.createField = (fileds, callback) => {
    DefaultFieldsDao.createField(fileds, function(err, data){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}

//get AllFields
module.exports.getAllFields = (callback) => {
    DefaultFieldsDao.getAllFields(function(err,data){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}