var RegistrationService = require('../service/RegistrationService');

module.exports.signUp = (req, res) =>{
    var userData = req.body;
    console.log("testewgds")
    RegistrationService.signUp(userData, function(data, err){
        if(err){
            res.status(500).send(err);
        }else{
            res.status(200).send(data);
        }
    })
}

module.exports.updateUser = (req, res) =>{
     var email = req.param('email');
    RegistrationService.updateUser(email, function(data, err){
        if(err){
            res.status(500).send(err);
        }else{
            res.status(200).send({message:'Email Confirmation successfully'});
        }
    })
}


module.exports.deleteUser = (req, res) =>{
    var email = req.param('email');
   RegistrationService.deleteUser(email, function(data, err){
       if(err){
           res.status(500).send(err);
       }else{
           res.status(200).send({message:'User Deleted Successfully'});
       }
   })
}

//get all users from reuser table
module.exports.getUsers = (req,res) => {

    RegistrationService.getUsers(function(data, err){
        if(err){
            res.status(500).send(err);
        }else{
            res.status(200).send(data);
        }
    })
}

//set percentage in reuser table
module.exports.setUserPercentage = (req,res) => {
    var percentage = req.params.percentage;
    var _id = req.params._id;

    RegistrationService.setUserPercentage(percentage,_id, function(data, err){
        if(err){
            res.status(500).send(err);
        }else{
            res.status(200).send(data);
        }
    })
}

//get user_by_id from reuser table
module.exports.getUserId = (req,res) => {
    var UserId = req.params.UserId;

    RegistrationService.getUserId(UserId,function(data, err){
        if(err){
            res.status(500).send(err);
        }else{
            res.status(200).send(data);
        }
    })
}

