'use strict';

module.exports = function (sequelize, DataTypes) {
  var Tables = sequelize.define("AdjustedEntry", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    TimeCardId: DataTypes.INTEGER,
    EntryId: DataTypes.INTEGER,
    EntryCode: DataTypes.STRING,
    EmployeeNumber: DataTypes.STRING,
    WorkOrderNumber: DataTypes.STRING,
    PartNumber: DataTypes.STRING,
    OrganizationalUnitId: DataTypes.INTEGER,
    Duration: DataTypes.DOUBLE,
    Weight: DataTypes.DOUBLE
  }, {
      createdAt: false,
      updatedAt: false,
      freezeTableName: true
    });
  return Tables;
};