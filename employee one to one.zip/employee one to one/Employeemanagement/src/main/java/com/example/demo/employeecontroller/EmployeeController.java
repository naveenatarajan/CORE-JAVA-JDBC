package com.example.demo.employeecontroller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.employeerecord.EmployeeRecord;
import com.example.demo.employeeservice.EmployeeService;

@RestController
public class EmployeeController {
	@Autowired  
    private EmployeeService empService; 
	
	@RequestMapping(value= "/string_return",method = RequestMethod.GET)
    public String  string_return(){  
        return "hello babe";  
    } 
	
   @RequestMapping(value= "/Employee",method = RequestMethod.GET)  
    public List<EmployeeRecord> getAllEmployees(){  
        return empService.getAllEmployees();  
    }     
    
   @RequestMapping(value="/addEmployee", method=RequestMethod.POST)  
    public void addEmployee(@RequestBody EmployeeRecord id){  
        empService.addEmployee(id);  
    }  
    @RequestMapping(value="/Employee/{id}", method=RequestMethod.GET)  
    public Optional<EmployeeRecord> getEmployee(@PathVariable long id){  
        return empService.getEmployeeRecordById(id);  
    } 
   
 }
  

