var express = require('express');
var apiRouter = express.Router();
var DefaultFieldsController = require('../../controller/DefaultFieldsController');

apiRouter.post('/create_Field',DefaultFieldsController.createField);
apiRouter.get('/getall',DefaultFieldsController.getAllFields);


module.exports = apiRouter;
