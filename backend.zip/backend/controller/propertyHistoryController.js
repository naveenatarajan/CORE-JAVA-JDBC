var propertyHistoryService = require('../service/propertyHistoryService');

module.exports.insert_property_history = (req, res) => {
    var history = req.body;
    propertyHistoryService.insert_property_history(history, function (err, response) {
        if (err) {
            res.status(500).send(err);
        } else {
            res.status(201).send(response);
        }
    });
}

module.exports.get_history_by_key = (req, res) => {
    var key = req.query.key;
    propertyHistoryService.get_history_by_key(key, function (err, response) {
        res.status(201).send(response);
        if(err) {
            res.status(500).send(err);
        } else {
            res.status(201).send(response);
        }
    });
}
// get all propertyhistory
module.exports.all_propertyhistory = (req, res) => {

    propertyHistoryService.all_propertyhistory(function (history, err) {

        if (err) {
            res.status(500).send(err);
        } else {
            res.status(200).send(history);
        }
    })

}
//update propertyhistory
module.exports.update_propertyhistory = (req, res) => {
    var property = req.body;
    var id = req.param('id');
    propertyHistoryService.update_propertyhistory(id, property, function (err, data) {
        if (err) {
            res.status(500).send(err);
        } else {
            res.status(200).send(data);
        }
    })
}

//delete property history
module.exports.delete_propertyhistory = (req, res)=>{
    var id = req.param('id');
    propertyHistoryService.delete_propertyhistory(id, function (err,data){
        if(err){
            res.status(500).send(err);
        } else{
            res.status(200).send(data)
        }
    })
}
//search property history
module.exports.search_propertyhistory = (req, res)=>{
    var id = req.param('id');
    propertyHistoryService.search_propertyhistory(id, function (err,data){
        if(err){
            res.status(500).send(err);
        } else{
            res.status(200).send(data)
        }
    })
}













