module.exports = {
    accessKeyId: 'AKIAIAC6V6ZAQRX6VJGA',
    secretAccessKey: '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',
    region: 'us-east-1',
    bucketName: 'aerobit'
};