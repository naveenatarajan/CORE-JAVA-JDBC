var TaskcommentDao = require('../dao/TaskcommentDao');

module.exports.createcomment = (taskcomment, callback) => {
    TaskcommentDao.createcomment(taskcomment, function(err,taskcomment){
        if(err){
            callback(err);
        }else {
            callback(taskcomment);
        }

    });
}

module.exports.getalltask = (callback) => {

    TaskcommentDao.getalltask(function(err,getalltask){

        if(err){
            callback(err);
        }else{
            callback(getalltask);
        }
    });
} 