var Person = require('../model/person')



module.exports.postPerson = (personData,callback) =>{
     var person = new Person(personData);
     person.save(function(err, result){
         if(err){
             callback(err)
         }else{
             callback(result)
         }
     })
}