var express = require('express');
var apiRouter = express.Router();
var FileController = require('../../controller/MailController');

apiRouter.post('/mail',MailController.nodeMail);

module.exports = apiRouter;
