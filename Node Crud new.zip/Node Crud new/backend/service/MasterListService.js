var MasterlistDao = require('../dao/MasterListDao');

module.exports.addlist = (masterlistdata, callback) => {

    MasterlistDao.addmasterlist(masterlistdata, function (err, masterlistdata) {
        if (err) {
            callback(err);
        } else {
            callback(masterlistdata);
        }
    })
}

module.exports.getalllist = (callback) => {

    MasterlistDao.getalllist(function (err, masterlist) {

        if (err) {
            callback(err);
        } else {
            callback(masterlist);
        }
    })
}

module.exports.updatealllist = (id, listdetails, callback) => {
    
    MasterlistDao.updatemasterlist(id, listdetails, function (err, listdetails) {
        if (err) {
            callback(err);
        } else {
            callback(listdetails);
        }
    })
}

module.exports.deletealllist = (_id, callback) => {

    MasterlistDao.deletealllist(_id, function (data, err) {
        console.log("-------------------------------??????????",_id)
        if (err) {
            callback(err);
        } else {
            callback(data);
        }
    })
}