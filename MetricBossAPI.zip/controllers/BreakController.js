var service = require("../services/BreakService")


module.exports.create_Tables = function(req, res) {
  var Tables = req.body;
  service.create_Tables(Tables,function (tables){
    res.status(201);
    res.json(tables);
  });
}

module.exports.createBreakEntries = function(req, res) {
  var Tables = req.body;
  service.createBreakEntries(Tables,function (tables){
    res.status(201);
    res.json(tables);
  });
}

module.exports.checkBreakEntries = function(req, res) {
  var Tables_id = req.body.EmployeeId;
  service.checkBreakEntries(Tables_id,function (tables){
    res.json(tables);
  });
}

module.exports.update_Tables = function(req, res) {
  var Tables = req.body;
  service.update_Tables(Tables,function (tables){
    res.status(201);
    res.json(tables);
  });
}
module.exports.search_Tables_for_update = function(req, res) {
  var Tables_id = req.params.id;
  service.search_Tables_for_update(Tables_id,function (tables){
    res.json(tables);
  });
}
module.exports.delete_Tables = function(req, res) {
  var Tables_id = req.params.id;
  service.delete_Tables(Tables_id,function (){
    res.status(204);
    res.end();
  });
}
module.exports.get_all_Tables = function(req, res) {
  var tables_id = req.query.id;

  service.get_all_Tables(function (tables){
    res.json(tables);
  });
}