'use strict';
var propertyDao = require('../dao/propertyDao');

module.exports.insert_property = (data, callback) => {
    propertyDao.insert_property(data, function (err, response) {
        if (err) {
            callback(err);
        } else {
            callback(response);
        }
    });
}

module.exports.listofproperty = (callback) => {

    propertyDao.propertylist(function (err, propertylist) {

        if (err) {
            callback(err);
        } else {
            callback(propertylist);
        }
    });
}

module.exports.updateproperty = (id,  property_key, address, postal_code, list_price, sq_ft_header, sub_division_name,water_frontage, year, county, user_action, historical_high_sold_price_per_sq_ft, notes, legalDescription, taxId, updated_by , callback) => {

    propertyDao.updateproperty(id,  property_key, address, postal_code, list_price, sq_ft_header, sub_division_name,water_frontage, year, county, user_action, historical_high_sold_price_per_sq_ft, notes, legalDescription, taxId, updated_by , function (err, data) {

        if (err) {
            callback(err);
        } else {
            callback(data);
        }
    });

}

module.exports.deleteproperties = (id,callback) => {

    propertyDao.deleteproperty (id, function (err,data){

        if (err){
            callback(err);
        }else{
            callback(data);
        }
    });
}

module.exports.get_by_city_zip = (city, zip, callback) => {
    propertyDao.get_by_city_zip(city, zip, function (err, response) {
        console.log("Service get by city:", response);
        if (err) {
            callback(err);
        } else {
            callback(null, response);
        }
    });
}

//search property 
module.exports.searchproperty=(_id,callback)=>{
    propertyDao.searchproperty(_id,function(err,data){
        if (err){
            callback(err);
        } else {

            callback(data);
        }
    })
    

}
//get postal code by city
module.exports.getpostalbycity = (city, callback) => {

    propertyDao.getpostalbycity(city, function(err,postal_code){
        if(err){
            callback(err);
        }
        else{
            callback(postal_code);
        }
    })
}


//find property by view
module.exports.getByAddress = (_address, callback) => {

    propertyDao.getByAddress(_address, function(err, data){
        if(err){
            callback(err);
        }else{
            console.log("dattttttttttttttaservid",data)
            callback(data);
        }
    })
}