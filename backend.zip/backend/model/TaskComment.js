var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var uniqueValidator = require('mongoose-unique-validator');
var autoIncrement = require('mongoose-auto-increment');

var TaskCommentSchema = new Schema({
    comment: { type: String },
    commentdate: { type: String },
    taskid: { type: Number },
    userid: { type: Number },
},{
        versionKey: false,
    });

autoIncrement.initialize(mongoose);
TaskCommentSchema.plugin(uniqueValidator);
TaskCommentSchema.plugin(autoIncrement.plugin, { model: 'taskcomment', startAt: 1 });
var taskcomment = mongoose.model('taskcomment', TaskCommentSchema, 'taskcomment');

module.exports = taskcomment;
