'use strict';

module.exports = function(sequelize, DataTypes) {
  var Tables = sequelize.define("OrganizationalUnit", {
    id: {
    	type : DataTypes.INTEGER,
    	primaryKey : true,
    	autoIncrement : true
    },
    name: DataTypes.STRING,
    parentId:DataTypes.INTEGER,
    active: DataTypes.INTEGER,
    order: DataTypes.INTEGER, 
    OrganizationalUnit_Id: DataTypes.INTEGER,
  },{
    createdAt: false,
    updatedAt: false,
    freezeTableName:true
  });
  return Tables;
};