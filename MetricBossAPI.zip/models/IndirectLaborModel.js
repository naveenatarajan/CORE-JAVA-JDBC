'use strict';

module.exports = function(sequelize, DataTypes) {
  var Tables = sequelize.define("IndirectLabor", {
    id: {
    	type : DataTypes.INTEGER,
    	primaryKey : true,
    	autoIncrement : true
    },
    Code: DataTypes.STRING,
    Description:DataTypes.STRING,
    AllowConcurrency: DataTypes.INTEGER,
    Active: DataTypes.INTEGER,
    Order:DataTypes.INTEGER,
    TimeCardEntry_Id:DataTypes.INTEGER
  },{
    createdAt: false,
    updatedAt: false,
    freezeTableName:true
  });
  return Tables;
};