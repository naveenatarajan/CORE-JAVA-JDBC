var TaskcommentService = require ('../service/TaskcommentService');

module.exports.createcomment = (req,res) => {
    var comment = req.body;

    TaskcommentService.createcomment(comment, function(comment,err) {
        if(err){
            res.status(500).send(err);
        }else{
            res.status(201).send(comment);
        }
    });

}

module.exports.gettaskcomment = (req,res) => {

    TaskcommentService.getalltask(function(taskcomment,err){

        if(err){
            res.status(500).send(err);
        }else{
            res.status(200).send(taskcomment);
        }
    });
}