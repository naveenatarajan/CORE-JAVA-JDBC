var service = require("../services/TimeCardService")

module.exports.create_Tables = function(req, res) {
  var Tables = req.body;
  service.create_Tables(Tables,function (tables){
    res.status(201);
    res.json(tables);
  });
}

module.exports.UpdateOutTime = function(req, res) {
  var Tables = req.body;
  service.UpdateOutTime(Tables,function (tables){
    res.status(201);
    res.json(tables);
  });
}

module.exports.update_Tables = function(req, res) {
  var Tables = req.body;
  service.update_Tables(Tables,function (tables){
    res.status(201);
    res.json(tables);

  });
}
module.exports.search_Tables_for_update = function(req, res) {
  var Tables_id = req.params.id;
  console.log("emplyeee id==>",Tables_id)
  service.search_Tables_for_update(Tables_id,function (tables){
    res.json(tables);
  });
}

module.exports.search_by_params = function(req, res) { 
  // var Tables_id = req.params.id;
  // console.log("req==>",req)
  console.log("Params",req.param('Out'))
  service.search_by_params(req,function (tables){
    res.json(tables);
  });
}

module.exports.delete_Tables = function(req, res) {
  var Tables_id = req.params.id;
  service.delete_Tables(Tables_id,function (){
    res.status(204);
    res.end();
  });
}
module.exports.get_all_Tables = function(req, res) {
  var tables_id = req.query.id;

  service.get_all_Tables(function (tables){
    res.json(tables);
  });
}