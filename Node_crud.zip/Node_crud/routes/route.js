var express = require("express");
var api = express.Router();
var routers = require("./routers")
api.use("/student", routers.employee);

module.exports = api;