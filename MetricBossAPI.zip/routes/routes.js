var express = require("express");
var api = express.Router();
var routers = require("./routers")
api.use("/WorkOrderStatus", routers.Tables_Default_ActivityRouter);
api.use("/EmployeeType", routers.EmployeeTypeControllerRouter);
api.use("/TimeCardStatus", routers.TimeCardStatusRouter);
api.use("/workOrder",routers.WorkOrderRouter)
api.use("/OrganizationalUnit", routers.OrganizationalUnitRouter);
api.use("/Employee", routers.EmployeeRouter);
api.use("/TimeCard", routers.TimeCardRouter);
api.use("/Entry",routers.EntryRouter);
api.use("/EntryStatus",routers.EntryStatusRouter);
api.use("/EntryType",routers.EntryTypeRouter);
api.use("/AdjustedEntry",routers.AdjustedEntryRouter);
api.use("/Operation",routers.Operation);
api.use("/EntryChangeLog",routers.EntryChangeLog);
api.use("/Break",routers.BreakRouter);
api.use("/IndirectLabor",routers.IndirectLaborRouter);
api.use("/timecardChangelog",routers.timecardChangelogRouter)

module.exports = api;