var express = require("express");
var router = express.Router();
var controller = require("../../controllers/BreakController")
router.post("", controller.create_Tables);
router.post("/createBreakEntries", controller.createBreakEntries);
router.post("/checkBreakEntries", controller.checkBreakEntries);
router.get("/:id", controller.search_Tables_for_update);
router.put("", controller.update_Tables);
router.delete("/:id", controller.delete_Tables);
router.get("", controller.get_all_Tables);

module.exports = router;