-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema TimeTracker

-- -----------------------------------------------------
-- Schema TimeTracker
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `TimeTracker` DEFAULT CHARACTER SET utf8 ;
USE `TimeTracker` ;

-- -----------------------------------------------------
-- Table `TimeTracker`.`EmployeeType`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TimeTracker`.`EmployeeType` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `Name` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `Active` TINYINT(4) NOT NULL DEFAULT '1' COMMENT '',
  `Order` INT(11) NOT NULL DEFAULT '0' COMMENT '',
  PRIMARY KEY (`Id`)  COMMENT '')
ENGINE = InnoDB
AUTO_INCREMENT = 4
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `TimeTracker`.`OrganizationalUnit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TimeTracker`.`OrganizationalUnit` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `ParentId` INT NULL COMMENT '',
  `Name` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `Active` TINYINT(4) NOT NULL DEFAULT '1' COMMENT '',
  `Order` INT(11) NOT NULL DEFAULT '0' COMMENT '',
  `OrganizationalUnitId` INT(11) NOT NULL COMMENT '',
  PRIMARY KEY (`Id`)  COMMENT '',
  INDEX `fk_OrganizationalUnit_OrganizationalUnit1_idx` (`OrganizationalUnitId` ASC)  COMMENT '',
  CONSTRAINT `fk_OrganizationalUnit_OrganizationalUnit1`
    FOREIGN KEY (`OrganizationalUnitId`)
    REFERENCES `TimeTracker`.`OrganizationalUnit` (`Id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `TimeTracker`.`Employee`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TimeTracker`.`Employee` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `FirstName` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `MiddleName` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `LastName` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `EmployeeTypeId` INT(11) NULL DEFAULT NULL COMMENT '',
  `EmployeeNumber` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `OrganizationalUnitId` INT(11) NULL COMMENT '',
  `Active` TINYINT(4) NOT NULL DEFAULT '1' COMMENT '',
  `Order` INT(11) NOT NULL DEFAULT '0' COMMENT '',
  `ManagerId` INT(11) NULL DEFAULT NULL COMMENT '',
  PRIMARY KEY (`Id`)  COMMENT '',
  INDEX `fk_Employee_EmployeeType1_idx` (`EmployeeTypeId` ASC)  COMMENT '',
  INDEX `fk_Employee_OrganizationalUnit1_idx` (`OrganizationalUnitId` ASC)  COMMENT '',
  CONSTRAINT `fk_Employee_EmployeeType1`
    FOREIGN KEY (`EmployeeTypeId`)
    REFERENCES `TimeTracker`.`EmployeeType` (`Id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Employee_OrganizationalUnit1`
    FOREIGN KEY (`OrganizationalUnitId`)
    REFERENCES `TimeTracker`.`OrganizationalUnit` (`Id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 4
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `TimeTracker`.`TimeCardStatus`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TimeTracker`.`TimeCardStatus` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `Name` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `Active` TINYINT(4) NOT NULL DEFAULT '1' COMMENT '',
  `Order` INT(11) NOT NULL DEFAULT '0' COMMENT '',
  PRIMARY KEY (`Id`)  COMMENT '')
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `TimeTracker`.`TimeCard`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TimeTracker`.`TimeCard` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `In` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '',
  `Out` TIMESTAMP NULL DEFAULT NULL COMMENT '',
  `Deleted` TINYINT(4) NULL DEFAULT '0' COMMENT '',
  `Updated` TIMESTAMP NULL DEFAULT NULL COMMENT '',
  `UpdatedFromIp` VARCHAR(15) NULL DEFAULT NULL COMMENT '',
  `UpdatedBy` VARCHAR(80) NULL DEFAULT NULL COMMENT '',
  `EmployeeId` INT(11) NOT NULL COMMENT '',
  `TimeCardStatusId` INT(11) NOT NULL COMMENT '',
  PRIMARY KEY (`Id`)  COMMENT '',
  INDEX `fk_TimeCard_Employee1_idx` (`EmployeeId` ASC)  COMMENT '',
  INDEX `fk_TimeCard_TimeCardStatus1_idx` (`TimeCardStatusId` ASC)  COMMENT '',
  CONSTRAINT `fk_TimeCard_Employee1`
    FOREIGN KEY (`EmployeeId`)
    REFERENCES `TimeTracker`.`Employee` (`Id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_TimeCard_TimeCardStatus1`
    FOREIGN KEY (`TimeCardStatusId`)
    REFERENCES `TimeTracker`.`TimeCardStatus` (`Id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `TimeTracker`.`Entry`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TimeTracker`.`Entry` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `EntryTypeId` INT NOT NULL COMMENT '',
  `In` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '',
  `Out` TIMESTAMP NULL DEFAULT NULL COMMENT '',
  `PaidTime` TINYINT(4) NOT NULL DEFAULT '0' COMMENT '',
  `BillableTime` TINYINT(4) NOT NULL DEFAULT '0' COMMENT '',
  `RefId` INT NULL DEFAULT NULL COMMENT '',
  `Completed` DOUBLE(16,4) NULL DEFAULT NULL COMMENT '',
  `Notes` VARCHAR(8192) NULL DEFAULT NULL COMMENT '',
  `EntryStatusId` INT(11) NULL COMMENT '',
  `Deleted` TINYINT(4) NOT NULL DEFAULT '0' COMMENT '',
  `Updated` TIMESTAMP NULL DEFAULT NULL COMMENT '',
  `UpdatedBy` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `UpdatedFromIp` VARCHAR(15) NULL DEFAULT NULL COMMENT '',
  `TimeCardId` INT(11) NOT NULL COMMENT '',
  PRIMARY KEY (`Id`)  COMMENT '',
  INDEX `fk_TimeCardEntry_TimeCard1_idx` (`TimeCardId` ASC)  COMMENT '',
  CONSTRAINT `fk_TimeCardEntry_TimeCard1`
    FOREIGN KEY (`TimeCardId`)
    REFERENCES `TimeTracker`.`TimeCard` (`Id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `TimeTracker`.`Break`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TimeTracker`.`Break` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `Code` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `Description` VARCHAR(100) NULL DEFAULT NULL COMMENT '',
  `PaidTime` TINYINT(4) NOT NULL DEFAULT '1' COMMENT '',
  `Active` TINYINT(4) NOT NULL DEFAULT '1' COMMENT '',
  `Order` INT(11) NOT NULL DEFAULT '0' COMMENT '',
  `TimeCardEntryId` INT(11) NOT NULL COMMENT '',
  PRIMARY KEY (`Id`)  COMMENT '',
  INDEX `fk_Break_TimeCardEntry_idx` (`TimeCardEntryId` ASC)  COMMENT '',
  CONSTRAINT `fk_Break_TimeCardEntry`
    FOREIGN KEY (`TimeCardEntryId`)
    REFERENCES `TimeTracker`.`Entry` (`Id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 4
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `TimeTracker`.`IndirectLabor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TimeTracker`.`IndirectLabor` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `Code` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `Description` VARCHAR(100) NULL DEFAULT NULL COMMENT '',
  `AllowConcurrency` TINYINT NOT NULL DEFAULT 0 COMMENT '',
  `Active` TINYINT(4) NOT NULL DEFAULT '1' COMMENT '',
  `Order` INT(11) NOT NULL DEFAULT '0' COMMENT '',
  `TimeCardEntryId` INT(11) NOT NULL COMMENT '',
  PRIMARY KEY (`Id`)  COMMENT '',
  INDEX `fk_IndirectLabor_TimeCardEntry1_idx` (`TimeCardEntryId` ASC)  COMMENT '',
  CONSTRAINT `fk_IndirectLabor_TimeCardEntry1`
    FOREIGN KEY (`TimeCardEntryId`)
    REFERENCES `TimeTracker`.`Entry` (`Id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `TimeTracker`.`EntryStatus`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TimeTracker`.`EntryStatus` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `Name` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `Active` TINYINT(4) NOT NULL DEFAULT '1' COMMENT '',
  `Order` INT(11) NOT NULL DEFAULT '0' COMMENT '',
  `TimeCardEntryId` INT(11) NOT NULL COMMENT '',
  PRIMARY KEY (`Id`)  COMMENT '',
  INDEX `fk_Status_TimeCardEntry1_idx` (`TimeCardEntryId` ASC)  COMMENT '',
  CONSTRAINT `fk_Status_TimeCardEntry1`
    FOREIGN KEY (`TimeCardEntryId`)
    REFERENCES `TimeTracker`.`Entry` (`Id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `TimeTracker`.`TimeCard.ChangeLog`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TimeTracker`.`TimeCard.ChangeLog` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `Revision` INT(11) NOT NULL COMMENT '',
  `In` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '',
  `Out` TIMESTAMP NULL DEFAULT NULL COMMENT '',
  `EmployeeId` INT(11) NOT NULL COMMENT '',
  `TimeCardStatusId` INT(11) NULL DEFAULT NULL COMMENT '',
  `Deleted` TINYINT NULL COMMENT '',
  `Updated` TIMESTAMP NULL DEFAULT NULL COMMENT '',
  `UpdatedFromIp` VARCHAR(15) NULL DEFAULT NULL COMMENT '',
  `UpdatedBy` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `Action` VARCHAR(45) NULL COMMENT '',
  `TimeCardId` INT(11) NOT NULL COMMENT '',
  PRIMARY KEY (`Id`,`Revision`)  COMMENT '')
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `TimeTracker`.`Entry.ChangeLog`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TimeTracker`.`Entry.ChangeLog` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `Revision` INT(11) NOT NULL COMMENT '',
  `TimeCardId` INT(11) NULL DEFAULT NULL COMMENT '',
  `EntryTypeId` INT NULL COMMENT '',
  `In` TIMESTAMP NULL DEFAULT NULL COMMENT '',
  `Out` TIMESTAMP NULL DEFAULT NULL COMMENT '',
  `PaidTime` TINYINT(4) NULL DEFAULT NULL COMMENT '',
  `BillableTime` TINYINT(4) NULL DEFAULT NULL COMMENT '',
  `RefId` INT NULL DEFAULT NULL COMMENT '',
  `Completed` DOUBLE(16,4) NULL DEFAULT NULL COMMENT '',
  `Notes` VARCHAR(8192) NULL DEFAULT NULL COMMENT '',
  `EntryStatusId` INT(11) NULL DEFAULT NULL COMMENT '',
  `Deleted` TINYINT(4) NULL DEFAULT NULL COMMENT '',
  `Updated` TIMESTAMP NULL DEFAULT NULL COMMENT '',
  `UpdatedBy` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `UpdatedFromIp` VARCHAR(15) NULL DEFAULT NULL COMMENT '',
  `Action` VARCHAR(45) NULL COMMENT '',
  `EntryId` INT(11) NOT NULL COMMENT '',
  PRIMARY KEY (`Id`,`Revision`)  COMMENT '')
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `TimeTracker`.`WorkOrderStatus`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TimeTracker`.`WorkOrderStatus` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `Name` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `Active` TINYINT(4) NOT NULL DEFAULT '1' COMMENT '',
  `Order` INT(11) NOT NULL DEFAULT '0' COMMENT '',
  PRIMARY KEY (`Id`)  COMMENT '')
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `TimeTracker`.`WorkOrder`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TimeTracker`.`WorkOrder` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `WorkOrderNumber` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `SalesOrderNumber` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `SalesOrderLine` INT(11) NULL DEFAULT NULL COMMENT '',
  `CustomerName` VARCHAR(100) NULL DEFAULT NULL COMMENT '',
  `CustomerNumber` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `DueDate` DATE NULL DEFAULT NULL COMMENT '',
  `PartNumber` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `PartDescription` VARCHAR(4192) NULL DEFAULT NULL COMMENT '',
  `Quantity` DOUBLE(16,4) NULL DEFAULT NULL COMMENT '',
  `Completed` DOUBLE(16,4) NULL DEFAULT NULL COMMENT '',
  `Updated` TIMESTAMP NULL DEFAULT NULL COMMENT '',
  `WorkOrderStatusId` INT(11) NOT NULL COMMENT '',
  PRIMARY KEY (`Id`)  COMMENT '',
  UNIQUE INDEX `WorkOrderNum_UNIQUE` (`WorkOrderNumber` ASC)  COMMENT '',
  INDEX `fk_WorkOrder_WorkOrderStatus1_idx` (`WorkOrderStatusId` ASC)  COMMENT '',
  CONSTRAINT `fk_WorkOrder_WorkOrderStatus1`
    FOREIGN KEY (`WorkOrderStatusId`)
    REFERENCES `TimeTracker`.`WorkOrderStatus` (`Id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 18
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `TimeTracker`.`Operation`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TimeTracker`.`Operation` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `Code` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `Description` VARCHAR(255) NULL DEFAULT NULL COMMENT '',
  `AllowConcurrency` TINYINT NOT NULL DEFAULT 1 COMMENT '',
  `Instructions` VARCHAR(16384) NULL DEFAULT NULL COMMENT '',
  `PlannedQuantity` DOUBLE(16,4) NULL DEFAULT NULL COMMENT '',
  `ExpectedTime` DOUBLE(16,4) NULL DEFAULT NULL COMMENT '',
  `TimeCardEntryId` INT(11) NOT NULL COMMENT '',
  `WorkOrderId` INT(11) NOT NULL COMMENT '',
  PRIMARY KEY (`Id`)  COMMENT '',
  INDEX `fk_Operation_TimeCardEntry1_idx` (`TimeCardEntryId` ASC)  COMMENT '',
  INDEX `fk_Operation_WorkOrder1_idx` (`WorkOrderId` ASC)  COMMENT '',
  CONSTRAINT `fk_Operation_TimeCardEntry1`
    FOREIGN KEY (`TimeCardEntryId`)
    REFERENCES `TimeTracker`.`Entry` (`Id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Operation_WorkOrder1`
    FOREIGN KEY (`WorkOrderId`)
    REFERENCES `TimeTracker`.`WorkOrder` (`Id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 32
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `TimeTracker`.`AdjustedEntry`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TimeTracker`.`AdjustedEntry` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `TimeCardId` INT NULL COMMENT '',
  `EntryId` INT NOT NULL DEFAULT '1' COMMENT '',
  `EntryCode` VARCHAR(45) NULL COMMENT '',
  `EmployeeNumber` VARCHAR(45) NULL COMMENT '',
  `WorkOrderNumber` VARCHAR(45) NULL COMMENT '',
  `PartNumber` VARCHAR(45) NULL COMMENT '',
  `OrganizationalUnitId` INT NULL COMMENT '',
  `In` TIMESTAMP NOT NULL COMMENT '',
  `Out` TIMESTAMP NULL COMMENT '',
  `Duration` DOUBLE(6,4) NULL COMMENT '',
  `Weight` DOUBLE(5,4) NULL COMMENT '',
  PRIMARY KEY (`Id`)  COMMENT '')
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `TimeTracker`.`EntryType`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TimeTracker`.`EntryType` (
  `Id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '',
  `Name` VARCHAR(45) NULL DEFAULT NULL COMMENT '',
  `Active` TINYINT(4) NOT NULL DEFAULT '1' COMMENT '',
  `Order` INT(11) NOT NULL DEFAULT '0' COMMENT '',
  `TimeCardEntryId` INT(11) NOT NULL COMMENT '',
  PRIMARY KEY (`Id`)  COMMENT '',
  INDEX `fk_TimeCardEntryType_TimeCardEntry1_idx` (`TimeCardEntryId` ASC)  COMMENT '',
  CONSTRAINT `fk_TimeCardEntryType_TimeCardEntry1`
    FOREIGN KEY (`TimeCardEntryId`)
    REFERENCES `TimeTracker`.`Entry` (`Id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 4
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
