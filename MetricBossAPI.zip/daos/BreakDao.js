var models = require("../models");
var sequelize = models.sequelize;
var PropertiesReader = require('properties-reader');
var sqlQuery = PropertiesReader(__dirname + '/../sql_queries/Break_SQL.properties');
var sqlQueryEntry = PropertiesReader(__dirname + '/../sql_queries/Entry_SQL.properties');
var moment = require("moment")

module.exports.create_Tables = function (Tables, callback) {
  var create_query = sqlQuery._properties.create_Tables;
  sequelize.query(create_query, {
    replacements: {
      Code: Tables.Code,
      Description: Tables.Description,
      PaidTime: Tables.PaidTime,
      Active: Tables.Active,
      Order: Tables.Order,
      TimeCardEntryId: Tables.TimeCardEntryId,
    },
    type: sequelize.QueryTypes.INSERT,
    model: models.Tables
  }).then(function (tables) {
    callback(tables);
  });
}

module.exports.createBreakEntries = function (Tables, callback) {
  console.log("======Tables", Tables)

  //saving the entry with base info
  var create_query = sqlQueryEntry._properties.create_Tables_for_entries;
  sequelize.query(create_query, {
    replacements: {
      TimeCardId: Tables.TimeCardId,
      EntryTypeId: 0,
      PaidTime: Tables.PaidTime,
      BillableTime: Tables.BillableTime,
      Completed: Tables.Completed,
      Notes: Tables.Notes,
      EntryStatusId: 0,
      Completed: Tables.Completed,
      Deleted: Tables.Deleted,
      UpdatedBy: "MetriCBoss",
      UpdatedFromIp: "MetriCBoss",
    },
    type: sequelize.QueryTypes.INSERT,
    model: models.Tables
  }).then(function (entrydata) {
    //saving the break info with retirning of refId
    var create_query_for_break = sqlQuery._properties.create_Tables;
    sequelize.query(create_query_for_break, {
      replacements: {
        Code: Tables.Code,
        Description: Tables.Description,
        PaidTime: Tables.PaidTime,
        Active: Tables.Active,
        Order: Tables.Order,
        TimeCardEntryId: entrydata,
      },
      type: sequelize.QueryTypes.INSERT,
      model: models.Tables
    }).then(function (values) {
      //updating the ref id
      var update_for_refId = sqlQueryEntry._properties.update_for_refId;
      sequelize.query(update_for_refId, {
        replacements: {
          id: entrydata,
          RefId: values
        },
        type: sequelize.QueryTypes.INSERT,
        model: models.Tables
      }).then(function (refIdSave) {
        var obj = { success: true, id: entrydata }
        callback(obj);
      });
    });
  });
}


module.exports.checkBreakEntries = function (Tables_id, callback) {

  var firstDate = moment(new Date()).format('YYYY-MM-DD');
  var secondDate = moment(new Date()).add(1, 'days').format("YYYY-MM-DD");

  var search_for_update_query = sqlQuery._properties.check_employee_break_availability;
  sequelize.query(search_for_update_query, {
    replacements: {
      Employee_Id: Tables_id,
      firstDate: firstDate,
      secondDate: secondDate
    },
    type: sequelize.QueryTypes.SELECT,
    model: models.Tables
  }).then(function (tables) {
    console.log("===>",tables)
    callback(tables);
  });

}

module.exports.update_Tables = function (Tables, callback) {
  var update_query = sqlQuery._properties.update_Tables;
  sequelize.query(update_query, {
    replacements: {
      Id: Tables.Id,
      Code: Tables.Code,
      Description: Tables.Description,
      PaidTime: Tables.PaidTime,
      Active: Tables.Active,
      Order: Tables.Order,
      TimeCardEntryId: Tables.TimeCardEntryId,
    },
    type: sequelize.QueryTypes.BULKUPDATE,
    model: models.Tables
  }).then(function (tables) {
    callback(tables);
  });
}

module.exports.search_Tables_for_update = function (Tables_id, callback) {
  var search_for_update_query = sqlQuery._properties.search_for_update_Tables;
  sequelize.query(search_for_update_query, {
    replacements: {
      id: Tables_id
    },
    type: sequelize.QueryTypes.SELECT,
    model: models.Tables
  }).then(function (tables) {
    callback(tables[0]);
  });
}

module.exports.delete_Tables = function (Tables_id, callback) {
  var delete_query = sqlQuery._properties.delete_Tables;
  sequelize.query(delete_query, {
    replacements: {
      id: Tables_id
    },
    type: sequelize.QueryTypes.DELETE,
    model: models.Tables
  }).then(function () {
    callback();
  });
}

module.exports.get_all_Tables = function (callback) {
  var get_all_query = sqlQuery._properties.get_all_Tables;
  sequelize.query(get_all_query, {
    type: sequelize.QueryTypes.SELECT,
    model: models.Tables
  }).then(function (tables) {
    callback(tables);
  });
}