var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var uniqueValidator = require('mongoose-unique-validator');
var autoIncrement = require('mongoose-auto-increment');

var mailSchema = new Schema({
    id:{type:Number},
    from :{type:String, default:null},
    to :{type:String, default:null},
    subject:{type:String, default:null},
    file:{type:Buffer, default:null},
    
},{
    versionKey:false
});
autoIncrement.initialize(mongoose);

reuserSchema.plugin(uniqueValidator);
reuserSchema.plugin(autoIncrement.plugin,{model:'reuser' , startAt:1});
var reuserDetails = mongoose.model('reuser', reuserSchema, 'Reuser');

module.exports = reuserDetails;