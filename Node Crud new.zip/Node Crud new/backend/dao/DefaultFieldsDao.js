
var DefaultField = require('../model/DefaultFields') 

//create default field in DefaultFields table
module.exports.createField = (fields, callback) => {

    var defaultField = new DefaultField(fields);
    defaultField.save(function(err,data){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
    
}

//get AllFields
module.exports.getAllFields = (callback) => {

    DefaultField.find(function(err,data){
        if(err){
            callback(err);
        }else{
            callback(data);
        }
    })
}