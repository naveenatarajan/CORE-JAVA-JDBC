var dao = require("../daos/TimeCard.ChangeLogDao")
module.exports.create_Tables = function(Tables,callback) {
  dao.create_Tables(Tables,function (tables){
    callback(tables);
  });
}
module.exports.update_Tables = function(Tables,callback) {
  dao.update_Tables(Tables,function (tables){
    callback(tables);
  });
}
module.exports.search_Tables_for_update = function(Tables_id,callback) {
  dao.search_Tables_for_update(Tables_id,function (tables){
    callback(tables)
  });
}
module.exports.delete_Tables = function(Tables_id,callback) {
  dao.delete_Tables(Tables_id,function (){
    callback();
  });
}
module.exports.get_all_Tables = function(callback) {
  dao.get_all_Tables(function (list_of_tables){
    callback(list_of_tables)
  });
}