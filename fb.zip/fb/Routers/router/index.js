exports.Facebook = require("./facebookroute");
exports.smschatbot = require("./smschatroute");
//exports.hotelChat = require("./hotelchatroute");