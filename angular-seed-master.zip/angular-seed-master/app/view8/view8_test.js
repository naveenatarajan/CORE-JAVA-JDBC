'use strict';

describe('myApp.view8 module', function() {

  beforeEach(module('myApp.view8'));

  describe('view8 controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view8Ctrl = $controller('View8Ctrl');
      expect(view8Ctrl).toBeDefined();
    }));

  });
});