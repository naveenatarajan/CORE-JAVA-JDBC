import {Component} from 'angular2/core';
import {bootstrap} from 'angular2/platform/browser';


@Component({
  selector: 'hello-world-example',
  providers: [myService],
  template: '<b class="color"><br/>{{helloworld}} world!"' +'<br/></b> {{curentdate}} <br/><br/><a href="{{webURL}}">Click for more detail..</a>'
})

class myApp {
  constructor(service: myService) {
    this.helloworld = service.getMesg();
    this.curentdate =service.getDate();
    this.webURL =service.getWebURL();
  }
}

class myService {
   getMesg() {
    return 'Welcome you, in Angular 2! "Hello';
  }
  
  getDate(){
    return new Date();
  }
  
  getWebURL(){
    return "http://www.code-sample.com/"
  }
}

//Start aplication from here.
bootstrap(myApp);